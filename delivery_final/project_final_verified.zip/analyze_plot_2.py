"""Проверка и корректная перерисовка второго EDA-графика.

Исходный stock-файл содержит несколько строк на один ключ
(date, warehouse_name, article). Для уровня прогноза "склад × товар"
остатки нужно сначала агрегировать, иначе merge размножает даты и рисует
несколько несовместимых линий внутри одного дня.
"""

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


SALES_PATH = Path("sales_dataset_hakaton_train.csv")
STOCK_PATH = Path("stock_dataset_hakaton_train.csv")
OUTPUT_PATH = Path("plot_2_out_of_stock_effect_corrected.png")


def main() -> None:
    sales = pd.read_csv(
        SALES_PATH,
        usecols=["date", "warehouse_name", "article", "quantity"],
        parse_dates=["date"],
    )
    stock = pd.read_csv(STOCK_PATH, parse_dates=["date"])

    sales_daily = (
        sales.groupby(["date", "warehouse_name", "article"], as_index=False)[
            "quantity"
        ].sum()
    )
    stock_daily = (
        stock.groupby(["date", "warehouse_name", "article"], as_index=False)[
            "stock"
        ].sum()
    )

    top_pair = (
        sales_daily.groupby(["warehouse_name", "article"], as_index=False)[
            "quantity"
        ]
        .sum()
        .nlargest(1, "quantity")
        .iloc[0]
    )
    warehouse = top_pair["warehouse_name"]
    article = top_pair["article"]

    end_date = sales_daily["date"].max()
    start_date = end_date - pd.Timedelta(days=180)
    dates = pd.DataFrame({"date": pd.date_range(start_date, end_date, freq="D")})

    pair_sales = sales_daily[
        (sales_daily["warehouse_name"] == warehouse)
        & (sales_daily["article"] == article)
    ][["date", "quantity"]]
    pair_stock = stock_daily[
        (stock_daily["warehouse_name"] == warehouse)
        & (stock_daily["article"] == article)
    ][["date", "stock"]]

    merged = dates.merge(pair_stock, on="date", how="left").merge(
        pair_sales, on="date", how="left"
    )
    # Отсутствие строки продажи означает 0 продаж. Отсутствие снимка остатка
    # не означает stock=0, поэтому пропуски stock намеренно оставляем NaN.
    merged["quantity"] = merged["quantity"].fillna(0)

    raw_pair = stock[
        (stock["warehouse_name"] == warehouse) & (stock["article"] == article)
    ]
    raw_recent = raw_pair[raw_pair["date"].between(start_date, end_date)]
    duplicate_extras = raw_recent.duplicated(["date"]).sum()
    zero_days = int(merged["stock"].eq(0).sum())

    plt.style.use("seaborn-v0_8-whitegrid")
    fig, ax_stock = plt.subplots(figsize=(14, 6), dpi=200)
    ax_sales = ax_stock.twinx()

    stock_line = ax_stock.plot(
        merged["date"],
        merged["stock"],
        color="#2B6CB0",
        linewidth=2,
        label="Суммарный остаток",
    )
    sales_bars = ax_sales.bar(
        merged["date"],
        merged["quantity"],
        color="#E53E3E",
        alpha=0.55,
        width=0.8,
        label="Продажи",
    )

    for date in merged.loc[merged["stock"].eq(0), "date"]:
        ax_stock.axvspan(
            date - pd.Timedelta(hours=12),
            date + pd.Timedelta(hours=12),
            color="#FED7D7",
            alpha=0.7,
        )

    ax_stock.set_title(
        "Остаток и продажи после агрегации дублей\n"
        f"Склад: {warehouse}, товар: {article}; дней stock=0: {zero_days}",
        fontsize=15,
        fontweight="bold",
    )
    ax_stock.set_xlabel("Дата")
    ax_stock.set_ylabel("Суммарный остаток", color="#2B6CB0")
    ax_sales.set_ylabel("Продажи в день", color="#E53E3E")
    ax_stock.tick_params(axis="y", labelcolor="#2B6CB0")
    ax_sales.tick_params(axis="y", labelcolor="#E53E3E")
    ax_stock.set_ylim(bottom=0)
    ax_sales.set_ylim(bottom=0)
    ax_sales.grid(False)
    ax_stock.legend(
        stock_line + [sales_bars],
        ["Суммарный остаток", "Продажи"],
        loc="upper left",
    )
    fig.tight_layout()
    fig.savefig(OUTPUT_PATH)
    plt.close(fig)

    print(f"Пара: {warehouse} / {article}")
    print(f"Период: {start_date.date()} — {end_date.date()} ({len(merged)} дней)")
    print(f"Сырых строк stock: {len(raw_recent)}")
    print(f"Лишних строк относительно одной строки на дату: {duplicate_extras}")
    print(f"Дней с суммарным stock=0: {zero_days}")
    print(f"График сохранён: {OUTPUT_PATH.resolve()}")


if __name__ == "__main__":
    main()
