#!/usr/bin/env python3
"""
test_reconciliation_prototype.py

Tests Task 1 (Double Gating elimination) and Task 2 (Series-aware reconciliation)
on Selection Folds (4, 3, 2).
"""

import sys
from pathlib import Path
import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(PROJECT_ROOT / "sber_hak"))

from fast_score import compute_all_metrics_fast, METRIC_WEIGHTS
from run_weekly_feature_experiments import WeeklyMatrices, make_truth, KEYS, HORIZON
from train_tft_weekly import baseline_mean13

SELECTION_FOLDS = {4: 89, 3: 98, 2: 107}


def apply_p(x, alpha=1.05, threshold=0.65):
    scaled = alpha * np.maximum(np.asarray(x, dtype=float), 0.0)
    gated = np.where(scaled < threshold, 0.0, scaled)
    return np.maximum(np.rint(gated), 0.0)


def series_reconcile(df_keyed: pd.DataFrame, pred_col: str, raw_col: str, tau_series: float = 1.3) -> np.ndarray:
    """
    Applies series-level recovery for all-zero series where expected volume >= tau_series.
    df_keyed must have ['warehouse_name', 'article', 'week', pred_col, raw_col].
    """
    df = df_keyed.copy()
    df['series_id'] = df['warehouse_name'] + '__' + df['article'].astype(str)
    
    # Calculate series-level sum of raw forecasts and sum of point-wise postprocessed forecasts
    grouped = df.groupby('series_id')
    raw_sums = grouped[raw_col].transform('sum')
    pred_sums = grouped[pred_col].transform('sum')
    
    # Identify maximum raw forecast week within each series
    raw_max = grouped[raw_col].transform('max')
    is_max_week = (df[raw_col] == raw_max) & (raw_max > 0)
    
    # Recovery condition:
    # Series was completely zeroed out by pointwise postprocessing,
    # but the 9-week cumulative expected demand >= tau_series
    reconciled_pred = df[pred_col].to_numpy().copy()
    
    # Series to recover: pred_sums == 0 and raw_sums >= tau_series
    recover_mask = (pred_sums == 0) & (raw_sums >= tau_series) & is_max_week
    
    # Handle possible ties in max week by picking only the first occurrence per series
    # (or simply adding 1.0)
    reconciled_pred[recover_mask] = 1.0
    
    return reconciled_pred


def main():
    data = pd.read_csv(PROJECT_ROOT / "weekly_data" / "weekly_dataset.csv.gz", parse_dates=["week"])
    matrices = WeeklyMatrices(data)
    weeks = sorted(data["week"].unique())

    print("=" * 80)
    print("PROTOTYPING TASK 1 & 2 ON SELECTION FOLDS (4, 3, 2)")
    print("=" * 80)

    for tau in [0.0, 1.0, 1.2, 1.3, 1.4, 1.5, 1.8, 2.0]:
        scores = []
        uncs = []
        smapes = []
        biases = []
        wapes = []
        rmses = []
        rmsles = []

        for fold, origin in SELECTION_FOLDS.items():
            val_weeks = weeks[origin : origin + HORIZON]
            truth = make_truth(matrices, origin)
            truth["week"] = pd.to_datetime(truth["week"]).dt.strftime("%Y-%m-%d")
            b_df = baseline_mean13(data, pd.Timestamp(val_weeks[0]), pd.Index(val_weeks))
            b_df["week"] = pd.to_datetime(b_df["week"]).dt.strftime("%Y-%m-%d")

            df_f = pd.read_csv(PROJECT_ROOT / "experiments" / "history_window_audit" / "keyed_oof" / f"blend_b_fold_{fold}.csv.gz")
            df_f["week"] = pd.to_datetime(df_f["week"]).dt.strftime("%Y-%m-%d")
            merged = truth[KEYS].merge(df_f, on=KEYS)

            # 1. Base prediction
            sub = truth[KEYS].copy()
            if tau == 0.0:
                # Standard Control B
                sub["quantity"] = merged["final_prediction"]
            else:
                # Apply series reconciler on top of Control B
                sub["warehouse_name"] = merged["warehouse_name"]
                sub["article"] = merged["article"]
                sub["pred_base"] = merged["final_prediction"]
                sub["raw_blend"] = merged["raw_blend"]
                sub["quantity"] = series_reconcile(sub, "pred_base", "raw_blend", tau_series=tau)
                sub = sub[KEYS + ["quantity"]]

            m = compute_all_metrics_fast(truth, sub)
            bm = compute_all_metrics_fast(truth, b_df)

            score = sum(w * min(max(m[k] / bm[k], 0), 1) for k, w in METRIC_WEIGHTS.items())
            unc = sum(w * (m[k] / bm[k]) for k, w in METRIC_WEIGHTS.items())

            scores.append(score)
            uncs.append(unc)
            smapes.append(m["smape"])
            biases.append(m["bias"])
            wapes.append(m["wape"])
            rmses.append(m["rmse"])
            rmsles.append(m["rmsle"])

        print(f"tau={tau:4.1f} | Score={np.mean(scores):.6f} (Delta={np.mean(scores) - 0.734539:+.6f}) | Unclipped={np.mean(uncs):.6f} (Delta={np.mean(uncs) - 0.761314:+.6f}) | SMAPE={np.mean(smapes):.2f}% | Bias={np.mean(biases):.2f}% | WAPE={np.mean(wapes):.2f}% | RMSE={np.mean(rmses):.4f}")


if __name__ == "__main__":
    main()
