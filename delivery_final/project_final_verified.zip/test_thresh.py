import pandas as pd
from fast_score import compute_all_metrics_fast

df_truth = pd.read_csv("val_ground_truth.csv")
df_sub = pd.read_csv("baseline_dow_mean.csv")

print("Влияние порога зануления (threshold) на baseline_dow_mean:")
for thresh in [0.0, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.4, 0.5]:
    df_temp = df_sub.copy()
    df_temp.loc[df_temp["quantity"] < thresh, "quantity"] = 0.0
    m = compute_all_metrics_fast(df_truth, df_temp)
    print(f"Порог {thresh:4.2f} -> SMAPE: {m['smape']:6.2f}%, WAPE: {m['wape']:6.2f}%, RMSE: {m['rmse']:6.4f}, Bias: {m['bias']:6.2f}%, RMSLE: {m['rmsle']:6.4f}")
