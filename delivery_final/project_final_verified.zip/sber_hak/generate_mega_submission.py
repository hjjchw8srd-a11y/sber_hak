"""Генерация окончательного сабмита лучшего калиброванного мега-ансамбля на тестовый период 9 недель.

Архитектура ансамбля (Score CV: 0.725573):
- 50% Temporal Fusion Transformer (TFT, neuralforecast на GPU)
- 30% LightGBM (настроенный Optuna)
- 10% Per-Category Models (14 моделей по категориям товаров)
- 10% CatBoost (base_calendar_network)
- Масштабная калибровка тренда (alpha = 1.05)
- Оптимальный порог отсечения нулей (threshold = 0.65) + целочисленное округление

Период: 2026-07-27 .. 2026-09-21 (9 недель).
Строк: 79 101.
"""

from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
import lightgbm as lgb

from run_weekly_feature_experiments import (
    HORIZON,
    KEYS,
    CAT_COLUMNS,
    WeeklyMatrices,
    columns_for_experiment,
    train_and_predict as train_and_predict_cb,
)
from score import validate_submission
from analyze_tft_postprocessing import apply_rule


def train_and_predict_lgbm(
    train: pd.DataFrame,
    target: np.ndarray,
    validation: pd.DataFrame,
    columns: list[str],
    iterations: int = 200,
) -> np.ndarray:
    cat_columns = [c for c in CAT_COLUMNS if c in columns]
    X_train = train[columns].copy()
    X_val = validation[columns].copy()

    for col in cat_columns:
        X_train[col] = X_train[col].astype("category")
        X_val[col] = X_val[col].astype("category")

    clf = lgb.LGBMClassifier(
        n_estimators=160,
        learning_rate=0.0495,
        num_leaves=29,
        min_child_samples=51,
        subsample=0.727,
        colsample_bytree=0.728,
        reg_alpha=0.0164,
        reg_lambda=0.0057,
        random_state=42,
        verbosity=-1,
        n_jobs=-1,
    )
    clf.fit(X_train, (target > 0).astype(int))
    proba = clf.predict_proba(X_val)[:, 1]

    pos_idx = target > 0
    reg = lgb.LGBMRegressor(
        n_estimators=160,
        learning_rate=0.0495,
        num_leaves=29,
        min_child_samples=51,
        subsample=0.727,
        colsample_bytree=0.728,
        reg_alpha=0.0164,
        reg_lambda=0.0057,
        random_state=42,
        verbosity=-1,
        n_jobs=-1,
    )
    reg.fit(X_train.loc[pos_idx], np.log1p(target[pos_idx]))
    cond = np.expm1(reg.predict(X_val))

    pred = proba * np.maximum(cond, 0)
    pred[proba < 0.5] = 0.0
    return pred


def main(alpha: float = 1.05, optimal_threshold: float = 0.65) -> None:
    print("1. Подготовка матриц данных и фичей для будущего горизонта...")
    data = pd.read_csv("weekly_data/weekly_dataset.csv.gz", parse_dates=["week"])
    first_week = data[data["week"] == data["week"].min()].sort_values(["warehouse_name", "article"])
    pairs_df = first_week[["warehouse_name", "article", "category_lvl_1", "category_lvl_2", "category_lvl_3"]].copy()

    future_weeks = pd.date_range("2026-07-27", periods=HORIZON, freq="W-MON")

    future_rows = []
    for w in future_weeks:
        chunk = pairs_df.copy()
        chunk["week"] = w
        chunk["quantity"] = 0.0
        chunk["sales_sum"] = 0.0
        chunk["discount_sum"] = 0.0
        chunk["stock_week_end"] = np.nan
        chunk["stock_mean"] = np.nan
        chunk["stock_nonpositive_rate"] = np.nan
        chunk["stock_observed_days"] = 0.0
        future_rows.append(chunk)

    future_df = pd.concat(future_rows, ignore_index=True)
    extended_data = pd.concat([data, future_df], ignore_index=True)

    matrices = WeeklyMatrices(extended_data)
    origin = len(data["week"].unique())  # 134

    latest_train_origin = origin - HORIZON
    earliest_train_origin = max(26, latest_train_origin - 17)
    train_origins = np.arange(earliest_train_origin, latest_train_origin + 1)
    columns = columns_for_experiment("base_calendar_network")

    print(f"Обучение на исторических ориджинах {train_origins[0]}..{train_origins[-1]}")
    train_df, target_arr, _ = matrices.make_rows(train_origins, 350_000, seed=42)
    test_df, _, _ = matrices.make_rows(np.array([origin]), None)

    print("2. Обучение LightGBM (Optuna-tuned) и прогноз на 9 недель...")
    lgbm_vals = train_and_predict_lgbm(train_df, target_arr, test_df, columns, iterations=200)

    print("3. Обучение CatBoost и прогноз на 9 недель...")
    cb_vals, _ = train_and_predict_cb(train_df, target_arr, test_df, columns, iterations=160)

    test_weeks = np.repeat(matrices.weeks[origin : origin + HORIZON].to_numpy(), matrices.n_pairs)
    test_pairs = pd.concat([matrices.pairs] * HORIZON, ignore_index=True)

    test_keys = pd.DataFrame({
        "week": pd.to_datetime(test_weeks).strftime("%Y-%m-%d"),
        "warehouse_name": test_pairs["warehouse_name"],
        "article": test_pairs["article"],
    })

    print("4. Загрузка прогноза TFT (NeuralForecast GPU)...")
    tft_raw_path = Path("experiments/tft/tft_final_prediction_raw.csv.gz")
    if not tft_raw_path.exists():
        tft_raw_path = Path("experiments/tft/tft_final_submission.csv")
    tft_df = pd.read_csv(tft_raw_path)
    tft_df["week"] = pd.to_datetime(tft_df["week"]).dt.strftime("%Y-%m-%d")

    print("5. Загрузка прогноза Per-Category Models...")
    per_cat_path = Path("experiments/benchmarks/per_category/per_category_final_submission.csv")
    per_cat_df = pd.read_csv(per_cat_path)
    per_cat_df["week"] = pd.to_datetime(per_cat_df["week"]).dt.strftime("%Y-%m-%d")

    # Объединяем прогнозы
    merged = test_keys.merge(tft_df, on=KEYS, how="inner").rename(columns={"quantity": "tft_qty"})
    merged = merged.merge(per_cat_df, on=KEYS, how="inner").rename(columns={"quantity": "per_cat_qty"})
    merged["lgbm_qty"] = np.maximum(lgbm_vals, 0)
    merged["cb_qty"] = np.maximum(cb_vals, 0)

    print("6. Взвешивание 4-компонентного мега-ансамбля (50% TFT + 30% LightGBM + 10% Per-Category + 10% CatBoost)...")
    raw_blend = (
        0.50 * merged["tft_qty"].values
        + 0.30 * merged["lgbm_qty"].values
        + 0.10 * merged["per_cat_qty"].values
        + 0.10 * merged["cb_qty"].values
    )

    print(f"7. Масштабная калибровка тренда (alpha = {alpha})...")
    scaled_blend = raw_blend * alpha

    print(f"8. Применение оптимизированного порога {optimal_threshold} и целочисленного округления...")
    final_qty = apply_rule(pd.Series(scaled_blend), threshold=optimal_threshold, round_to_int=True)
    merged["quantity"] = final_qty

    final_sub = merged[KEYS + ["quantity"]]
    final_sub.to_csv("final_submission.csv", index=False)
    print(f"Файл final_submission.csv успешно сохранен! Строк: {len(final_sub)}")

    warnings = validate_submission(final_sub, "final_submission")
    if warnings:
        print("Предупреждения:")
        for w in warnings:
            print("  ⚠", w)
    else:
        print("Валидация ТЗ пройдена успешно (0 ошибок, формат 100% корректен).")

    print("\nСтатистика финального сабмита:")
    print(f"  Доля ненулевых строк: {(final_sub['quantity'] > 0).mean() * 100:.2f}%")
    print(f"  Среднее значение:     {final_sub['quantity'].mean():.2f}")
    print(f"  Максимальное:         {final_sub['quantity'].max():.0f}")
    print("\nПример первых строк сабмита:")
    print(final_sub.head())


if __name__ == "__main__":
    main()
