"""Обучение отдельных моделей прогнозирования для каждого вида (категории) товаров.

Подход:
1. В датасете 14 макро-категорий товаров (category_lvl_1).
2. Для каждой категории обучается отдельная независимая двухэтапная модель:
   - классификатор вероятности продажи (настроенный под zero-rate категории)
   - регрессор объема продажи при условии quantity > 0
3. Оценка проводится на тех же 3-х фолдах скользящей валидации.
"""

from __future__ import annotations
from pathlib import Path
import time
import numpy as np
import pandas as pd
import lightgbm as lgb

from fast_score import compute_all_metrics_fast
from score import normalized_score
from run_weekly_feature_experiments import (
    HORIZON,
    KEYS,
    CAT_COLUMNS,
    WeeklyMatrices,
    columns_for_experiment,
    make_truth,
    prediction_frame,
)
from train_tft_weekly import baseline_mean13
from analyze_tft_postprocessing import apply_rule


def train_predict_category(
    X_train_cat: pd.DataFrame,
    y_train_cat: np.ndarray,
    X_val_cat: pd.DataFrame,
    feature_cols: list[str],
    cat_cols: list[str],
) -> np.ndarray:
    if len(X_val_cat) == 0:
        return np.array([])

    # Если в категории совсем мало продаж, возвращаем среднее или нули
    pos_mask = y_train_cat > 0
    if pos_mask.sum() < 20:
        return np.full(len(X_val_cat), max(0.0, float(np.mean(y_train_cat))))

    clf = lgb.LGBMClassifier(
        n_estimators=140,
        learning_rate=0.06,
        num_leaves=25,
        min_child_samples=20,
        random_state=42,
        verbosity=-1,
        n_jobs=-1,
    )
    clf.fit(X_train_cat[feature_cols], (y_train_cat > 0).astype(int))
    proba = clf.predict_proba(X_val_cat[feature_cols])[:, 1]

    reg = lgb.LGBMRegressor(
        n_estimators=140,
        learning_rate=0.06,
        num_leaves=25,
        min_child_samples=20,
        random_state=42,
        verbosity=-1,
        n_jobs=-1,
    )
    reg.fit(X_train_cat.loc[pos_mask, feature_cols], np.log1p(y_train_cat[pos_mask]))
    cond = np.expm1(reg.predict(X_val_cat[feature_cols]))

    pred = proba * np.maximum(cond, 0)
    pred[proba < 0.5] = 0.0
    return pred


def main() -> None:
    print("=== Запуск обучения отдельных моделей для каждого вида (категории) товаров ===")
    data = pd.read_csv("weekly_data/weekly_dataset.csv.gz", parse_dates=["week"])
    matrices = WeeklyMatrices(data)
    latest_origin = len(matrices.weeks) - HORIZON
    folds = 3
    fold_step = HORIZON

    output_dir = Path("experiments/benchmarks/per_category")
    output_dir.mkdir(parents=True, exist_ok=True)

    all_columns = columns_for_experiment("base_calendar_network")
    # category_lvl_1 не нужна как фича внутри модели категории, но нужна для разбиения
    feature_columns = [c for c in all_columns if c != "category_lvl_1"]
    cat_columns = [c for c in CAT_COLUMNS if c in feature_columns]

    results = []

    for fold in range(folds):
        origin = latest_origin - fold * fold_step
        validation_weeks = matrices.weeks[origin : origin + HORIZON]
        truth = make_truth(matrices, origin)

        baseline = baseline_mean13(data, pd.Timestamp(validation_weeks[0]), pd.Index(validation_weeks))
        baseline_metrics = compute_all_metrics_fast(truth, baseline)

        latest_train_origin = origin - HORIZON
        earliest_train_origin = max(26, latest_train_origin - 17)
        train_origins = np.arange(earliest_train_origin, latest_train_origin + 1)

        print(f"\n--- Fold {fold}: обучение 14 категориальных моделей ---")
        train_df, target_arr, _ = matrices.make_rows(train_origins, 350_000, seed=42 + fold)
        val_df, _, _ = matrices.make_rows(np.array([origin]), None)

        train_df["target"] = target_arr

        # Преобразуем категориальные колонки
        for col in cat_columns:
            train_df[col] = train_df[col].astype("category")
            val_df[col] = val_df[col].astype("category")

        val_predictions = np.zeros(len(val_df), dtype=np.float32)

        unique_categories = sorted(train_df["category_lvl_1"].unique())
        started = time.perf_counter()

        for cat in unique_categories:
            train_mask = train_df["category_lvl_1"] == cat
            val_mask = val_df["category_lvl_1"] == cat

            X_tr_cat = train_df.loc[train_mask]
            y_tr_cat = train_df.loc[train_mask, "target"].values
            X_val_cat = val_df.loc[val_mask]

            cat_pred = train_predict_category(X_tr_cat, y_tr_cat, X_val_cat, feature_columns, cat_columns)
            val_predictions[val_mask.values] = cat_pred

        elapsed = time.perf_counter() - started

        pred_df = prediction_frame(truth, val_predictions)
        pred_df["quantity"] = apply_rule(pred_df["quantity"], threshold=0.75, round_to_int=True)

        metrics = compute_all_metrics_fast(truth, pred_df)
        score = normalized_score(metrics, baseline_metrics)

        row = {
            "fold": fold,
            "validation_start": str(validation_weeks[0].date()),
            "validation_end": str(validation_weeks[-1].date()),
            **metrics,
            "normalized_score": score,
            "seconds": elapsed,
        }
        results.append(row)
        print(f"Fold {fold}: Score={score:.4f}, SMAPE={metrics['smape']:.2f}%, WAPE={metrics['wape']:.2f}% (время: {elapsed:.1f}с)")
        pred_df.to_csv(output_dir / f"per_cat_predictions_fold_{fold}.csv.gz", index=False)

    df_res = pd.DataFrame(results)
    df_res.to_csv(output_dir / "per_category_results.csv", index=False)

    print("\n" + "=" * 60)
    print("ИТОГИ МОДЕЛЕЙ ПО ВИДАМ ТОВАРОВ (PER-CATEGORY):")
    print(f"  Средний Score (3 folds): {df_res['normalized_score'].mean():.6f}")
    print(f"  Средний SMAPE:           {df_res['smape'].mean():.2f}%")
    print(f"  Средний WAPE:            {df_res['wape'].mean():.2f}%")
    print(f"  Среднее время на фолд:   {df_res['seconds'].mean():.1f} с")
    print("=" * 60)


if __name__ == "__main__":
    main()
