import json
import optuna
from train_tft_weekly import train_tft

def objective(trial):
    """Optuna objective: returns SMAPE for given hyper‑parameters."""
    config = {
        # hidden_size must be divisible by n_head (=4) – use step=4
        "hidden_size": trial.suggest_int("hidden_size", 16, 128, step=4),
        "learning_rate": trial.suggest_float("learning_rate", 1e-4, 1e-1, log=True),
        "input_size": trial.suggest_int("input_size", 20, 30),
        "max_steps": trial.suggest_int("max_steps", 200, 500),
        "batch_size": trial.suggest_categorical("batch_size", [64, 128, 256]),
        "windows_batch_size": trial.suggest_categorical("windows_batch_size", [256, 512, 1024]),
        "patience": trial.suggest_int("patience", 3, 10),
    }
    try:
        result = train_tft(config)
        return float(result["val_smape"])
    except Exception as e:
        print(f"Trial failed with error: {e}")
        # Return a large penalty value
        return 1e6

    """Optuna objective: returns SMAPE for given hyper‑parameters."""
    config = {
        # hidden_size must be divisible by n_head (=4) – use step=4
        "hidden_size": trial.suggest_int("hidden_size", 16, 128, step=4),
        "learning_rate": trial.suggest_float("learning_rate", 1e-4, 1e-1, log=True),
        "input_size": trial.suggest_int("input_size", 20, 30),
        "max_steps": trial.suggest_int("max_steps", 200, 500),
        "batch_size": trial.suggest_categorical("batch_size", [64, 128, 256]),
        "windows_batch_size": trial.suggest_categorical("windows_batch_size", [256, 512, 1024]),
        "patience": trial.suggest_int("patience", 3, 10),
    }
    result = train_tft(config)
    return float(result["val_smape"])

if __name__ == "__main__":
    study = optuna.create_study(direction="minimize")
    study.optimize(objective, n_trials=20)
    print("Best trial:")
    print(study.best_trial.params)
    with open("tft_optuna_best.json", "w", encoding="utf-8") as f:
        json.dump(study.best_trial.params, f, ensure_ascii=False, indent=2)

import optuna
from train_tft_weekly import train_tft

def objective(trial):
    """Optuna objective: returns SMAPE for given hyper‑parameters."""
    config = {
        # hidden_size must be divisible by n_head (=4) – use step=4
        "hidden_size": trial.suggest_int("hidden_size", 16, 128, step=4),
        "learning_rate": trial.suggest_float("learning_rate", 1e-4, 1e-1, log=True),
        "input_size": trial.suggest_int("input_size", 20, 30),
        "max_steps": trial.suggest_int("max_steps", 200, 500),
        "batch_size": trial.suggest_categorical("batch_size", [64, 128, 256]),
        "windows_batch_size": trial.suggest_categorical("windows_batch_size", [256, 512, 1024]),
        "patience": trial.suggest_int("patience", 3, 10),
    }
    try:
        result = train_tft(config)
        return float(result["val_smape"])
    except Exception as e:
        print(f"Trial failed with error: {e}")
        # Return a large penalty value
        return 1e6

    """Optuna objective: returns SMAPE for given hyper‑parameters."""
    config = {
        "learning_rate": trial.suggest_loguniform("learning_rate", 1e-4, 1e-1),
        "hidden_size": trial.suggest_int("hidden_size", 16, 128),
        "input_size": trial.suggest_int("input_size", 20, 30),
        "max_steps": trial.suggest_int("max_steps", 200, 500),
        "batch_size": trial.suggest_categorical("batch_size", [64, 128, 256]),
        "windows_batch_size": trial.suggest_categorical("windows_batch_size", [256, 512, 1024]),
        "patience": trial.suggest_int("patience", 3, 10),
    }
    result = train_tft(config)
    # Optuna minimizes, so return SMAPE (lower is better)
    return float(result["val_smape"])

if __name__ == "__main__":
    study = optuna.create_study(direction="minimize")
    study.optimize(objective, n_trials=20)
    print("Best trial:")
    print(study.best_trial.params)
    # Save best params for later use
    with open("tft_optuna_best.json", "w", encoding="utf-8") as f:
        json.dump(study.best_trial.params, f, ensure_ascii=False, indent=2)
