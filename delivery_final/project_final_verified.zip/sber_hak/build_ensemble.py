"""Ансамбль TFT + CatBoost на тех же 3 rolling-окнах.

Для каждого фолда:
1) Берём прогнозы TFT (с постобработкой) и CatBoost (base_calendar_network).
2) Строим ансамбль: взвешенное среднее с разными весами.
3) Считаем Score и сравниваем с каждой моделью по отдельности.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from fast_score import compute_all_metrics_fast
from score import normalized_score
from train_tft_weekly import METRICS, baseline_mean13, truth_frame

# --- CatBoost weekly pipeline (from run_weekly_feature_experiments) ---
from run_weekly_feature_experiments import (
    HORIZON,
    WeeklyMatrices,
    columns_for_experiment,
    make_truth,
    prediction_frame,
    train_and_predict,
)
from analyze_tft_postprocessing import apply_rule


CATBOOST_EXPERIMENT = "base_calendar_network"
TFT_OUTPUT_DIR = Path("experiments/tft")
OUTPUT_DIR = Path("experiments/ensemble")


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    # --- Load data ---
    data = pd.read_csv("weekly_data/weekly_dataset.csv.gz", parse_dates=["week"])
    matrices = WeeklyMatrices(data)
    latest_origin = len(matrices.weeks) - HORIZON

    folds = 3
    fold_step = HORIZON

    # TFT rolling results to get the same fold boundaries
    tft_rolling = pd.read_csv(TFT_OUTPUT_DIR / "tft_rolling_results.csv")

    # Weight grid for ensemble
    tft_weights = np.arange(0.0, 1.05, 0.1)  # 0.0, 0.1, ..., 1.0

    all_rows = []

    for fold_idx in range(folds):
        origin = latest_origin - fold_idx * fold_step
        validation_start = str(matrices.weeks[origin].date())
        validation_end = str(matrices.weeks[origin + HORIZON - 1].date())

        # --- Truth and baseline ---
        weeks_idx = pd.Index(matrices.weeks[origin: origin + HORIZON])
        truth = truth_frame(data, weeks_idx)
        baseline = baseline_mean13(data, pd.Timestamp(weeks_idx[0]), weeks_idx)
        baseline_metrics = compute_all_metrics_fast(truth, baseline)

        # --- TFT predictions (with postprocessing: threshold=0.75, round=True) ---
        tft_pred_path = TFT_OUTPUT_DIR / f"tft_predictions_fold_{fold_idx}.csv.gz"
        if not tft_pred_path.exists():
            print(f"  SKIP fold {fold_idx}: TFT predictions not found at {tft_pred_path}")
            continue
        tft_pred = pd.read_csv(tft_pred_path, parse_dates=["week"])
        tft_pred["quantity"] = apply_rule(tft_pred["quantity"], threshold=0.75, round_to_int=True)

        # --- CatBoost predictions (weekly, base_calendar_network) ---
        columns = columns_for_experiment(CATBOOST_EXPERIMENT)
        latest_train_origin = origin - HORIZON
        earliest_train_origin = max(26, latest_train_origin - 17)
        train_origins = np.arange(earliest_train_origin, latest_train_origin + 1)
        train, target, _ = matrices.make_rows(train_origins, 350_000, seed=42 + fold_idx)
        validation, _, _ = matrices.make_rows(np.array([origin]), None)
        cb_prediction_values, _ = train_and_predict(
            train, target, validation, columns, iterations=160
        )
        cb_truth = make_truth(matrices, origin)
        cb_pred = prediction_frame(cb_truth, cb_prediction_values)

        # Merge TFT and CatBoost predictions
        keys = ["week", "warehouse_name", "article"]
        merged = tft_pred[keys + ["quantity"]].merge(
            cb_pred[keys + ["quantity"]],
            on=keys,
            how="inner",
            suffixes=("_tft", "_cb"),
        )

        # --- Individual model scores ---
        tft_metrics = compute_all_metrics_fast(truth, tft_pred)
        tft_score = normalized_score(tft_metrics, baseline_metrics)
        cb_metrics = compute_all_metrics_fast(truth, cb_pred)
        cb_score = normalized_score(cb_metrics, baseline_metrics)

        print(f"\nFold {fold_idx}: TFT score={tft_score:.4f}, CatBoost score={cb_score:.4f}")

        for tft_w in tft_weights:
            cb_w = 1.0 - tft_w
            ensemble_qty = tft_w * merged["quantity_tft"].values + cb_w * merged["quantity_cb"].values
            # Post-process ensemble: threshold at 0.5, round to int
            ensemble_qty = np.clip(ensemble_qty, 0, None)

            ensemble_pred = merged[keys].copy()
            ensemble_pred["quantity"] = ensemble_qty

            # Also try with rounding
            for do_round in [False, True]:
                pred_final = ensemble_pred.copy()
                if do_round:
                    pred_final["quantity"] = np.rint(pred_final["quantity"]).clip(0, None)

                metrics = compute_all_metrics_fast(truth, pred_final)
                score = normalized_score(metrics, baseline_metrics)

                row = {
                    "fold": fold_idx,
                    "validation_start": validation_start,
                    "validation_end": validation_end,
                    "tft_weight": round(tft_w, 2),
                    "catboost_weight": round(cb_w, 2),
                    "round_to_int": do_round,
                    **metrics,
                    "normalized_score": score,
                    "tft_only_score": tft_score,
                    "cb_only_score": cb_score,
                }
                all_rows.append(row)

    results = pd.DataFrame(all_rows)
    results.to_csv(OUTPUT_DIR / "ensemble_results.csv", index=False)

    # Summary: average across folds
    summary = (
        results.groupby(["tft_weight", "catboost_weight", "round_to_int"], as_index=False)
        .agg(
            mean_score=("normalized_score", "mean"),
            std_score=("normalized_score", "std"),
            mean_smape=("smape", "mean"),
            mean_wape=("wape", "mean"),
            mean_rmse=("rmse", "mean"),
            mean_bias=("bias", "mean"),
            mean_rmsle=("rmsle", "mean"),
        )
        .sort_values("mean_score")
        .reset_index(drop=True)
    )
    summary.to_csv(OUTPUT_DIR / "ensemble_summary.csv", index=False)

    best = summary.iloc[0]
    tft_avg = results.groupby("fold")["tft_only_score"].first().mean()
    cb_avg = results.groupby("fold")["cb_only_score"].first().mean()

    print("\n" + "=" * 60)
    print("ENSEMBLE RESULTS")
    print("=" * 60)
    print(f"TFT only (avg score):       {tft_avg:.6f}")
    print(f"CatBoost only (avg score):  {cb_avg:.6f}")
    print(f"\nBest ensemble:")
    print(f"  TFT weight:    {best['tft_weight']:.2f}")
    print(f"  CB weight:     {best['catboost_weight']:.2f}")
    print(f"  Round to int:  {best['round_to_int']}")
    print(f"  Mean score:    {best['mean_score']:.6f}")
    print(f"  Improvement vs TFT: {tft_avg - best['mean_score']:.6f}")
    print(f"  Improvement vs CB:  {cb_avg - best['mean_score']:.6f}")
    print("\nTop 10 ensemble configs:")
    print(summary.head(10).to_string(index=False))


# Generate final ensemble submission using best configuration
def generate_final_submission(best_config):
    tft_weight = best_config['tft_weight']
    catboost_weight = best_config['catboost_weight']
    do_round = best_config['round_to_int']
    # Prepare output DataFrame
    all_preds = []
    data = pd.read_csv("weekly_data/weekly_dataset.csv.gz", parse_dates=["week"])
    matrices = WeeklyMatrices(data)
    latest_origin = len(matrices.weeks) - HORIZON
    folds = 3
    fold_step = HORIZON
    for fold_idx in range(folds):
        origin = latest_origin - fold_idx * fold_step
        # Load TFT predictions
        tft_pred_path = TFT_OUTPUT_DIR / f"tft_predictions_fold_{fold_idx}.csv.gz"
        tft_pred = pd.read_csv(tft_pred_path, parse_dates=["week"])
        tft_pred["quantity"] = apply_rule(tft_pred["quantity"], threshold=0.75, round_to_int=True)
        # CatBoost predictions
        columns = columns_for_experiment(CATBOOST_EXPERIMENT)
        latest_train_origin = origin - HORIZON
        earliest_train_origin = max(26, latest_train_origin - 17)
        train_origins = np.arange(earliest_train_origin, latest_train_origin + 1)
        train, target, _ = matrices.make_rows(train_origins, 350_000, seed=42 + fold_idx)
        validation, _, _ = matrices.make_rows(np.array([origin]), None)
        cb_prediction_values, _ = train_and_predict(
            train, target, validation, columns, iterations=160
        )
        cb_truth = make_truth(matrices, origin)
        cb_pred = prediction_frame(cb_truth, cb_prediction_values)
        # Merge
        keys = ["week", "warehouse_name", "article"]
        merged = tft_pred[keys + ["quantity"]].merge(
            cb_pred[keys + ["quantity"]], on=keys, how="inner", suffixes=("_tft", "_cb")
        )
        ensemble_qty = tft_weight * merged["quantity_tft"].values + catboost_weight * merged["quantity_cb"].values
        if do_round:
            ensemble_qty = np.rint(ensemble_qty).clip(0, None)
        else:
            ensemble_qty = np.clip(ensemble_qty, 0, None)
        pred_df = merged[keys].copy()
        pred_df["quantity"] = ensemble_qty.astype(int)
        all_preds.append(pred_df)
    final_df = pd.concat(all_preds, ignore_index=True)
    # Ensure correct order of columns
    final_df = final_df["week"].astype(str).replace("T00:00:00", "", regex=True).to_frame().join(
        final_df[["warehouse_name", "article", "quantity"]]
    )
    final_df.to_csv("final_submission.csv", index=False)
    print("Final ensemble submission written to final_submission.csv")

if __name__ == "__main__":
    main()
    # After main, generate final submission using best config
    try:
        # Load summary to get best config
        summary_path = OUTPUT_DIR / "ensemble_summary.csv"
        summary_df = pd.read_csv(summary_path)
        best_cfg = summary_df.iloc[0]
        generate_final_submission(best_cfg)
    except Exception as e:
        print(f"Failed to generate final submission: {e}")
