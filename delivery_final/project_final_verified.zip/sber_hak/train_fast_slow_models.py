"""Обучение раздельных специализированных моделей для частых и редких товаров.

1. Сегментация на основе истории до точки прогноза (без заглядывания в будущее):
   - Fast-moving (частые товары): nonzero_rate_26 >= 0.35
   - Slow-moving (редкие товары): nonzero_rate_26 < 0.35
2. Модель частых товаров:
   - Обучается на частых рядах.
   - Минимальное зануление для сохранения WAPE и RMSE (ходовые товары делают >85% оборота).
3. Модель редких товаров:
   - Обучается на разреженных рядах.
   - Агрессивная фильтрация ложных продаж (высокий gate), оптимизирующая серийный SMAPE.
4. Валидация на тех же 3-х фолдах Rolling CV.
"""

from __future__ import annotations
from pathlib import Path
import time
import numpy as np
import pandas as pd
import lightgbm as lgb

from fast_score import compute_all_metrics_fast
from score import normalized_score
from run_weekly_feature_experiments import (
    HORIZON,
    KEYS,
    CAT_COLUMNS,
    WeeklyMatrices,
    columns_for_experiment,
    make_truth,
    prediction_frame,
)
from train_tft_weekly import baseline_mean13
from analyze_tft_postprocessing import apply_rule


def train_predict_segment(
    train_df: pd.DataFrame,
    target_arr: np.ndarray,
    val_df: pd.DataFrame,
    columns: list[str],
    cat_columns: list[str],
    is_fast_segment: bool,
) -> np.ndarray:
    if len(val_df) == 0:
        return np.array([])

    X_train = train_df[columns].copy()
    X_val = val_df[columns].copy()
    for col in cat_columns:
        X_train[col] = X_train[col].astype("category")
        X_val[col] = X_val[col].astype("category")

    if is_fast_segment:
        # Для частых товаров: модель сфокусирована на регрессии объема
        clf = lgb.LGBMClassifier(
            n_estimators=160,
            learning_rate=0.05,
            num_leaves=31,
            min_child_samples=40,
            random_state=42,
            verbosity=-1,
            n_jobs=-1,
        )
        clf.fit(X_train, (target_arr > 0).astype(int))
        proba = clf.predict_proba(X_val)[:, 1]

        pos_idx = target_arr > 0
        reg = lgb.LGBMRegressor(
            n_estimators=160,
            learning_rate=0.05,
            num_leaves=31,
            min_child_samples=40,
            random_state=42,
            verbosity=-1,
            n_jobs=-1,
        )
        reg.fit(X_train.loc[pos_idx], np.log1p(target_arr[pos_idx]))
        cond = np.expm1(reg.predict(X_val))

        # Мягкий порог для частых товаров (не зануляем лишний раз)
        pred = proba * np.maximum(cond, 0)
        pred[proba < 0.35] = 0.0
        return pred

    else:
        # Для редких товаров: строгий отбор вероятности, защищающий SMAPE
        clf = lgb.LGBMClassifier(
            n_estimators=140,
            learning_rate=0.05,
            num_leaves=20,
            min_child_samples=25,
            class_weight="balanced",
            random_state=42,
            verbosity=-1,
            n_jobs=-1,
        )
        clf.fit(X_train, (target_arr > 0).astype(int))
        proba = clf.predict_proba(X_val)[:, 1]

        pos_idx = target_arr > 0
        reg = lgb.LGBMRegressor(
            n_estimators=140,
            learning_rate=0.05,
            num_leaves=20,
            min_child_samples=25,
            random_state=42,
            verbosity=-1,
            n_jobs=-1,
        )
        reg.fit(X_train.loc[pos_idx], np.log1p(target_arr[pos_idx]))
        cond = np.expm1(reg.predict(X_val))

        # Жесткий порог вероятности для редких товаров (отсекаем ложные шумы)
        pred = proba * np.maximum(cond, 0)
        pred[proba < 0.65] = 0.0
        return pred


def main() -> None:
    print("=== Запуск обучения раздельных моделей: Частые (Fast) vs Редкие (Slow) товары ===")
    data = pd.read_csv("weekly_data/weekly_dataset.csv.gz", parse_dates=["week"])
    matrices = WeeklyMatrices(data)
    latest_origin = len(matrices.weeks) - HORIZON
    folds = 3
    fold_step = HORIZON

    output_dir = Path("experiments/benchmarks/fast_slow")
    output_dir.mkdir(parents=True, exist_ok=True)

    columns = columns_for_experiment("base_calendar_network")
    cat_columns = [c for c in CAT_COLUMNS if c in columns]

    results = []

    for fold in range(folds):
        origin = latest_origin - fold * fold_step
        validation_weeks = matrices.weeks[origin : origin + HORIZON]
        truth = make_truth(matrices, origin)

        baseline = baseline_mean13(data, pd.Timestamp(validation_weeks[0]), pd.Index(validation_weeks))
        baseline_metrics = compute_all_metrics_fast(truth, baseline)

        latest_train_origin = origin - HORIZON
        earliest_train_origin = max(26, latest_train_origin - 17)
        train_origins = np.arange(earliest_train_origin, latest_train_origin + 1)

        # Классификация серий строго по истории фолда (до origin)
        history26 = matrices.quantity[origin - 26 : origin]  # (26, n_pairs)
        nonzero_rate_26 = (history26 > 0).mean(axis=0)  # (n_pairs,)
        is_fast_pair = nonzero_rate_26 >= 0.35  # boolean array (n_pairs,)

        print(f"\n--- Fold {fold}: {validation_weeks[0].date()} .. {validation_weeks[-1].date()} ---")
        print(f"  Частых серий: {is_fast_pair.sum()} ({is_fast_pair.mean():.1%}), редких: {(~is_fast_pair).sum()} ({(~is_fast_pair).mean():.1%})")

        train_df, target_arr, _ = matrices.make_rows(train_origins, 350_000, seed=42 + fold)
        val_df, _, _ = matrices.make_rows(np.array([origin]), None)

        # Размечаем строки по признаку is_fast_pair
        # pair_idx в make_rows соответствует self.pairs
        pair_to_fast = pd.Series(is_fast_pair, index=pd.MultiIndex.from_frame(matrices.pairs))
        train_pairs = pd.MultiIndex.from_frame(train_df[["warehouse_name", "article"]])
        val_pairs = pd.MultiIndex.from_frame(val_df[["warehouse_name", "article"]])

        train_is_fast = pair_to_fast.loc[train_pairs].values
        val_is_fast = pair_to_fast.loc[val_pairs].values

        started = time.perf_counter()

        # 1. Обучаем модель для частых товаров
        train_fast_df = train_df[train_is_fast]
        target_fast = target_arr[train_is_fast]
        val_fast_df = val_df[val_is_fast]
        pred_fast = train_predict_segment(train_fast_df, target_fast, val_fast_df, columns, cat_columns, is_fast_segment=True)

        # 2. Обучаем модель для редких товаров
        train_slow_df = train_df[~train_is_fast]
        target_slow = target_arr[~train_is_fast]
        val_slow_df = val_df[~val_is_fast]
        pred_slow = train_predict_segment(train_slow_df, target_slow, val_slow_df, columns, cat_columns, is_fast_segment=False)

        elapsed = time.perf_counter() - started

        # Объединяем предсказания
        val_predictions = np.zeros(len(val_df), dtype=np.float32)
        val_predictions[val_is_fast] = pred_fast
        val_predictions[~val_is_fast] = pred_slow

        # Дифференцированная постобработка:
        # Для редких товаров — более строгий порог зануления (0.85)
        # Для частых товаров — естественное округление (0.50)
        final_qty = np.zeros(len(val_df), dtype=np.float32)
        final_qty[val_is_fast] = apply_rule(pd.Series(val_predictions[val_is_fast]), threshold=0.50, round_to_int=True)
        final_qty[~val_is_fast] = apply_rule(pd.Series(val_predictions[~val_is_fast]), threshold=0.85, round_to_int=True)

        pred_df = prediction_frame(truth, final_qty)
        metrics = compute_all_metrics_fast(truth, pred_df)
        score = normalized_score(metrics, baseline_metrics)

        row = {
            "fold": fold,
            "validation_start": str(validation_weeks[0].date()),
            "validation_end": str(validation_weeks[-1].date()),
            **metrics,
            "normalized_score": score,
            "seconds": elapsed,
        }
        results.append(row)
        print(f"Fold {fold}: Score={score:.4f}, SMAPE={metrics['smape']:.2f}%, WAPE={metrics['wape']:.2f}%, RMSE={metrics['rmse']:.2f} (время: {elapsed:.1f}с)")
        pred_df.to_csv(output_dir / f"fast_slow_predictions_fold_{fold}.csv.gz", index=False)

    df_res = pd.DataFrame(results)
    df_res.to_csv(output_dir / "fast_slow_results.csv", index=False)

    print("\n" + "=" * 60)
    print("ИТОГИ МОДЕЛИ FAST/SLOW (ЧАСТЫЕ VS РЕДКИЕ ТОВАРЫ):")
    print(f"  Средний Score (3 folds): {df_res['normalized_score'].mean():.6f}")
    print(f"  Средний SMAPE:           {df_res['smape'].mean():.2f}%")
    print(f"  Средний WAPE:            {df_res['wape'].mean():.2f}%")
    print(f"  Средний RMSE:            {df_res['rmse'].mean():.2f}")
    print(f"  Среднее время на фолд:   {df_res['seconds'].mean():.1f} с")
    print("=" * 60)


if __name__ == "__main__":
    main()
