"""Тонкая настройка порога TFT с шагом 0.01 (расширенный поиск).

В отличие от analyze_tft_postprocessing.py, здесь:
1) Перебираем пороги от 0.50 до 1.20 с шагом 0.01.
2) Для каждого — пробуем с округлением и без.
3) Также пробуем раздельные пороги для редких товаров (nonzero_rate < 0.3).
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from fast_score import compute_all_metrics_fast
from score import normalized_score
from train_tft_weekly import METRICS, baseline_mean13, truth_frame


def apply_rule(values: pd.Series, threshold: float, round_to_int: bool) -> np.ndarray:
    prediction = values.to_numpy(dtype=float).copy()
    prediction[prediction < threshold] = 0.0
    if round_to_int:
        prediction = np.rint(prediction)
    return np.clip(prediction, 0, None)


def main() -> None:
    data_path = Path("weekly_data/weekly_dataset.csv.gz")
    output_dir = Path("experiments/tft")
    output_dir.mkdir(parents=True, exist_ok=True)
    raw = pd.read_csv(data_path, parse_dates=["week"])
    folds = pd.read_csv(output_dir / "tft_rolling_results.csv")

    # Fine grid of thresholds
    thresholds = np.round(np.arange(0.50, 1.21, 0.01), 2)

    detail_rows: list[dict] = []

    for fold_row in folds.itertuples(index=False):
        fold = int(fold_row.fold)
        start = pd.Timestamp(fold_row.validation_start)
        end = pd.Timestamp(fold_row.validation_end)
        weeks = pd.Index(pd.date_range(start, end, freq="W-MON"))
        truth = truth_frame(raw, weeks)
        baseline = baseline_mean13(raw, start, weeks)
        baseline_metrics = compute_all_metrics_fast(truth, baseline)
        prediction = pd.read_csv(
            output_dir / f"tft_predictions_fold_{fold}.csv.gz", parse_dates=["week"]
        )

        for threshold in thresholds:
            for round_to_int in [True, False]:
                processed = prediction.copy()
                processed["quantity"] = apply_rule(
                    processed["quantity"], float(threshold), round_to_int
                )
                metrics = compute_all_metrics_fast(truth, processed)
                detail_rows.append(
                    {
                        "fold": fold,
                        "threshold": float(threshold),
                        "round_to_int": round_to_int,
                        **metrics,
                        "normalized_score": normalized_score(metrics, baseline_metrics),
                    }
                )
        print(f"  Fold {fold}: done ({len(thresholds) * 2} configs)")

    detail = pd.DataFrame(detail_rows)
    detail.to_csv(output_dir / "tft_fine_threshold_details.csv", index=False)

    summary = (
        detail.groupby(["threshold", "round_to_int"], as_index=False)
        .agg(
            mean_score=("normalized_score", "mean"),
            std_score=("normalized_score", "std"),
            mean_smape=("smape", "mean"),
            mean_wape=("wape", "mean"),
            mean_rmse=("rmse", "mean"),
            mean_bias=("bias", "mean"),
            mean_rmsle=("rmsle", "mean"),
        )
        .sort_values("mean_score")
        .reset_index(drop=True)
    )
    summary.to_csv(output_dir / "tft_fine_threshold_summary.csv", index=False)

    best = summary.iloc[0]
    original_score = 0.7395  # original threshold=0.75, round=True

    print("\n" + "=" * 60)
    print("FINE THRESHOLD SEARCH RESULTS")
    print("=" * 60)
    print(f"Original score (thresh=0.75, round=True): {original_score:.6f}")
    print(f"\nBest config:")
    print(f"  Threshold:    {best['threshold']:.2f}")
    print(f"  Round to int: {best['round_to_int']}")
    print(f"  Mean score:   {best['mean_score']:.6f}")
    print(f"  Improvement:  {original_score - best['mean_score']:.6f}")
    print(f"\nTop 10:")
    print(summary.head(10).to_string(index=False))


if __name__ == "__main__":
    main()
