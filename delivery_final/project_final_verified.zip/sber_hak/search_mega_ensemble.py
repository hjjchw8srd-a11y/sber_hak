"""Комплексный поиск мега-ансамбля по всем 5 моделям:
TFT, LightGBM, CatBoost, TiDE, NHITS.

Ищет лучшее взвешивание на 3 фолдах кросс-валидации.
"""

from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd

from fast_score import compute_all_metrics_fast
from score import normalized_score
from run_weekly_feature_experiments import HORIZON, WeeklyMatrices, make_truth
from train_tft_weekly import baseline_mean13
from analyze_tft_postprocessing import apply_rule


def main() -> None:
    data = pd.read_csv("weekly_data/weekly_dataset.csv.gz", parse_dates=["week"])
    matrices = WeeklyMatrices(data)
    latest_origin = len(matrices.weeks) - HORIZON
    folds = 3
    fold_step = HORIZON

    keys = ["week", "warehouse_name", "article"]
    fold_data = []

    for fold in range(folds):
        origin = latest_origin - fold * fold_step
        validation_weeks = matrices.weeks[origin : origin + HORIZON]
        truth = make_truth(matrices, origin)
        truth["week"] = pd.to_datetime(truth["week"]).dt.strftime("%Y-%m-%d")

        baseline = baseline_mean13(data, pd.Timestamp(validation_weeks[0]), pd.Index(validation_weeks))
        baseline["week"] = pd.to_datetime(baseline["week"]).dt.strftime("%Y-%m-%d")
        baseline_metrics = compute_all_metrics_fast(truth, baseline)

        # 1. TFT
        p_tft = pd.read_csv(f"experiments/tft/tft_predictions_fold_{fold}.csv.gz")
        p_tft["week"] = pd.to_datetime(p_tft["week"]).dt.strftime("%Y-%m-%d")
        p_tft_qty = apply_rule(p_tft["quantity"], threshold=0.75, round_to_int=False)

        # 2. LightGBM
        p_lgbm = pd.read_csv(f"experiments/benchmarks/lgbm/lgbm_predictions_fold_{fold}.csv.gz")
        p_lgbm["week"] = pd.to_datetime(p_lgbm["week"]).dt.strftime("%Y-%m-%d")

        # 3. CatBoost
        p_cb = pd.read_csv(f"experiments/benchmarks/catboost/catboost_predictions_fold_{fold}.csv.gz")
        p_cb["week"] = pd.to_datetime(p_cb["week"]).dt.strftime("%Y-%m-%d")

        # 4. TiDE
        p_tide = pd.read_csv(f"experiments/benchmarks/tide/tide_predictions_fold_{fold}.csv.gz")
        p_tide["week"] = pd.to_datetime(p_tide["week"]).dt.strftime("%Y-%m-%d")

        # 5. NHITS
        p_nhits = pd.read_csv(f"experiments/benchmarks/nhits/nhits_predictions_fold_{fold}.csv.gz")
        p_nhits["week"] = pd.to_datetime(p_nhits["week"]).dt.strftime("%Y-%m-%d")

        merged = truth[keys].copy()
        merged["qty_truth"] = truth["quantity"].values
        merged["tft"] = p_tft_qty
        merged["lgbm"] = p_lgbm["quantity"].values
        merged["cb"] = p_cb["quantity"].values
        merged["tide"] = p_tide["quantity"].values
        merged["nhits"] = p_nhits["quantity"].values

        fold_data.append({
            "truth": truth,
            "baseline_metrics": baseline_metrics,
            "merged": merged,
        })

    print("Данные всех 5 моделей успешно загружены!")

    # Генерируем сетку весов
    candidates = []

    # Тройные ансамбли: TFT + LGBM + CatBoost
    for w_tft in np.arange(0.2, 0.7, 0.05):
        for w_lgbm in np.arange(0.1, 0.7, 0.05):
            w_cb = round(1.0 - w_tft - w_lgbm, 2)
            if 0.0 <= w_cb <= 0.5:
                candidates.append({"tft": w_tft, "lgbm": w_lgbm, "cb": w_cb, "tide": 0.0, "nhits": 0.0})

    # Четверные ансамбли: TFT + LGBM + CatBoost + TiDE
    for w_tft in [0.35, 0.40, 0.45]:
        for w_lgbm in [0.30, 0.35, 0.40]:
            for w_cb in [0.15, 0.20, 0.25]:
                w_tide = round(1.0 - w_tft - w_lgbm - w_cb, 2)
                if 0.05 <= w_tide <= 0.20:
                    candidates.append({"tft": w_tft, "lgbm": w_lgbm, "cb": w_cb, "tide": w_tide, "nhits": 0.0})

    print(f"Всего конфигураций для оценки: {len(candidates)}")

    results = []
    for cfg in candidates:
        w_tft = cfg["tft"]
        w_lgbm = cfg["lgbm"]
        w_cb = cfg["cb"]
        w_tide = cfg["tide"]
        w_nhits = cfg["nhits"]

        scores = []
        metrics_list = []

        for fd in fold_data:
            df = fd["merged"]
            pred_vals = (
                w_tft * df["tft"].values
                + w_lgbm * df["lgbm"].values
                + w_cb * df["cb"].values
                + w_tide * df["tide"].values
                + w_nhits * df["nhits"].values
            )
            final_pred = np.rint(np.clip(pred_vals, 0, None))
            eval_df = df[keys].copy()
            eval_df["quantity"] = final_pred

            m = compute_all_metrics_fast(fd["truth"], eval_df)
            sc = normalized_score(m, fd["baseline_metrics"])
            scores.append(sc)
            metrics_list.append(m)

        mean_sc = float(np.mean(scores))
        results.append({
            "tft": round(w_tft, 2),
            "lgbm": round(w_lgbm, 2),
            "cb": round(w_cb, 2),
            "tide": round(w_tide, 2),
            "mean_score": mean_sc,
            "std_score": float(np.std(scores)),
            "smape": float(np.mean([m["smape"] for m in metrics_list])),
            "wape": float(np.mean([m["wape"] for m in metrics_list])),
            "rmse": float(np.mean([m["rmse"] for m in metrics_list])),
            "bias": float(np.mean([m["bias"] for m in metrics_list])),
        })

    df_res = pd.DataFrame(results).sort_values("mean_score").reset_index(drop=True)
    df_res.to_csv("experiments/benchmarks/mega_ensemble_search.csv", index=False)

    print("\n" + "=" * 70)
    print("ТОП-10 КОНФИГУРАЦИЙ МЕГА-АНСАМБЛЯ:")
    print("=" * 70)
    print(df_res.head(10).to_string(index=False))

    best = df_res.iloc[0]
    print("\n" + "=" * 70)
    print("ЛУЧШАЯ КОНФИГУРАЦИЯ:")
    print(f"  TFT:   {best['tft']:.2f}")
    print(f"  LGBM:  {best['lgbm']:.2f}")
    print(f"  CB:    {best['cb']:.2f}")
    print(f"  TiDE:  {best['tide']:.2f}")
    print(f"  SCORE: {best['mean_score']:.6f}  (SMAPE={best['smape']:.2f}%, WAPE={best['wape']:.2f}%)")
    print("=" * 70)


if __name__ == "__main__":
    main()
