"""Оценка ансамбля: Модель Fast/Slow + TFT."""

from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd

from fast_score import compute_all_metrics_fast
from score import normalized_score
from run_weekly_feature_experiments import HORIZON, WeeklyMatrices, make_truth
from train_tft_weekly import baseline_mean13


def main() -> None:
    data = pd.read_csv("weekly_data/weekly_dataset.csv.gz", parse_dates=["week"])
    matrices = WeeklyMatrices(data)
    latest_origin = len(matrices.weeks) - HORIZON
    keys = ["week", "warehouse_name", "article"]

    for w_fs in [0.2, 0.3, 0.4, 0.5, 0.6]:
        w_tft = round(1.0 - w_fs, 2)
        scores = []
        for fold in range(3):
            origin = latest_origin - fold * HORIZON
            val_weeks = matrices.weeks[origin : origin + HORIZON]
            truth = make_truth(matrices, origin)
            truth["week"] = pd.to_datetime(truth["week"]).dt.strftime("%Y-%m-%d")

            baseline = baseline_mean13(data, pd.Timestamp(val_weeks[0]), pd.Index(val_weeks))
            baseline["week"] = pd.to_datetime(baseline["week"]).dt.strftime("%Y-%m-%d")
            base_m = compute_all_metrics_fast(truth, baseline)

            p_tft = pd.read_csv(f"experiments/tft/tft_predictions_fold_{fold}.csv.gz")
            p_tft["week"] = pd.to_datetime(p_tft["week"]).dt.strftime("%Y-%m-%d")

            p_fs = pd.read_csv(f"experiments/benchmarks/fast_slow/fast_slow_predictions_fold_{fold}.csv.gz")
            p_fs["week"] = pd.to_datetime(p_fs["week"]).dt.strftime("%Y-%m-%d")

            blend = w_tft * p_tft["quantity"].values + w_fs * p_fs["quantity"].values
            blend = np.rint(np.clip(blend, 0, None))
            eval_df = truth[keys].copy()
            eval_df["quantity"] = blend

            m = compute_all_metrics_fast(truth, eval_df)
            sc = normalized_score(m, base_m)
            scores.append(sc)

        print(f"TFT {w_tft:.2f} + FastSlow {w_fs:.2f}: mean Score = {np.mean(scores):.6f}")


if __name__ == "__main__":
    main()
