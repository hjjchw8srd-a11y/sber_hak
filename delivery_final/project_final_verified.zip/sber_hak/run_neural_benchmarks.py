"""Бенчмарк альтернативных архитектур NeuralForecast: TiDE, NHITS, TSMixerx.

Сравниваем на тех же 3 rolling-фолдах, что и TFT.
Метрика — Min-Max Score (меньше = лучше).
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from neuralforecast import NeuralForecast
from neuralforecast.losses.pytorch import MAE
from neuralforecast.models import NHITS, TFT, TiDE, TSMixerx

from analyze_tft_postprocessing import apply_rule
from fast_score import compute_all_metrics_fast
from score import normalized_score
from train_tft_weekly import (
    FUTR_EXOG,
    HIST_EXOG,
    HORIZON,
    KEYS,
    METRICS,
    baseline_mean13,
    prediction_to_submission,
    prepare_frames,
    truth_frame,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=str, required=True, choices=["tide", "nhits", "tsmixerx", "tft"])
    parser.add_argument("--data", type=Path, default=Path("weekly_data/weekly_dataset.csv.gz"))
    parser.add_argument("--output-dir", type=Path, default=Path("experiments/benchmarks"))
    parser.add_argument("--folds", type=int, default=3)
    parser.add_argument("--fold-step", type=int, default=HORIZON)
    parser.add_argument("--input-size", type=int, default=26)
    parser.add_argument("--max-steps", type=int, default=300)
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--windows-batch-size", type=int, default=512)
    parser.add_argument("--learning-rate", type=float, default=1e-3)
    parser.add_argument("--val-check-steps", type=int, default=50)
    parser.add_argument("--patience", type=int, default=3)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--threshold", type=float, default=0.75)
    return parser.parse_args()


def create_model(model_name: str, args: argparse.Namespace, static_columns: list[str], n_series: int, device: str):
    common = dict(
        h=HORIZON,
        input_size=args.input_size,
        stat_exog_list=static_columns,
        hist_exog_list=HIST_EXOG,
        futr_exog_list=FUTR_EXOG,
        loss=MAE(),
        valid_loss=MAE(),
        max_steps=args.max_steps,
        learning_rate=args.learning_rate,
        val_check_steps=args.val_check_steps,
        early_stop_patience_steps=args.patience,
        batch_size=args.batch_size,
        valid_batch_size=args.batch_size,
        windows_batch_size=args.windows_batch_size,
        inference_windows_batch_size=args.windows_batch_size,
        scaler_type="robust",
        random_seed=args.seed,
        accelerator=device,
        devices=1,
        precision="16-mixed" if device == "gpu" else "32-true",
        enable_progress_bar=False,
        enable_checkpointing=False,
        logger=False,
    )

    if model_name == "tide":
        return TiDE(
            hidden_size=256,
            decoder_output_dim=16,
            temporal_decoder_dim=64,
            dropout=0.2,
            alias="TiDE",
            **common,
        )
    elif model_name == "nhits":
        return NHITS(
            mlp_units=[[256, 256], [256, 256], [256, 256]],
            n_pool_kernel_size=[2, 2, 1],
            n_freq_downsample=[4, 2, 1],
            alias="NHITS",
            **common,
        )
    elif model_name == "tsmixerx":
        return TSMixerx(
            n_series=n_series,
            n_block=2,
            ff_dim=64,
            dropout=0.1,
            revin=True,
            alias="TSMixerx",
            **common,
        )
    elif model_name == "tft":
        return TFT(
            hidden_size=32,
            n_head=4,
            dropout=0.1,
            alias="TFT",
            **common,
        )
    else:
        raise ValueError(f"Неизвестная модель: {model_name}")


def main() -> None:
    args = parse_args()
    model_dir = args.output_dir / args.model
    model_dir.mkdir(parents=True, exist_ok=True)

    if torch.cuda.is_available():
        torch.set_float32_matmul_precision("medium")
    device = "gpu" if torch.cuda.is_available() else "cpu"
    print(f"=== Запуск бенчмарка: модель={args.model.upper()}, устройство={device} ===")

    raw = pd.read_csv(args.data, parse_dates=["week"])
    temporal, static_df, static_columns = prepare_frames(raw)
    n_series = int(temporal["unique_id"].nunique())
    weeks = pd.Index(sorted(raw["week"].unique()))
    latest_origin = len(weeks) - HORIZON
    origins = [latest_origin - fold * args.fold_step for fold in range(args.folds)]

    results_raw = []
    results_postproc = []

    for fold, origin in enumerate(origins):
        validation_weeks = weeks[origin : origin + HORIZON]
        cutoff = pd.Timestamp(validation_weeks[0])
        train_df = temporal[temporal["ds"] < cutoff].copy()
        future_df = temporal[temporal["ds"].isin(validation_weeks)][["unique_id", "ds", *FUTR_EXOG]].copy()
        truth = truth_frame(raw, validation_weeks)
        baseline = baseline_mean13(raw, cutoff, validation_weeks)
        baseline_metrics = compute_all_metrics_fast(truth, baseline)

        print(f"\n--- Fold {fold}: {validation_weeks[0].date()} .. {validation_weeks[-1].date()} ---")
        model = create_model(args.model, args, static_columns, n_series, device)
        nf = NeuralForecast(models=[model], freq="W-MON")

        started = time.perf_counter()
        nf.fit(df=train_df, static_df=static_df, val_size=HORIZON)
        prediction = prediction_to_submission(nf.predict(futr_df=future_df), raw)
        elapsed = time.perf_counter() - started

        # Сырой прогноз
        metrics_raw = compute_all_metrics_fast(truth, prediction)
        score_raw = normalized_score(metrics_raw, baseline_metrics)
        row_raw = {
            "model": args.model,
            "fold": fold,
            "validation_start": str(validation_weeks[0].date()),
            "validation_end": str(validation_weeks[-1].date()),
            **metrics_raw,
            "normalized_score": score_raw,
            "seconds": elapsed,
        }
        results_raw.append(row_raw)
        print(f"  Сырой {args.model}: Score={score_raw:.4f}, SMAPE={metrics_raw['smape']:.2f}%, WAPE={metrics_raw['wape']:.2f}% (время: {elapsed:.1f}с)")

        # Прогноз с постобработкой (threshold + round)
        pred_post = prediction.copy()
        pred_post["quantity"] = apply_rule(pred_post["quantity"], threshold=args.threshold, round_to_int=True)
        metrics_post = compute_all_metrics_fast(truth, pred_post)
        score_post = normalized_score(metrics_post, baseline_metrics)
        row_post = {
            "model": f"{args.model}_postproc",
            "fold": fold,
            "validation_start": str(validation_weeks[0].date()),
            "validation_end": str(validation_weeks[-1].date()),
            **metrics_post,
            "normalized_score": score_post,
            "seconds": elapsed,
        }
        results_postproc.append(row_post)
        print(f"  Постобработка ({args.threshold} + round): Score={score_post:.4f}, SMAPE={metrics_post['smape']:.2f}%, WAPE={metrics_post['wape']:.2f}%")

        # Сохранение прогноза фолда
        pred_post.to_csv(model_dir / f"{args.model}_predictions_fold_{fold}.csv.gz", index=False)

        del nf, model
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    df_raw = pd.DataFrame(results_raw)
    df_post = pd.DataFrame(results_postproc)
    df_raw.to_csv(model_dir / f"{args.model}_results_raw.csv", index=False)
    df_post.to_csv(model_dir / f"{args.model}_results_postproc.csv", index=False)

    print("\n" + "=" * 60)
    print(f"ИТОГИ ДЛЯ {args.model.upper()}:")
    print(f"  Средний сырой Score:          {df_raw['normalized_score'].mean():.6f}")
    print(f"  Средний Score c постобработкой: {df_post['normalized_score'].mean():.6f}")
    print(f"  Среднее время на фолд:         {df_raw['seconds'].mean():.1f} с")
    print("=" * 60)


if __name__ == "__main__":
    main()
