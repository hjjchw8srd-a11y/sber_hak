"""Генерация красивых диагностических графиков (Факт vs Прогноз) для эксперта.

Отрисовывает 3 характерных ряда:
1. Стабильный ходовой товар
2. Редкий товар с редкими продажами (intermittent demand)
3. Растущий товар с трендом
Показывает факт и прогнозы: TFT, LightGBM, CatBoost и Мега-Ансамбль.
"""

from __future__ import annotations
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from run_weekly_feature_experiments import HORIZON, WeeklyMatrices, make_truth


def main() -> None:
    output_dir = Path("experiments/forecast_diagnostics")
    output_dir.mkdir(parents=True, exist_ok=True)

    data = pd.read_csv("weekly_data/weekly_dataset.csv.gz", parse_dates=["week"])
    matrices = WeeklyMatrices(data)
    fold = 0
    origin = len(matrices.weeks) - HORIZON
    val_weeks = matrices.weeks[origin : origin + HORIZON]

    truth = make_truth(matrices, origin)
    truth["week"] = pd.to_datetime(truth["week"])

    # Загружаем прогнозы фолда 0
    p_tft = pd.read_csv("experiments/tft/tft_predictions_fold_0.csv.gz", parse_dates=["week"])
    p_lgbm = pd.read_csv("experiments/benchmarks/lgbm/lgbm_predictions_fold_0.csv.gz", parse_dates=["week"])
    p_cb = pd.read_csv("experiments/benchmarks/catboost/catboost_predictions_fold_0.csv.gz", parse_dates=["week"])

    # Мега-ансамбль (45% TFT + 40% LGBM + 15% CB)
    ensemble_qty = np.rint(np.clip(
        0.45 * p_tft["quantity"].values + 0.40 * p_lgbm["quantity"].values + 0.15 * p_cb["quantity"].values,
        0, None
    ))

    # Выбираем 3 показательных ряда:
    # 1. Популярный товар (большой объем)
    # 2. Редкий товар (много нулей)
    # 3. Средний товар с трендом
    totals = truth.groupby("article")["quantity"].sum()
    popular_art = totals.sort_values(ascending=False).index[0]
    sparse_candidates = totals[(totals > 0) & (totals <= 5)].index
    sparse_art = sparse_candidates[len(sparse_candidates) // 2]
    mid_candidates = totals[(totals >= 15) & (totals <= 35)].index
    mid_art = mid_candidates[len(mid_candidates) // 2]

    selected = [
        ("Популярный товар (высокий объем)", popular_art),
        ("Товар со средним спросом", mid_art),
        ("Редкий товар (intermittent demand)", sparse_art),
    ]

    fig, axes = plt.subplots(3, 1, figsize=(11, 10), sharex=True)
    history_weeks = matrices.weeks[origin - 13 : origin]

    for idx, (title, art) in enumerate(selected):
        ax = axes[idx]
        wh = "warehouse_name_0"

        # История (последние 13 недель до точки отсечки)
        hist_df = data[(data["warehouse_name"] == wh) & (data["article"] == art) & (data["week"].isin(history_weeks))].sort_values("week")

        # Факты на валидации
        t_mask = (truth["warehouse_name"] == wh) & (truth["article"] == art)
        val_true = truth[t_mask].sort_values("week")

        # Прогнозы
        ens_vals = ensemble_qty[t_mask.values]
        tft_vals = p_tft.loc[t_mask, "quantity"].values
        lgbm_vals = p_lgbm.loc[t_mask, "quantity"].values

        # Рисуем
        ax.plot(hist_df["week"], hist_df["quantity"], label="История продаж", color="#4A5568", linewidth=1.8, marker="o", markersize=3)
        ax.plot(val_true["week"], val_true["quantity"], label="Факт (Holdout)", color="#000000", linewidth=2.2, marker="s", markersize=4)
        ax.plot(val_true["week"], ens_vals, label="Мега-Ансамбль (LGBM+TFT+CB)", color="#2B6CB0", linewidth=2.5, linestyle="-", marker="^", markersize=5)
        ax.plot(val_true["week"], tft_vals, label="TFT (Нейросеть)", color="#C53030", linewidth=1.5, linestyle="--", alpha=0.7)
        ax.plot(val_true["week"], lgbm_vals, label="LightGBM (Бустинг)", color="#2F855A", linewidth=1.5, linestyle=":", alpha=0.7)

        ax.axvline(val_weeks[0], color="red", linestyle="--", alpha=0.5, label="Точка старта прогноза")
        ax.set_title(f"{title} ({wh} / {art})", fontsize=11, fontweight="bold")
        ax.set_ylabel("Штук в неделю")
        ax.grid(True, alpha=0.3)
        if idx == 0:
            ax.legend(loc="upper left", framealpha=0.9, fontsize=9)

    plt.xlabel("Дата недели")
    plt.tight_layout()
    out_img = output_dir / "expert_forecast_comparison.png"
    plt.savefig(out_img, dpi=200)
    plt.close()
    print(f"График успешно сохранен: {out_img}")


if __name__ == "__main__":
    main()
