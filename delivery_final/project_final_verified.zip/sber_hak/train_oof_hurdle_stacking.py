"""OOF Hurdle-Стэкинг (Приоритет №1).

Двухэтапная мета-модель:
1. Мета-классификатор вероятности продажи P(sale > 0)
2. Мета-регрессор объема продаж при условии наличия продажи (y | sale > 0)
3. Обучение строго на OOF-прогнозах базовых моделей (TFT, LightGBM, CatBoost, Per-Category)
4. Адаптивные пороги по режимам спроса (регулярный, прерывистый, редкий)
"""

from __future__ import annotations
from pathlib import Path
import time
import numpy as np
import pandas as pd
import lightgbm as lgb
from catboost import CatBoostClassifier, CatBoostRegressor

from fast_score import compute_all_metrics_fast
from score import normalized_score
from run_weekly_feature_experiments import (
    HORIZON,
    KEYS,
    CAT_COLUMNS,
    WeeklyMatrices,
    columns_for_experiment,
    make_truth,
    prediction_frame,
)
from train_tft_weekly import baseline_mean13


def extract_base_predictions_and_features(
    data: pd.DataFrame,
    matrices: WeeklyMatrices,
    folds: int = 3,
    output_dir: Path = Path("experiments/stacking"),
) -> list[pd.DataFrame]:
    output_dir.mkdir(parents=True, exist_ok=True)
    latest_origin = len(matrices.weeks) - HORIZON
    fold_step = HORIZON
    feature_columns = columns_for_experiment("base_calendar_network")
    cat_columns = [c for c in CAT_COLUMNS if c in feature_columns]

    fold_dfs = []

    for fold in range(folds):
        meta_file = output_dir / f"meta_features_fold_{fold}.csv.gz"
        if meta_file.exists():
            print(f"Загрузка готовых мета-признаков фолда {fold} из {meta_file}...")
            df_fold = pd.read_csv(meta_file)
            fold_dfs.append(df_fold)
            continue

        print(f"\n--- Генерация OOF признаков для фолда {fold} ---")
        origin = latest_origin - fold * fold_step
        validation_weeks = matrices.weeks[origin : origin + HORIZON]
        truth = make_truth(matrices, origin)
        truth["week"] = pd.to_datetime(truth["week"]).dt.strftime("%Y-%m-%d")

        # Обучающая выборка для базовых моделей
        latest_train_origin = origin - HORIZON
        earliest_train_origin = max(26, latest_train_origin - 17)
        train_origins = np.arange(earliest_train_origin, latest_train_origin + 1)
        train_df, target_arr, _ = matrices.make_rows(train_origins, 350_000, seed=42 + fold)
        val_df, val_target, _ = matrices.make_rows(np.array([origin]), None)

        X_train = train_df[feature_columns].copy()
        X_val = val_df[feature_columns].copy()
        for col in cat_columns:
            X_train[col] = X_train[col].astype("category")
            X_val[col] = X_val[col].astype("category")

        # 1. LightGBM Base
        print("  Обучение LightGBM (Classifier + Regressor)...")
        lgb_clf = lgb.LGBMClassifier(
            n_estimators=160,
            learning_rate=0.0495,
            num_leaves=29,
            min_child_samples=51,
            subsample=0.727,
            colsample_bytree=0.728,
            reg_alpha=0.0164,
            reg_lambda=0.0057,
            random_state=42,
            verbosity=-1,
            n_jobs=-1,
        )
        lgb_clf.fit(X_train, (target_arr > 0).astype(int))
        p_sale_lgb = lgb_clf.predict_proba(X_val)[:, 1]

        pos_mask = target_arr > 0
        lgb_reg = lgb.LGBMRegressor(
            n_estimators=160,
            learning_rate=0.0495,
            num_leaves=29,
            min_child_samples=51,
            subsample=0.727,
            colsample_bytree=0.728,
            reg_alpha=0.0164,
            reg_lambda=0.0057,
            random_state=42,
            verbosity=-1,
            n_jobs=-1,
        )
        lgb_reg.fit(X_train.loc[pos_mask], np.log1p(target_arr[pos_mask]))
        q_cond_lgb = np.expm1(lgb_reg.predict(X_val)).clip(min=0)

        # 2. CatBoost Base
        print("  Обучение CatBoost (Classifier + Regressor)...")
        cb_common = {
            "iterations": 160,
            "depth": 7,
            "learning_rate": 0.08,
            "random_seed": 42,
            "verbose": False,
            "allow_writing_files": False,
            "thread_count": -1,
        }
        cb_clf = CatBoostClassifier(loss_function="Logloss", **cb_common)
        cb_clf.fit(train_df[feature_columns], (target_arr > 0).astype(np.int8), cat_features=cat_columns)
        p_sale_cb = cb_clf.predict_proba(val_df[feature_columns])[:, 1]

        cb_reg = CatBoostRegressor(loss_function="RMSE", **cb_common)
        cb_reg.fit(train_df.loc[pos_mask, feature_columns], np.log1p(target_arr[pos_mask]), cat_features=cat_columns)
        q_cond_cb = np.expm1(cb_reg.predict(val_df[feature_columns])).clip(min=0)

        # 3. TFT Base (сырой непрерывный прогноз)
        tft_path = Path(f"experiments/tft/tft_predictions_fold_{fold}.csv.gz")
        print(f"  Чтение TFT прогноза из {tft_path}...")
        tft_df = pd.read_csv(tft_path)
        raw_tft = tft_df["quantity"].values

        # 4. Per-Category Base
        per_cat_path = Path(f"experiments/benchmarks/per_category/per_cat_predictions_fold_{fold}.csv.gz")
        print(f"  Чтение Per-Category прогноза из {per_cat_path}...")
        per_cat_df = pd.read_csv(per_cat_path)
        raw_per_cat = per_cat_df["quantity"].values

        # Сборка мета-датафрейма для фолда
        meta_df = val_df[[
            "warehouse_name", "article", "category_lvl_1", "horizon",
            "quantity_nonzero_rate_13", "weeks_since_last_sale", "current_zero_streak",
            "quantity_mean_4", "quantity_mean_13", "quantity_mean_26",
            "quantity_min_13", "quantity_max_13", "quantity_cv_13",
            "article_network_sales_mean_13_log", "stock_end_lag_1", "stock_missing_lag_1"
        ]].copy()

        test_weeks = np.repeat(matrices.weeks[origin : origin + HORIZON].to_numpy(), matrices.n_pairs)
        meta_df["week"] = pd.to_datetime(test_weeks).strftime("%Y-%m-%d")
        meta_df["target"] = val_target
        meta_df["fold"] = fold

        # Добавление признаков от моделей
        meta_df["p_sale_lgb"] = p_sale_lgb
        meta_df["q_cond_lgb"] = q_cond_lgb
        meta_df["exp_lgb"] = p_sale_lgb * q_cond_lgb

        meta_df["p_sale_cb"] = p_sale_cb
        meta_df["q_cond_cb"] = q_cond_cb
        meta_df["exp_cb"] = p_sale_cb * q_cond_cb

        meta_df["raw_tft"] = raw_tft
        meta_df["raw_per_cat"] = raw_per_cat

        # Консенсус моделей
        meta_df["p_mean"] = (p_sale_lgb + p_sale_cb) / 2.0
        meta_df["q_cond_mean"] = (q_cond_lgb + q_cond_cb + raw_tft) / 3.0
        meta_df["q_cond_max"] = np.maximum.reduce([q_cond_lgb, q_cond_cb, raw_tft])

        meta_df.to_csv(meta_file, index=False)
        print(f"  Сохранен {meta_file} (строк: {len(meta_df)})")
        fold_dfs.append(meta_df)

    return fold_dfs


def run_oof_stacking_validation(
    fold_dfs: list[pd.DataFrame],
    data: pd.DataFrame,
    matrices: WeeklyMatrices,
) -> None:
    print("\n" + "=" * 70)
    print("=== ОЦЕНКА OOF HURDLE-СТЭКИНГА (LEAVE-ONE-FOLD-OUT) ===")
    print("=" * 70)

    folds = len(fold_dfs)
    latest_origin = len(matrices.weeks) - HORIZON
    fold_step = HORIZON

    meta_features_clf = [
        "p_sale_lgb", "p_sale_cb", "p_mean",
        "raw_tft", "raw_per_cat",
        "exp_lgb", "exp_cb", "q_cond_mean",
        "quantity_nonzero_rate_13", "weeks_since_last_sale", "current_zero_streak",
        "quantity_mean_4", "quantity_mean_13", "quantity_cv_13",
        "article_network_sales_mean_13_log", "stock_end_lag_1", "stock_missing_lag_1",
        "horizon"
    ]

    meta_features_reg = [
        "q_cond_lgb", "q_cond_cb", "raw_tft", "raw_per_cat",
        "q_cond_mean", "q_cond_max",
        "quantity_mean_4", "quantity_mean_13", "quantity_mean_26", "quantity_max_13",
        "article_network_sales_mean_13_log",
        "horizon"
    ]

    cat_cols_clf = ["category_lvl_1", "warehouse_name"]

    stacking_results = []
    baseline_ensemble_results = []

    for val_fold in range(folds):
        print(f"\nВалидация на фолде {val_fold} (обучение мета-моделей на остальных фолдах):")
        train_folds_df = pd.concat([fold_dfs[f] for f in range(folds) if f != val_fold], ignore_index=True)
        val_fold_df = fold_dfs[val_fold].copy()

        # Подготовка данных для мета-моделей
        X_meta_train_clf = train_folds_df[meta_features_clf + cat_cols_clf].copy()
        y_meta_train_clf = (train_folds_df["target"] > 0).astype(int)

        X_meta_val_clf = val_fold_df[meta_features_clf + cat_cols_clf].copy()

        for c in cat_cols_clf:
            X_meta_train_clf[c] = X_meta_train_clf[c].astype("category")
            X_meta_val_clf[c] = X_meta_val_clf[c].astype("category")

        # 1. Мета-классификатор P(sale > 0)
        meta_clf = lgb.LGBMClassifier(
            n_estimators=100,
            learning_rate=0.05,
            num_leaves=20,
            min_child_samples=50,
            random_state=42,
            verbosity=-1,
            n_jobs=-1,
        )
        meta_clf.fit(X_meta_train_clf, y_meta_train_clf)
        p_sale_meta = meta_clf.predict_proba(X_meta_val_clf)[:, 1]

        # 2. Мета-регрессор для положительных продаж (MAE Loss для прямого снижения SMAPE/WAPE)
        pos_train_mask = train_folds_df["target"] > 0
        X_meta_train_reg = train_folds_df.loc[pos_train_mask, meta_features_reg].copy()
        y_meta_train_reg = train_folds_df.loc[pos_train_mask, "target"].values

        X_meta_val_reg = val_fold_df[meta_features_reg].copy()

        meta_reg = lgb.LGBMRegressor(
            objective="regression_l1",  # L1 loss = MAE, напрямую оптимизирует медиану и SMAPE
            n_estimators=120,
            learning_rate=0.05,
            num_leaves=25,
            min_child_samples=40,
            random_state=42,
            verbosity=-1,
            n_jobs=-1,
        )
        meta_reg.fit(X_meta_train_reg, y_meta_train_reg)
        q_cond_meta = meta_reg.predict(X_meta_val_reg).clip(min=0)

        # 3. Адаптивное пороговое правило по режимам спроса
        # Регулярный спрос (rate >= 0.70): низкий порог 0.35, чтобы не пропустить продажи
        # Прерывистый спрос (0.20 <= rate < 0.70): порог 0.50
        # Редкий спрос (rate < 0.20): порог 0.65, чтобы не плодить 200% штраф SMAPE
        zr = val_fold_df["quantity_nonzero_rate_13"].values
        th_adaptive = np.where(zr >= 0.70, 0.35, np.where(zr >= 0.20, 0.50, 0.65))

        # Формирование итогового прогноза
        raw_pred = p_sale_meta * q_cond_meta * 1.05  # калибровка тренда
        pred_qty = np.where(p_sale_meta < th_adaptive, 0.0, np.round(raw_pred))

        # Истинные значения и бейзлайн
        origin = latest_origin - val_fold * fold_step
        validation_weeks = matrices.weeks[origin : origin + HORIZON]
        truth = make_truth(matrices, origin)
        truth["week"] = pd.to_datetime(truth["week"]).dt.strftime("%Y-%m-%d")

        baseline = baseline_mean13(data, pd.Timestamp(validation_weeks[0]), pd.Index(validation_weeks))
        baseline["week"] = pd.to_datetime(baseline["week"]).dt.strftime("%Y-%m-%d")
        baseline_metrics = compute_all_metrics_fast(truth, baseline)

        pred_df = val_fold_df[["week", "warehouse_name", "article"]].copy()
        pred_df["quantity"] = pred_qty

        m_stack = compute_all_metrics_fast(truth, pred_df)
        sc_stack = normalized_score(m_stack, baseline_metrics)
        stacking_results.append({
            "fold": val_fold,
            "score": sc_stack,
            "smape": m_stack["smape"],
            "wape": m_stack["wape"],
            "rmse": m_stack["rmse"],
            "bias": m_stack["bias"],
            "rmsle": m_stack["rmsle"],
        })
        print(f"  [Hurdle Stacking] Fold {val_fold}: Score={sc_stack:.6f}, SMAPE={m_stack['smape']:.2f}%, WAPE={m_stack['wape']:.2f}%, RMSE={m_stack['rmse']:.3f}, Bias={m_stack['bias']:.2f}%")

        # Для сравнения считаем текущий фиксированный ансамбль (50% TFT + 30% LGB + 10% Cat + 10% CB)
        fixed_blend = (
            0.50 * val_fold_df["raw_tft"].values +
            0.30 * val_fold_df["q_cond_lgb"].values * val_fold_df["p_sale_lgb"].values +
            0.10 * val_fold_df["raw_per_cat"].values +
            0.10 * val_fold_df["q_cond_cb"].values * val_fold_df["p_sale_cb"].values
        ) * 1.05
        fixed_qty = np.where(fixed_blend < 0.65, 0.0, np.round(fixed_blend))
        pred_fixed_df = val_fold_df[["week", "warehouse_name", "article"]].copy()
        pred_fixed_df["quantity"] = fixed_qty

        m_fixed = compute_all_metrics_fast(truth, pred_fixed_df)
        sc_fixed = normalized_score(m_fixed, baseline_metrics)
        baseline_ensemble_results.append({
            "fold": val_fold,
            "score": sc_fixed,
            "smape": m_fixed["smape"],
            "wape": m_fixed["wape"],
            "rmse": m_fixed["rmse"],
            "bias": m_fixed["bias"],
            "rmsle": m_fixed["rmsle"],
        })
        print(f"  [Прежний Ансамбль] Fold {val_fold}: Score={sc_fixed:.6f}, SMAPE={m_fixed['smape']:.2f}%, WAPE={m_fixed['wape']:.2f}%, RMSE={m_fixed['rmse']:.3f}, Bias={m_fixed['bias']:.2f}%")

    df_stack = pd.DataFrame(stacking_results)
    df_fixed = pd.DataFrame(baseline_ensemble_results)

    print("\n" + "=" * 70)
    print("ИТОГОВОЕ СРАВНЕНИЕ (СРЕДНЕЕ ПО ВСЕМ ФОЛДАМ):")
    print("=" * 70)
    print(f"Метрика     | Прежний Ансамбль | OOF Hurdle-Стэкинг | Разница (Дельта)")
    print(f"Score       | {df_fixed['score'].mean():.6f}         | {df_stack['score'].mean():.6f}           | {df_stack['score'].mean() - df_fixed['score'].mean():+.6f}")
    print(f"SMAPE (%)   | {df_fixed['smape'].mean():.2f}%           | {df_stack['smape'].mean():.2f}%             | {df_stack['smape'].mean() - df_fixed['smape'].mean():+.2f}%")
    print(f"WAPE (%)    | {df_fixed['wape'].mean():.2f}%           | {df_stack['wape'].mean():.2f}%             | {df_stack['wape'].mean() - df_fixed['wape'].mean():+.2f}%")
    print(f"RMSE        | {df_fixed['rmse'].mean():.3f}            | {df_stack['rmse'].mean():.3f}              | {df_stack['rmse'].mean() - df_fixed['rmse'].mean():+.3f}")
    print(f"Bias (%)    | {df_fixed['bias'].mean():.2f}%           | {df_stack['bias'].mean():.2f}%             | {df_stack['bias'].mean() - df_fixed['bias'].mean():+.2f}%")
    print("=" * 70)


def main() -> None:
    data = pd.read_csv("weekly_data/weekly_dataset.csv.gz", parse_dates=["week"])
    matrices = WeeklyMatrices(data)
    fold_dfs = extract_base_predictions_and_features(data, matrices, folds=3)
    run_oof_stacking_validation(fold_dfs, data, matrices)


if __name__ == "__main__":
    main()
