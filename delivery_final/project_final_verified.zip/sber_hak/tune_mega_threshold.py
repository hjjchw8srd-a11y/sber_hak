"""Тонкий подбор порога отсечения нулей для лучшего мега-ансамбля:
45% TFT + 40% LightGBM + 15% CatBoost.
"""

from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd

from fast_score import compute_all_metrics_fast
from score import normalized_score
from run_weekly_feature_experiments import HORIZON, WeeklyMatrices, make_truth
from train_tft_weekly import baseline_mean13
from analyze_tft_postprocessing import apply_rule


def main() -> None:
    data = pd.read_csv("weekly_data/weekly_dataset.csv.gz", parse_dates=["week"])
    matrices = WeeklyMatrices(data)
    latest_origin = len(matrices.weeks) - HORIZON
    folds = 3
    fold_step = HORIZON
    keys = ["week", "warehouse_name", "article"]

    fold_data = []
    for fold in range(folds):
        origin = latest_origin - fold * fold_step
        validation_weeks = matrices.weeks[origin : origin + HORIZON]
        truth = make_truth(matrices, origin)
        truth["week"] = pd.to_datetime(truth["week"]).dt.strftime("%Y-%m-%d")

        baseline = baseline_mean13(data, pd.Timestamp(validation_weeks[0]), pd.Index(validation_weeks))
        baseline["week"] = pd.to_datetime(baseline["week"]).dt.strftime("%Y-%m-%d")
        baseline_metrics = compute_all_metrics_fast(truth, baseline)

        p_tft = pd.read_csv(f"experiments/tft/tft_predictions_fold_{fold}.csv.gz")
        p_lgbm = pd.read_csv(f"experiments/benchmarks/lgbm/lgbm_predictions_fold_{fold}.csv.gz")
        p_cb = pd.read_csv(f"experiments/benchmarks/catboost/catboost_predictions_fold_{fold}.csv.gz")

        merged = truth[keys].copy()
        raw_blend = 0.45 * p_tft["quantity"].values + 0.40 * p_lgbm["quantity"].values + 0.15 * p_cb["quantity"].values
        merged["raw_blend"] = raw_blend

        fold_data.append({
            "truth": truth,
            "baseline_metrics": baseline_metrics,
            "merged": merged,
        })

    thresholds = np.arange(0.50, 1.10, 0.02)
    rows = []

    for th in thresholds:
        scores = []
        for fd in fold_data:
            df = fd["merged"]
            qty = apply_rule(df["raw_blend"], threshold=th, round_to_int=True)
            eval_df = df[keys].copy()
            eval_df["quantity"] = qty

            m = compute_all_metrics_fast(fd["truth"], eval_df)
            sc = normalized_score(m, fd["baseline_metrics"])
            scores.append(sc)

        rows.append({
            "threshold": round(th, 2),
            "mean_score": float(np.mean(scores)),
            "std_score": float(np.std(scores)),
        })

    res = pd.DataFrame(rows).sort_values("mean_score").reset_index(drop=True)
    res.to_csv("experiments/benchmarks/mega_threshold_search.csv", index=False)
    print("ТОП-10 ПОРОГОВ:")
    print(res.head(10).to_string(index=False))

    best = res.iloc[0]
    print(f"\nАБСОЛЮТНО ЛУЧШИЙ РЕЗУЛЬТАТ:")
    print(f"  Порог: {best['threshold']:.2f}")
    print(f"  Score: {best['mean_score']:.6f}")


if __name__ == "__main__":
    main()
