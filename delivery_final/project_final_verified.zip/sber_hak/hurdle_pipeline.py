"""Единый модуль конвейера прогнозирования Hurdle + Tweedie + TFT Stacking.

Содержит строго общие:
- Списки признаков (META_FEATURES_CLF, META_FEATURES_REG);
- Гиперпараметры мета-моделей (LGBMClassifier, LGBMRegressor);
- Гиперпараметры Tweedie Regressor;
- Границы режимов спроса и пороги отсечения нулей;
- Единую функцию прогнозирования compute_hurdle_forecast, используемую
  как при валидации (CV/Expanding window), так и при инференсе сабмита.
"""

from __future__ import annotations

from typing import Any
import numpy as np
import pandas as pd
import lightgbm as lgb


# =====================================================================
# ПРИЗНАКИ ДЛЯ МЕТА-МОДЕЛЕЙ (ЕДИНЫЙ НАБОР)
# =====================================================================

META_FEATURES_CLF = [
    "p_sale_lgb",
    "p_sale_cb",
    "p_mean",
    "raw_tft",
    "raw_per_cat",
    "exp_lgb",
    "exp_cb",
    "q_cond_mean",
    "quantity_nonzero_rate_13",
    "weeks_since_last_sale",
    "current_zero_streak",
    "quantity_mean_4",
    "quantity_mean_13",
    "quantity_cv_13",
    "article_network_sales_mean_13_log",
    "stock_end_lag_1",
    "stock_missing_lag_1",
    "horizon",
]

META_FEATURES_REG = [
    "q_cond_lgb",
    "q_cond_cb",
    "raw_tft",
    "raw_per_cat",
    "q_cond_mean",
    "q_cond_max",
    "quantity_mean_4",
    "quantity_mean_13",
    "quantity_mean_26",
    "quantity_max_13",
    "article_network_sales_mean_13_log",
    "horizon",
]


# =====================================================================
# ГИПЕРПАРАМЕТРЫ МОДЕЛЕЙ (ФИКСИРОВАННЫЕ)
# =====================================================================

META_CLF_PARAMS: dict[str, Any] = {
    "n_estimators": 120,
    "learning_rate": 0.05,
    "num_leaves": 20,
    "min_child_samples": 50,
    "random_state": 42,
    "verbosity": -1,
    "n_jobs": -1,
}

META_REG_PARAMS: dict[str, Any] = {
    "objective": "regression_l1",
    "n_estimators": 140,
    "learning_rate": 0.05,
    "num_leaves": 25,
    "min_child_samples": 40,
    "random_state": 42,
    "verbosity": -1,
    "n_jobs": -1,
}

TWEEDIE_REG_PARAMS: dict[str, Any] = {
    "objective": "tweedie",
    "tweedie_variance_power": 1.35,
    "n_estimators": 180,
    "learning_rate": 0.05,
    "num_leaves": 35,
    "min_child_samples": 30,
    "subsample": 0.8,
    "colsample_bytree": 0.8,
    "random_state": 42,
    "verbosity": -1,
    "n_jobs": -1,
}


# =====================================================================
# ПОРОГИ И ГРАНИЦЫ РЕЖИМОВ СПРОСА (ФИКСИРОВАННЫЕ ДО ТЕСТИРОВАНИЯ)
# =====================================================================

REGIME_REGULAR_ZR: float = 0.50       # zr >= 0.50 -> регулярный спрос
REGIME_INTERMITTENT_ZR: float = 0.15  # 0.15 <= zr < 0.50 -> прерывистый спрос
TH_REGULAR: float = 0.35              # порог отсечения для регулярного спроса
TH_INTERMITTENT: float = 0.45          # порог отсечения для прерывистого спроса
TH_RARE: float = 0.65                  # порог отсечения для редкого спроса

HIGH_DEMAND_MEAN: float = 3.0          # mean_13 >= 3.0
HIGH_DEMAND_MAX: float = 15.0          # max_13 >= 15.0
TWEEDIE_BLEND_WEIGHT: float = 0.45     # 55% stacking + 45% tweedie

EXTREME_DEMAND_MAX: float = 50.0       # max_13 >= 50.0
TWEEDIE_EXTREME_BOOST: float = 1.15

TFT_BLEND_WEIGHT: float = 0.45         # 55% adjusted_stacking + 45% tft_smooth
TFT_SCALE: float = 1.05
STACKED_SCALE: float = 1.05


# =====================================================================
# ЕДИНАЯ ФУНКЦИЯ РАСЧЕТА ПРОГНОЗА
# =====================================================================

def fit_meta_models(
    meta_train_df: pd.DataFrame,
) -> dict[str, Any]:
    """Обучает мета-классификатор и мета-регрессор на обучающих фолдах."""
    clf = lgb.LGBMClassifier(**META_CLF_PARAMS)
    y_binary = (meta_train_df["target"] > 0).astype(int)
    clf.fit(meta_train_df[META_FEATURES_CLF], y_binary)

    pos_mask = meta_train_df["target"] > 0
    reg = lgb.LGBMRegressor(**META_REG_PARAMS)
    reg.fit(
        meta_train_df.loc[pos_mask, META_FEATURES_REG],
        meta_train_df.loc[pos_mask, "target"].values,
    )

    return {"meta_clf": clf, "meta_reg": reg}


def compute_hurdle_forecast(
    meta_train_df: pd.DataFrame | None,
    eval_df: pd.DataFrame,
    variant: str = "hurdle_tweedie_tft",
    fitted_models: dict[str, Any] | None = None,
) -> tuple[np.ndarray, dict[str, Any]]:
    """Единый расчет прогноза Hurdle + Tweedie + TFT Stacking.

    Параметры:
    ----------
    meta_train_df : pd.DataFrame | None
        Датафрейм с историческими обучающими фолдами (обязателен, если fitted_models is None).
    eval_df : pd.DataFrame
        Датафрейм оцениваемого фолда или тестовой выборки, содержащий все meta-признаки,
        tweedie_pred, raw_tft, quantity_nonzero_rate_13, quantity_mean_13, quantity_max_13.
    variant : str
        Один из вариантов:
        - 'hurdle_only': только Hurdle (stacked_expected + адаптивный порог)
        - 'hurdle_tweedie': Hurdle + Tweedie (подмешивание на высоком спросе и экстремальных пиках)
        - 'hurdle_tweedie_tft': Hurdle + Tweedie + смешивание с TFT (полная логика train_hurdle_stacking_submission.py)
    fitted_models : dict | None
        Словарь со словарем уже обученных моделей {'meta_clf': ..., 'meta_reg': ...}.
        Если None, модели обучаются на meta_train_df.

    Возвращает:
    -----------
    tuple[np.ndarray, dict[str, Any]]:
        - final_quantity: итоговый массив прогнозов
        - debug_info: промежуточные расчеты (p_sale_meta, q_cond_meta, final_continuous и т.д.)
    """
    valid_variants = ("hurdle_only", "hurdle_tweedie", "hurdle_tweedie_tft")
    if variant not in valid_variants:
        raise ValueError(f"Неизвестный вариант {variant}. Допустимы: {valid_variants}")

    if fitted_models is None:
        if meta_train_df is None:
            raise ValueError("Требуется либо meta_train_df, либо fitted_models!")
        fitted_models = fit_meta_models(meta_train_df)

    meta_clf = fitted_models["meta_clf"]
    meta_reg = fitted_models["meta_reg"]

    # 1. Прогнозы базовых мета-моделей
    p_sale_meta = meta_clf.predict_proba(eval_df[META_FEATURES_CLF])[:, 1]
    q_cond_meta = meta_reg.predict(eval_df[META_FEATURES_REG]).clip(min=0.0)

    # 2. Ожидаемый объем продаж Hurdle
    stacked_expected = p_sale_meta * q_cond_meta * STACKED_SCALE

    # 3. Адаптивный порог отсечения нулей по режимам спроса
    zr = eval_df["quantity_nonzero_rate_13"].values
    th_adaptive = np.where(
        zr >= REGIME_REGULAR_ZR,
        TH_REGULAR,
        np.where(zr >= REGIME_INTERMITTENT_ZR, TH_INTERMITTENT, TH_RARE),
    )
    passed = p_sale_meta >= th_adaptive

    # 4. Расчет непрерывного прогноза в зависимости от варианта
    if variant == "hurdle_only":
        final_continuous = stacked_expected.copy()

    elif variant == "hurdle_tweedie":
        if "tweedie_pred" not in eval_df.columns:
            raise KeyError("Колонка 'tweedie_pred' отсутствует в eval_df!")
        tweedie_pred = eval_df["tweedie_pred"].values

        high_demand_mask = (eval_df["quantity_mean_13"].values >= HIGH_DEMAND_MEAN) | (
            eval_df["quantity_max_13"].values >= HIGH_DEMAND_MAX
        )
        adjusted_quantity = stacked_expected.copy()
        adjusted_quantity[high_demand_mask] = (
            (1.0 - TWEEDIE_BLEND_WEIGHT) * stacked_expected[high_demand_mask]
            + TWEEDIE_BLEND_WEIGHT * tweedie_pred[high_demand_mask]
        )

        extreme_mask = eval_df["quantity_max_13"].values >= EXTREME_DEMAND_MAX
        adjusted_quantity[extreme_mask] = np.maximum(
            adjusted_quantity[extreme_mask],
            tweedie_pred[extreme_mask] * TWEEDIE_EXTREME_BOOST,
        )
        final_continuous = adjusted_quantity

    elif variant == "hurdle_tweedie_tft":
        if "tweedie_pred" not in eval_df.columns:
            raise KeyError("Колонка 'tweedie_pred' отсутствует в eval_df!")
        if "raw_tft" not in eval_df.columns:
            raise KeyError("Колонка 'raw_tft' отсутствует в eval_df!")

        tweedie_pred = eval_df["tweedie_pred"].values
        raw_tft = eval_df["raw_tft"].values

        high_demand_mask = (eval_df["quantity_mean_13"].values >= HIGH_DEMAND_MEAN) | (
            eval_df["quantity_max_13"].values >= HIGH_DEMAND_MAX
        )
        adjusted_quantity = stacked_expected.copy()
        adjusted_quantity[high_demand_mask] = (
            (1.0 - TWEEDIE_BLEND_WEIGHT) * stacked_expected[high_demand_mask]
            + TWEEDIE_BLEND_WEIGHT * tweedie_pred[high_demand_mask]
        )

        tft_smooth = np.maximum(raw_tft * TFT_SCALE, 0.0)
        continuous = (
            (1.0 - TFT_BLEND_WEIGHT) * adjusted_quantity
            + TFT_BLEND_WEIGHT * tft_smooth
        )

        extreme_mask = eval_df["quantity_max_13"].values >= EXTREME_DEMAND_MAX
        continuous[extreme_mask] = np.maximum(
            continuous[extreme_mask],
            tweedie_pred[extreme_mask] * TWEEDIE_EXTREME_BOOST,
        )
        final_continuous = continuous

    # 5. Применение порога и округления
    final_quantity = np.where(passed, np.maximum(1.0, np.round(final_continuous)), 0.0)

    debug_info = {
        "p_sale_meta": p_sale_meta,
        "q_cond_meta": q_cond_meta,
        "stacked_expected": stacked_expected,
        "th_adaptive": th_adaptive,
        "passed": passed,
        "final_continuous": final_continuous,
        "models": fitted_models,
    }

    return final_quantity, debug_info


def compute_old_ensemble_forecast(
    eval_df: pd.DataFrame,
    alpha: float = 1.05,
    threshold: float = 0.65,
) -> np.ndarray:
    """Точный расчет замороженного финального ансамбля из коммита fc45f11.

    raw = (0.50 * TFT + 0.30 * LGBM + 0.10 * PerCat + 0.10 * CatBoost) * alpha
    raw[raw < threshold] = 0.0
    final = np.rint(raw).clip(0, None)
    """
    for col in ("raw_tft", "q_lgbm_bench", "q_per_bench", "q_cb_bench"):
        if col not in eval_df.columns:
            raise KeyError(f"Колонка '{col}' отсутствует в eval_df для старого ансамбля!")

    raw = (
        0.50 * eval_df["raw_tft"].values
        + 0.30 * eval_df["q_lgbm_bench"].values
        + 0.10 * eval_df["q_per_bench"].values
        + 0.10 * eval_df["q_cb_bench"].values
    ) * alpha

    raw = raw.copy()
    raw[raw < threshold] = 0.0
    return np.rint(raw).clip(0, None)
