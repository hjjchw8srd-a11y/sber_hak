"""Optuna тюнинг гиперпараметров LightGBM для недельного прогноза продаж.

Оптимизирует взвешенный Score хакатона на кросс-валидации.
"""

from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import lightgbm as lgb
import optuna

from fast_score import compute_all_metrics_fast
from score import normalized_score
from run_weekly_feature_experiments import (
    HORIZON,
    CAT_COLUMNS,
    WeeklyMatrices,
    columns_for_experiment,
    make_truth,
    prediction_frame,
)
from train_tft_weekly import baseline_mean13
from analyze_tft_postprocessing import apply_rule

optuna.logging.set_verbosity(optuna.logging.WARNING)


def objective(trial: optuna.Trial, matrices: WeeklyMatrices, latest_origin: int, columns: list[str]) -> float:
    # Гиперпараметры для поиска
    num_leaves = trial.suggest_int("num_leaves", 15, 63)
    learning_rate = trial.suggest_float("learning_rate", 0.04, 0.14, log=True)
    n_estimators = trial.suggest_int("n_estimators", 120, 250, step=20)
    min_child_samples = trial.suggest_int("min_child_samples", 20, 100)
    subsample = trial.suggest_float("subsample", 0.7, 1.0)
    colsample_bytree = trial.suggest_float("colsample_bytree", 0.7, 1.0)
    reg_alpha = trial.suggest_float("reg_alpha", 1e-3, 5.0, log=True)
    reg_lambda = trial.suggest_float("reg_lambda", 1e-3, 5.0, log=True)

    cat_columns = [c for c in CAT_COLUMNS if c in columns]

    scores = []
    # Валидация на 2-х фолдах для быстрой и надежной оценки
    for fold in range(2):
        origin = latest_origin - fold * HORIZON
        validation_weeks = matrices.weeks[origin : origin + HORIZON]
        truth = make_truth(matrices, origin)

        # Baseline
        baseline = baseline_mean13(matrices.data_raw, pd.Timestamp(validation_weeks[0]), pd.Index(validation_weeks))
        baseline_metrics = compute_all_metrics_fast(truth, baseline)

        latest_train_origin = origin - HORIZON
        earliest_train_origin = max(26, latest_train_origin - 17)
        train_origins = np.arange(earliest_train_origin, latest_train_origin + 1)
        train, target, _ = matrices.make_rows(train_origins, 350_000, seed=42 + fold)
        validation, _, _ = matrices.make_rows(np.array([origin]), None)

        X_train = train[columns].copy()
        X_val = validation[columns].copy()
        for col in cat_columns:
            X_train[col] = X_train[col].astype("category")
            X_val[col] = X_val[col].astype("category")

        # Классификатор нулей
        clf = lgb.LGBMClassifier(
            n_estimators=n_estimators,
            learning_rate=learning_rate,
            num_leaves=num_leaves,
            min_child_samples=min_child_samples,
            subsample=subsample,
            colsample_bytree=colsample_bytree,
            reg_alpha=reg_alpha,
            reg_lambda=reg_lambda,
            random_state=42,
            verbosity=-1,
            n_jobs=-1,
        )
        clf.fit(X_train, (target > 0).astype(int))
        proba = clf.predict_proba(X_val)[:, 1]

        # Регрессор ненулевых
        pos_idx = target > 0
        reg = lgb.LGBMRegressor(
            n_estimators=n_estimators,
            learning_rate=learning_rate,
            num_leaves=num_leaves,
            min_child_samples=min_child_samples,
            subsample=subsample,
            colsample_bytree=colsample_bytree,
            reg_alpha=reg_alpha,
            reg_lambda=reg_lambda,
            random_state=42,
            verbosity=-1,
            n_jobs=-1,
        )
        reg.fit(X_train.loc[pos_idx], np.log1p(target[pos_idx]))
        cond = np.expm1(reg.predict(X_val))

        pred = proba * np.maximum(cond, 0)
        pred[proba < 0.5] = 0.0

        pred_df = prediction_frame(truth, pred)
        pred_df["quantity"] = apply_rule(pred_df["quantity"], threshold=0.75, round_to_int=True)

        m = compute_all_metrics_fast(truth, pred_df)
        sc = normalized_score(m, baseline_metrics)
        scores.append(sc)

    return float(np.mean(scores))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--trials", type=int, default=20)
    args = parser.parse_args()

    data = pd.read_csv("weekly_data/weekly_dataset.csv.gz", parse_dates=["week"])
    matrices = WeeklyMatrices(data)
    matrices.data_raw = data
    latest_origin = len(matrices.weeks) - HORIZON
    columns = columns_for_experiment("base_calendar_network")

    out_dir = Path("experiments/optuna")
    out_dir.mkdir(parents=True, exist_ok=True)
    db_path = out_dir / "lgbm_optuna.db"

    study = optuna.create_study(
        study_name="lgbm_tuning",
        storage=f"sqlite:///{db_path.as_posix()}",
        direction="minimize",
        load_if_exists=True,
    )

    print(f"=== Запуск Optuna для LightGBM ({args.trials} trials) ===")
    study.optimize(lambda trial: objective(trial, matrices, latest_origin, columns), n_trials=args.trials)

    print("\n" + "=" * 60)
    print("OPTUNA ТЮНИНГ ЗАВЕРШЕН!")
    print(f"Лучший Score: {study.best_value:.6f}")
    print("Лучшие гиперпараметры:")
    for k, v in study.best_params.items():
        print(f"  {k}: {v}")
    print("=" * 60)

    # Сохраняем датафрейм испытаний
    df_trials = study.trials_dataframe()
    df_trials.to_csv(out_dir / "lgbm_optuna_trials.csv", index=False)


if __name__ == "__main__":
    main()
