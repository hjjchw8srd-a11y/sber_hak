"""Генерация прогноза на будущее (9 недель) с помощью 14 моделей категорий.

Период: 2026-07-27 .. 2026-09-21.
"""

from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
import lightgbm as lgb

from run_weekly_feature_experiments import (
    HORIZON,
    KEYS,
    CAT_COLUMNS,
    WeeklyMatrices,
    columns_for_experiment,
)
from score import validate_submission
from analyze_tft_postprocessing import apply_rule


def train_predict_category(
    X_train_cat: pd.DataFrame,
    y_train_cat: np.ndarray,
    X_val_cat: pd.DataFrame,
    feature_cols: list[str],
) -> np.ndarray:
    if len(X_val_cat) == 0:
        return np.array([])
    pos_mask = y_train_cat > 0
    if pos_mask.sum() < 20:
        return np.full(len(X_val_cat), max(0.0, float(np.mean(y_train_cat))))

    clf = lgb.LGBMClassifier(
        n_estimators=140,
        learning_rate=0.06,
        num_leaves=25,
        min_child_samples=20,
        random_state=42,
        verbosity=-1,
        n_jobs=-1,
    )
    clf.fit(X_train_cat[feature_cols], (y_train_cat > 0).astype(int))
    proba = clf.predict_proba(X_val_cat[feature_cols])[:, 1]

    reg = lgb.LGBMRegressor(
        n_estimators=140,
        learning_rate=0.06,
        num_leaves=25,
        min_child_samples=20,
        random_state=42,
        verbosity=-1,
        n_jobs=-1,
    )
    reg.fit(X_train_cat.loc[pos_mask, feature_cols], np.log1p(y_train_cat[pos_mask]))
    cond = np.expm1(reg.predict(X_val_cat[feature_cols]))

    pred = proba * np.maximum(cond, 0)
    pred[proba < 0.5] = 0.0
    return pred


def main() -> None:
    data = pd.read_csv("weekly_data/weekly_dataset.csv.gz", parse_dates=["week"])
    first_week = data[data["week"] == data["week"].min()].sort_values(["warehouse_name", "article"])
    pairs_df = first_week[["warehouse_name", "article", "category_lvl_1", "category_lvl_2", "category_lvl_3"]].copy()

    future_weeks = pd.date_range("2026-07-27", periods=HORIZON, freq="W-MON")

    future_rows = []
    for w in future_weeks:
        chunk = pairs_df.copy()
        chunk["week"] = w
        chunk["quantity"] = 0.0
        chunk["sales_sum"] = 0.0
        chunk["discount_sum"] = 0.0
        chunk["stock_week_end"] = np.nan
        chunk["stock_mean"] = np.nan
        chunk["stock_nonpositive_rate"] = np.nan
        chunk["stock_observed_days"] = 0.0
        future_rows.append(chunk)

    future_df = pd.concat(future_rows, ignore_index=True)
    extended_data = pd.concat([data, future_df], ignore_index=True)

    matrices = WeeklyMatrices(extended_data)
    origin = len(data["week"].unique())

    latest_train_origin = origin - HORIZON
    earliest_train_origin = max(26, latest_train_origin - 17)
    train_origins = np.arange(earliest_train_origin, latest_train_origin + 1)
    all_columns = columns_for_experiment("base_calendar_network")
    feature_columns = [c for c in all_columns if c != "category_lvl_1"]
    cat_columns = [c for c in CAT_COLUMNS if c in feature_columns]

    print(f"Обучение 14 категориальных моделей на всей истории (ориджины {train_origins[0]}..{train_origins[-1]})...")
    train_df, target_arr, _ = matrices.make_rows(train_origins, 350_000, seed=42)
    test_df, _, _ = matrices.make_rows(np.array([origin]), None)
    train_df["target"] = target_arr

    for col in cat_columns:
        train_df[col] = train_df[col].astype("category")
        test_df[col] = test_df[col].astype("category")

    test_predictions = np.zeros(len(test_df), dtype=np.float32)
    unique_categories = sorted(train_df["category_lvl_1"].unique())

    for cat in unique_categories:
        train_mask = train_df["category_lvl_1"] == cat
        val_mask = test_df["category_lvl_1"] == cat
        X_tr = train_df.loc[train_mask]
        y_tr = train_df.loc[train_mask, "target"].values
        X_val = test_df.loc[val_mask]
        test_predictions[val_mask.values] = train_predict_category(X_tr, y_tr, X_val, feature_columns)

    test_weeks = np.repeat(matrices.weeks[origin : origin + HORIZON].to_numpy(), matrices.n_pairs)
    test_pairs = pd.concat([matrices.pairs] * HORIZON, ignore_index=True)

    pred_df = pd.DataFrame({
        "week": pd.to_datetime(test_weeks).strftime("%Y-%m-%d"),
        "warehouse_name": test_pairs["warehouse_name"],
        "article": test_pairs["article"],
        "quantity": apply_rule(pd.Series(test_predictions), threshold=0.75, round_to_int=True),
    })

    out_file = Path("experiments/benchmarks/per_category/per_category_final_submission.csv")
    pred_df.to_csv(out_file, index=False)
    print(f"Файл {out_file} сохранен! Строк: {len(pred_df)}")
    print("Предупреждения валидатора:", validate_submission(pred_df, "per_category"))


if __name__ == "__main__":
    main()
