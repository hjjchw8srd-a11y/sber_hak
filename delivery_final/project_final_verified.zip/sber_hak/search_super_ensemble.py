"""Поиск оптимального супер-ансамбля по всем обученным моделям.

Модели:
1. TFT (нейросеть-трансформер)
2. LightGBM (быстрый градиентный бустинг)
3. TiDE (плотная нейросеть-кодировщик)
4. NHITS (иерархическая нейросеть)

Ищет оптимальные веса на тех же 3-х фолдах.
"""

from __future__ import annotations
from pathlib import Path
import itertools
import numpy as np
import pandas as pd

from fast_score import compute_all_metrics_fast
from score import normalized_score
from run_weekly_feature_experiments import HORIZON, WeeklyMatrices, make_truth
from train_tft_weekly import baseline_mean13
from analyze_tft_postprocessing import apply_rule


def main() -> None:
    data = pd.read_csv("weekly_data/weekly_dataset.csv.gz", parse_dates=["week"])
    matrices = WeeklyMatrices(data)
    latest_origin = len(matrices.weeks) - HORIZON
    folds = 3
    fold_step = HORIZON

    keys = ["week", "warehouse_name", "article"]
    models = ["tft", "lgbm", "tide", "nhits"]

    # Загружаем предсказания по всем фолдам
    fold_data = []

    for fold in range(folds):
        origin = latest_origin - fold * fold_step
        validation_weeks = matrices.weeks[origin : origin + HORIZON]
        truth = make_truth(matrices, origin)
        truth["week"] = pd.to_datetime(truth["week"]).dt.strftime("%Y-%m-%d")

        baseline = baseline_mean13(data, pd.Timestamp(validation_weeks[0]), pd.Index(validation_weeks))
        baseline["week"] = pd.to_datetime(baseline["week"]).dt.strftime("%Y-%m-%d")
        baseline_metrics = compute_all_metrics_fast(truth, baseline)

        # TFT
        p_tft = pd.read_csv(f"experiments/tft/tft_predictions_fold_{fold}.csv.gz")
        p_tft["week"] = pd.to_datetime(p_tft["week"]).dt.strftime("%Y-%m-%d")
        # Post-process TFT raw
        p_tft["quantity"] = apply_rule(p_tft["quantity"], threshold=0.75, round_to_int=False)

        # LGBM
        p_lgbm = pd.read_csv(f"experiments/benchmarks/lgbm/lgbm_predictions_fold_{fold}.csv.gz")
        p_lgbm["week"] = pd.to_datetime(p_lgbm["week"]).dt.strftime("%Y-%m-%d")

        # TiDE
        p_tide = pd.read_csv(f"experiments/benchmarks/tide/tide_predictions_fold_{fold}.csv.gz")
        p_tide["week"] = pd.to_datetime(p_tide["week"]).dt.strftime("%Y-%m-%d")

        # NHITS
        p_nhits = pd.read_csv(f"experiments/benchmarks/nhits/nhits_predictions_fold_{fold}.csv.gz")
        p_nhits["week"] = pd.to_datetime(p_nhits["week"]).dt.strftime("%Y-%m-%d")

        merged = truth[keys].copy()
        merged["qty_truth"] = truth["quantity"].values
        merged["tft"] = p_tft["quantity"].values
        merged["lgbm"] = p_lgbm["quantity"].values
        merged["tide"] = p_tide["quantity"].values
        merged["nhits"] = p_nhits["quantity"].values

        fold_data.append({
            "truth": truth,
            "baseline_metrics": baseline_metrics,
            "merged": merged,
        })

    print("Все данные 3-х фолдов успешно загружены в память!")

    # Сетка весов (шаг 0.1)
    weight_candidates = []
    # 2-model ensembles: TFT + LGBM
    for w in np.linspace(0.0, 1.0, 21):
        weight_candidates.append({"tft": w, "lgbm": 1.0 - w, "tide": 0.0, "nhits": 0.0})

    # 3-model ensembles: TFT + LGBM + TiDE
    for w_tft in [0.3, 0.4, 0.5, 0.6]:
        for w_lgbm in [0.2, 0.3, 0.4, 0.5]:
            w_tide = round(1.0 - w_tft - w_lgbm, 2)
            if w_tide >= 0:
                weight_candidates.append({"tft": w_tft, "lgbm": w_lgbm, "tide": w_tide, "nhits": 0.0})

    # 4-model ensembles
    for w_tft in [0.3, 0.4, 0.5]:
        for w_lgbm in [0.3, 0.4]:
            for w_tide in [0.1, 0.2]:
                w_nhits = round(1.0 - w_tft - w_lgbm - w_tide, 2)
                if w_nhits > 0:
                    weight_candidates.append({"tft": w_tft, "lgbm": w_lgbm, "tide": w_tide, "nhits": w_nhits})

    results = []

    for cfg in weight_candidates:
        w_tft = cfg["tft"]
        w_lgbm = cfg["lgbm"]
        w_tide = cfg["tide"]
        w_nhits = cfg["nhits"]

        scores = []
        metrics_list = []

        for fd in fold_data:
            df = fd["merged"]
            pred_vals = (
                w_tft * df["tft"].values
                + w_lgbm * df["lgbm"].values
                + w_tide * df["tide"].values
                + w_nhits * df["nhits"].values
            )
            # Применяем порог и округление
            final_pred = np.rint(np.clip(pred_vals, 0, None))
            eval_df = df[keys].copy()
            eval_df["quantity"] = final_pred

            m = compute_all_metrics_fast(fd["truth"], eval_df)
            sc = normalized_score(m, fd["baseline_metrics"])
            scores.append(sc)
            metrics_list.append(m)

        mean_sc = float(np.mean(scores))
        mean_smape = float(np.mean([m["smape"] for m in metrics_list]))
        mean_wape = float(np.mean([m["wape"] for m in metrics_list]))
        mean_rmse = float(np.mean([m["rmse"] for m in metrics_list]))
        mean_bias = float(np.mean([m["bias"] for m in metrics_list]))

        results.append({
            "tft": round(w_tft, 2),
            "lgbm": round(w_lgbm, 2),
            "tide": round(w_tide, 2),
            "nhits": round(w_nhits, 2),
            "mean_score": mean_sc,
            "std_score": float(np.std(scores)),
            "smape": mean_smape,
            "wape": mean_wape,
            "rmse": mean_rmse,
            "bias": mean_bias,
        })

    df_res = pd.DataFrame(results).sort_values("mean_score").reset_index(drop=True)
    df_res.to_csv("experiments/benchmarks/super_ensemble_search.csv", index=False)

    print("\n" + "=" * 70)
    print("ТОП-10 КОНФИГУРАЦИЙ СУПЕР-АНСАМБЛЯ:")
    print("=" * 70)
    print(df_res.head(10).to_string(index=False))

    best = df_res.iloc[0]
    print("\n" + "=" * 70)
    print(f"★ ЛУЧШИЙ АНСАМБЛЬ:")
    print(f"  TFT:   {best['tft']:.2f}")
    print(f"  LGBM:  {best['lgbm']:.2f}")
    print(f"  TiDE:  {best['tide']:.2f}")
    print(f"  NHITS: {best['nhits']:.2f}")
    print(f"  SCORE: {best['mean_score']:.6f}  (SMAPE={best['smape']:.2f}%, WAPE={best['wape']:.2f}%)")
    print("=" * 70)


if __name__ == "__main__":
    main()
