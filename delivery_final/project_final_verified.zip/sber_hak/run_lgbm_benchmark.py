"""Бенчмарк LightGBM (глобальный табличный регрессор sktime-экосистемы).

Сравниваем с CatBoost base_calendar_network на тех же 3 rolling-фолдах.
"""

from __future__ import annotations
from pathlib import Path
import time
import numpy as np
import pandas as pd
import lightgbm as lgb

from fast_score import compute_all_metrics_fast
from score import normalized_score
from run_weekly_feature_experiments import (
    HORIZON,
    KEYS,
    CAT_COLUMNS,
    WeeklyMatrices,
    columns_for_experiment,
    make_truth,
    prediction_frame,
)
from analyze_tft_postprocessing import apply_rule


def train_and_predict_lgbm(
    train: pd.DataFrame,
    target: np.ndarray,
    validation: pd.DataFrame,
    columns: list[str],
    iterations: int = 200,
) -> np.ndarray:
    cat_columns = [c for c in CAT_COLUMNS if c in columns]
    X_train = train[columns].copy()
    X_val = validation[columns].copy()

    for col in cat_columns:
        X_train[col] = X_train[col].astype("category")
        X_val[col] = X_val[col].astype("category")

    # Двухэтапная модель: классификатор нулевых продаж + регрессор
    clf = lgb.LGBMClassifier(
        n_estimators=iterations,
        learning_rate=0.08,
        num_leaves=31,
        random_state=42,
        verbosity=-1,
        n_jobs=-1,
    )
    clf.fit(X_train, (target > 0).astype(int))
    proba = clf.predict_proba(X_val)[:, 1]

    pos_idx = target > 0
    reg = lgb.LGBMRegressor(
        n_estimators=iterations,
        learning_rate=0.08,
        num_leaves=31,
        random_state=42,
        verbosity=-1,
        n_jobs=-1,
    )
    reg.fit(X_train.loc[pos_idx], np.log1p(target[pos_idx]))
    cond = np.expm1(reg.predict(X_val))

    pred = proba * np.maximum(cond, 0)
    pred[proba < 0.5] = 0.0
    return pred


def main() -> None:
    data = pd.read_csv("weekly_data/weekly_dataset.csv.gz", parse_dates=["week"])
    matrices = WeeklyMatrices(data)
    latest_origin = len(matrices.weeks) - HORIZON
    folds = 3
    fold_step = HORIZON

    output_dir = Path("experiments/benchmarks/lgbm")
    output_dir.mkdir(parents=True, exist_ok=True)

    columns = columns_for_experiment("base_calendar_network")
    results = []

    print("=== Запуск бенчмарка LightGBM (base_calendar_network, 3 фолда) ===")
    for fold in range(folds):
        origin = latest_origin - fold * fold_step
        validation_weeks = matrices.weeks[origin : origin + HORIZON]
        truth = make_truth(matrices, origin)

        # Baseline
        from train_tft_weekly import baseline_mean13
        baseline = baseline_mean13(data, pd.Timestamp(validation_weeks[0]), pd.Index(validation_weeks))
        baseline_metrics = compute_all_metrics_fast(truth, baseline)

        latest_train_origin = origin - HORIZON
        earliest_train_origin = max(26, latest_train_origin - 17)
        train_origins = np.arange(earliest_train_origin, latest_train_origin + 1)
        train, target, _ = matrices.make_rows(train_origins, 350_000, seed=42 + fold)
        validation, _, _ = matrices.make_rows(np.array([origin]), None)

        started = time.perf_counter()
        pred_vals = train_and_predict_lgbm(train, target, validation, columns, iterations=200)
        elapsed = time.perf_counter() - started

        pred_df = prediction_frame(truth, pred_vals)
        pred_df["quantity"] = apply_rule(pred_df["quantity"], threshold=0.75, round_to_int=True)

        metrics = compute_all_metrics_fast(truth, pred_df)
        score = normalized_score(metrics, baseline_metrics)

        row = {
            "fold": fold,
            "validation_start": str(validation_weeks[0].date()),
            "validation_end": str(validation_weeks[-1].date()),
            **metrics,
            "normalized_score": score,
            "seconds": elapsed,
        }
        results.append(row)
        print(f"Fold {fold}: Score={score:.4f}, SMAPE={metrics['smape']:.2f}%, WAPE={metrics['wape']:.2f}% ({elapsed:.1f}с)")
        pred_df.to_csv(output_dir / f"lgbm_predictions_fold_{fold}.csv.gz", index=False)

    df_res = pd.DataFrame(results)
    df_res.to_csv(output_dir / "lgbm_results.csv", index=False)
    print("\n" + "=" * 60)
    print(f"ИТОГИ LightGBM: средний Score = {df_res['normalized_score'].mean():.6f}")
    print("=" * 60)


if __name__ == "__main__":
    main()
