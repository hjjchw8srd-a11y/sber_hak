"""
sber_hak/history_audit_pipeline.py

Unified module for history length ablation, pipeline standardization,
predict_from_components, unclipped_ratio scoring, and caching.
"""

from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import lightgbm as lgb

from fast_score import compute_all_metrics_fast, METRIC_WEIGHTS
from score import normalized_score
from run_weekly_feature_experiments import (
    HORIZON,
    KEYS,
    CAT_COLUMNS,
    WeeklyMatrices,
    columns_for_experiment,
    make_truth,
)
from train_tft_weekly import baseline_mean13


def compute_metrics_with_diagnostics(
    df_truth: pd.DataFrame,
    df_pred: pd.DataFrame,
    df_baseline: pd.DataFrame,
) -> dict[str, Any]:
    """
    Computes all 5 official raw metrics, official clipped score,
    and the unclipped diagnostic ratio:
        unclipped_ratio = sum(weight * metric / mean13_metric)
    along with clipping flags for each metric.
    """
    m = compute_all_metrics_fast(df_truth, df_pred)
    bm = compute_all_metrics_fast(df_truth, df_baseline)

    clipped_score = 0.0
    unclipped_ratio = 0.0
    clipping_flags = {}

    for metric, weight in METRIC_WEIGHTS.items():
        base_val = bm[metric]
        ratio = m[metric] / base_val if base_val > 0 else 0.0
        clipped_score += weight * min(max(ratio, 0.0), 1.0)
        unclipped_ratio += weight * ratio
        clipping_flags[f"{metric}_clipped"] = bool(ratio >= 1.0)

    # Classification / volume diagnostics
    merged = df_truth[KEYS + ["quantity"]].merge(
        df_pred[KEYS + ["quantity"]], on=KEYS, suffixes=("_true", "_pred"), how="inner"
    )
    y_true = merged["quantity_true"].values.astype(float)
    y_pred = merged["quantity_pred"].values.astype(float)

    fact_sum = float(y_true.sum())
    pred_sum = float(y_pred.sum())
    fact_pos = y_true > 0
    pred_pos = y_pred > 0

    tp = int((fact_pos & pred_pos).sum())
    fp = int((~fact_pos & pred_pos).sum())
    fn = int((fact_pos & ~pred_pos).sum())
    tn = int((~fact_pos & ~pred_pos).sum())

    precision = float(tp / (tp + fp)) if (tp + fp) > 0 else 0.0
    recall = float(tp / (tp + fn)) if (tp + fn) > 0 else 0.0

    return {
        "smape": m["smape"],
        "wape": m["wape"],
        "rmse": m["rmse"],
        "bias": m["bias"],
        "rmsle": m["rmsle"],
        "clipped_score": float(clipped_score),
        "unclipped_ratio": float(unclipped_ratio),
        "clipping_flags": clipping_flags,
        "base_smape": bm["smape"],
        "base_wape": bm["wape"],
        "base_rmse": bm["rmse"],
        "base_bias": bm["bias"],
        "base_rmsle": bm["rmsle"],
        "fact_sum": fact_sum,
        "pred_sum": pred_sum,
        "fact_nonzero_rate": float(fact_pos.mean()),
        "pred_nonzero_rate": float(pred_pos.mean()),
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "tn": tn,
        "precision": precision,
        "recall": recall,
        "max_pred": float(y_pred.max()),
        "p99_pred": float(np.percentile(y_pred, 99)),
    }


def predict_from_components(
    components: dict[str, pd.DataFrame],
    config: dict[str, Any],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Decouples raw model outputs, component postprocessing, and final blending.
    Applies explicit probability gate, component-level postprocess (if any),
    weighted combination, blend alpha, blend threshold, and rounding.

    Returns:
    - keyed_df: complete DataFrame with all intermediate component values and keys.
    - submission_df: DataFrame with ['week', 'warehouse_name', 'article', 'quantity'].
    """
    comp_configs = config["components"]
    blend_cfg = config["blend"]
    alpha = blend_cfg.get("alpha", 1.05)
    threshold = blend_cfg.get("threshold", 0.65)
    rounding = blend_cfg.get("rounding", "rint")
    clip_lower = blend_cfg.get("clip_lower", 0.0)

    # Start with keys from first component
    first_key = list(components.keys())[0]
    base_df = components[first_key][KEYS].copy()
    base_df["week"] = pd.to_datetime(base_df["week"]).dt.strftime("%Y-%m-%d")

    raw_blend = np.zeros(len(base_df), dtype=np.float64)
    keyed_df = base_df.copy()

    for name, c_cfg in comp_configs.items():
        weight = c_cfg["weight"]
        c_df = components[name].copy()
        c_df["week"] = pd.to_datetime(c_df["week"]).dt.strftime("%Y-%m-%d")

        # Validate one-to-one merge
        merged = base_df.merge(c_df, on=KEYS, how="inner", validate="one_to_one")
        if len(merged) != len(base_df):
            raise ValueError(f"Key mismatch in component '{name}': expected {len(base_df)}, got {len(merged)}")

        c_type = c_cfg.get("type", "two_stage")
        if c_type == "two_stage":
            p_sale = merged["p_sale"].values.astype(np.float64)
            q_cond = merged["conditional_quantity" if "conditional_quantity" in merged else "q_cond"].values.astype(np.float64)
            expected = p_sale * q_cond
            prob_gate = c_cfg.get("prob_gate", 0.5)

            if prob_gate is not None:
                after_gate = np.where(p_sale < prob_gate, 0.0, expected)
            else:
                after_gate = expected.copy()

            comp_post = c_cfg.get("comp_postprocess", None)
            if comp_post == "bench_lgbm":
                # Legacy benchmark rule: threshold=0.75, round_to_int=True
                after_comp = np.where(after_gate < 0.75, 0.0, np.rint(after_gate).clip(0, None))
            elif comp_post == "bench_cb":
                # Legacy benchmark rule: threshold=0.75, round_to_int=False
                after_comp = np.where(after_gate < 0.75, 0.0, after_gate)
            else:
                after_comp = after_gate.copy()

            keyed_df[f"p_sale_{name}"] = p_sale
            keyed_df[f"q_cond_{name}"] = q_cond
            keyed_df[f"expected_{name}"] = expected
            keyed_df[f"after_gate_{name}"] = after_gate
            keyed_df[f"after_comp_{name}"] = after_comp
            raw_blend += weight * after_comp

        elif c_type == "raw":
            q_raw = merged["quantity" if "quantity" in merged else "raw_tft"].values.astype(np.float64)
            keyed_df[f"raw_{name}"] = q_raw
            keyed_df[f"after_comp_{name}"] = q_raw
            raw_blend += weight * q_raw

    # Final blend postprocessing
    scaled_blend = raw_blend * alpha
    gated_blend = np.where(scaled_blend < threshold, 0.0, scaled_blend)

    if rounding == "rint":
        final_pred = np.rint(gated_blend).clip(clip_lower, None)
    elif rounding == "floor":
        final_pred = np.floor(gated_blend).clip(clip_lower, None)
    else:
        final_pred = gated_blend.clip(clip_lower, None)

    keyed_df["raw_blend"] = raw_blend
    keyed_df["scaled_blend"] = scaled_blend
    keyed_df["final_prediction"] = final_pred

    sub_df = base_df.copy()
    sub_df["quantity"] = final_pred

    return keyed_df, sub_df


def train_lgbm_history_variant(
    matrices: WeeklyMatrices,
    origin: int,
    variant: str,
    seed: int = 42,
    fixed_params: Optional[dict[str, Any]] = None,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """
    Trains LightGBM on specified history length variant:
    - 'A': last 18 origins, equal weights (control)
    - 'B': last 52 origins, equal weights
    - 'C': last 52 origins, weights = 2 ** (-age_weeks / 26), normalized to mean 1.0

    Guarantees:
    - Budget: 350,000 sampled rows with identical schema
    - Strict non-leakage: all target_week < matrices.weeks[origin]
    - Min origin >= 26 (prevents negative array indexing for 26 lags)
    """
    columns = columns_for_experiment("base_calendar_network")
    val_start = matrices.weeks[origin]
    latest_train_origin = origin - HORIZON

    if variant == "A":
        earliest_train_origin = max(26, latest_train_origin - 17)
    elif variant in ("B", "C"):
        earliest_train_origin = max(26, latest_train_origin - 51)
    else:
        raise ValueError(f"Unknown variant: {variant}")

    train_origins = np.arange(earliest_train_origin, latest_train_origin + 1)
    num_origins = len(train_origins)

    # Make rows
    train_df, target_arr, target_pos = matrices.make_rows(train_origins, 350_000, seed=seed)
    val_df, _, _ = matrices.make_rows(np.array([origin]), None)
    truth = make_truth(matrices, origin)

    # Leakage check: target_pos is the index in matrices.weeks
    max_train_pos = int(target_pos.max())
    max_train_date = matrices.weeks[max_train_pos]
    assert max_train_date < val_start, f"Target leakage in {variant}! {max_train_date} >= {val_start}"

    min_train_pos = int(target_pos.min())
    min_train_date = matrices.weeks[min_train_pos]
    unique_target_weeks = len(np.unique(target_pos))
    zero_rate = float((target_arr == 0).mean())

    # Sample weights
    if variant == "C":
        # age_weeks from latest available target week in training
        age_weeks = (max_train_pos - target_pos).astype(np.float64)
        raw_weights = 2.0 ** (-age_weeks / 26.0)
        sample_weights = raw_weights / raw_weights.mean()
    else:
        sample_weights = np.ones(len(train_df), dtype=np.float64)

    cat_columns = [c for c in CAT_COLUMNS if c in columns]
    X_train = train_df[columns].copy()
    X_val = val_df[columns].copy()

    for col in cat_columns:
        X_train[col] = X_train[col].astype("category")
        X_val[col] = X_val[col].astype("category")

    params = {
        "n_estimators": 160,
        "learning_rate": 0.0495,
        "num_leaves": 29,
        "min_child_samples": 51,
        "subsample": 0.727,
        "colsample_bytree": 0.728,
        "reg_alpha": 0.0164,
        "reg_lambda": 0.0057,
        "random_state": seed,
        "verbosity": -1,
        "n_jobs": -1,
    }
    if fixed_params:
        params.update(fixed_params)

    started = time.perf_counter()

    clf = lgb.LGBMClassifier(**params)
    clf.fit(X_train, (target_arr > 0).astype(int), sample_weight=sample_weights)
    p_sale = clf.predict_proba(X_val)[:, 1]

    pos_idx = target_arr > 0
    reg = lgb.LGBMRegressor(**params)
    reg.fit(
        X_train.loc[pos_idx],
        np.log1p(target_arr[pos_idx]),
        sample_weight=sample_weights[pos_idx],
    )
    conditional = np.maximum(np.expm1(reg.predict(X_val)), 0.0)
    expected = p_sale * conditional

    elapsed = time.perf_counter() - started

    truth_keys = truth[KEYS].copy()
    truth_keys["week"] = pd.to_datetime(truth_keys["week"]).dt.strftime("%Y-%m-%d")
    df_out = truth_keys.copy()
    df_out["origin"] = origin
    df_out["p_sale"] = p_sale
    df_out["conditional_quantity"] = conditional
    df_out["expected_quantity"] = expected
    df_out["quantity"] = expected

    diagnostics = {
        "variant": variant,
        "origin": origin,
        "num_origins": num_origins,
        "earliest_origin": int(train_origins[0]),
        "latest_origin": int(train_origins[-1]),
        "min_train_target_date": str(min_train_date.date()),
        "max_train_target_date": str(max_train_date.date()),
        "unique_target_weeks": unique_target_weeks,
        "zero_rate": zero_rate,
        "train_time_sec": elapsed,
        "mean_p_sale": float(p_sale.mean()),
        "mean_expected": float(expected.mean()),
    }

    return df_out, diagnostics
