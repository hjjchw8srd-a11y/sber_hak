"""Генерация и сохранение предсказаний CatBoost (base_calendar_network) на 3 фолдах."""

from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd

from run_weekly_feature_experiments import (
    HORIZON,
    WeeklyMatrices,
    columns_for_experiment,
    make_truth,
    prediction_frame,
    train_and_predict,
)
from analyze_tft_postprocessing import apply_rule


def main() -> None:
    data = pd.read_csv("weekly_data/weekly_dataset.csv.gz", parse_dates=["week"])
    matrices = WeeklyMatrices(data)
    latest_origin = len(matrices.weeks) - HORIZON
    folds = 3
    fold_step = HORIZON

    output_dir = Path("experiments/benchmarks/catboost")
    output_dir.mkdir(parents=True, exist_ok=True)
    columns = columns_for_experiment("base_calendar_network")

    print("=== Обучение CatBoost на 3 фолдах для сохранения предсказаний ===")
    for fold in range(folds):
        origin = latest_origin - fold * fold_step
        latest_train_origin = origin - HORIZON
        earliest_train_origin = max(26, latest_train_origin - 17)
        train_origins = np.arange(earliest_train_origin, latest_train_origin + 1)

        train, target, _ = matrices.make_rows(train_origins, 350_000, seed=42 + fold)
        validation, _, _ = matrices.make_rows(np.array([origin]), None)

        pred_vals, _ = train_and_predict(train, target, validation, columns, iterations=160)
        truth = make_truth(matrices, origin)
        pred_df = prediction_frame(truth, pred_vals)
        pred_df["quantity"] = apply_rule(pred_df["quantity"], threshold=0.75, round_to_int=False)

        out_path = output_dir / f"catboost_predictions_fold_{fold}.csv.gz"
        pred_df.to_csv(out_path, index=False)
        print(f"Fold {fold} сохранен: {out_path}")


if __name__ == "__main__":
    main()
