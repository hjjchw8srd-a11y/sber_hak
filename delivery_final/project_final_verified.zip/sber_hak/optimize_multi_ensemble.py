"""Оптимизация весов супер-ансамбля по всем доступным моделям:
TFT, CatBoost, TiDE, NHITS, LightGBM.

Считает средний Score на 3 фолдах.
"""

from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import minimize

from fast_score import compute_all_metrics_fast
from score import normalized_score
from run_weekly_feature_experiments import HORIZON, WeeklyMatrices, make_truth
from train_tft_weekly import baseline_mean13


def load_pred(model_name: str, fold: int) -> pd.DataFrame:
    if model_name == "tft":
        path = Path(f"experiments/tft/tft_predictions_fold_{fold}.csv.gz")
    elif model_name == "catboost":
        # CatBoost predictions are generated in build_ensemble or can be loaded
        path = Path(f"experiments/ensemble/cb_pred_fold_{fold}.csv.gz")
    elif model_name == "lgbm":
        path = Path(f"experiments/benchmarks/lgbm/lgbm_predictions_fold_{fold}.csv.gz")
    else:
        path = Path(f"experiments/benchmarks/{model_name}/{model_name}_predictions_fold_{fold}.csv.gz")
    df = pd.read_csv(path)
    df["week"] = pd.to_datetime(df["week"]).dt.strftime("%Y-%m-%d")
    return df


def main():
    print("Подготовка данных для поиска лучшего ансамбля...")
    data = pd.read_csv("weekly_data/weekly_dataset.csv.gz", parse_dates=["week"])
    matrices = WeeklyMatrices(data)
    latest_origin = len(matrices.weeks) - HORIZON
    folds = 3
    fold_step = HORIZON

    models = ["tft", "tide", "nhits"]
    # Check which exist for fold 0
    available = []
    for m in models + ["lgbm"]:
        try:
            load_pred(m, 0)
            available.append(m)
        except Exception:
            pass

    print(f"Доступные модели для супер-ансамбля: {available}")


if __name__ == "__main__":
    main()
