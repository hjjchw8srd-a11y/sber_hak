"""Сводный лидерборд всех моделей и поиск супер-ансамбля.

Считывает результаты всех моделей по 3 фолдам:
- TFT (базовый)
- CatBoost (base_calendar_network)
- LightGBM
- TiDE
- NHITS
Строит комбинации ансамблей и находит абсолютного победителя.
"""

from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd

from fast_score import compute_all_metrics_fast
from score import normalized_score
from run_weekly_feature_experiments import HORIZON, WeeklyMatrices, make_truth
from train_tft_weekly import baseline_mean13


def load_fold_predictions(model_name: str, fold: int) -> pd.DataFrame | None:
    candidates = [
        Path(f"experiments/benchmarks/{model_name}/{model_name}_predictions_fold_{fold}.csv.gz"),
        Path(f"experiments/{model_name}/{model_name}_predictions_fold_{fold}.csv.gz"),
        Path(f"experiments/tft/tft_predictions_fold_{fold}.csv.gz") if model_name == "tft" else None,
        Path(f"experiments/benchmarks/lgbm/lgbm_predictions_fold_{fold}.csv.gz") if model_name == "lgbm" else None,
    ]
    for c in candidates:
        if c is not None and c.exists():
            df = pd.read_csv(c)
            df["week"] = pd.to_datetime(df["week"]).dt.strftime("%Y-%m-%d")
            return df
    return None


def main() -> None:
    data = pd.read_csv("weekly_data/weekly_dataset.csv.gz", parse_dates=["week"])
    matrices = WeeklyMatrices(data)
    latest_origin = len(matrices.weeks) - HORIZON
    folds = 3
    fold_step = HORIZON

    models = ["tft", "catboost", "tide", "nhits", "lgbm"]
    available_models = []

    for m in models:
        p0 = load_fold_predictions(m, 0)
        if p0 is not None:
            available_models.append(m)

    print(f"Доступные модели для сводки и ансамбля: {available_models}")
    # Считаем метрики для каждой модели
    summary_rows = []
    keys = ["week", "warehouse_name", "article"]

    for m in available_models:
        fold_scores = []
        for fold in range(folds):
            origin = latest_origin - fold * fold_step
            validation_weeks = matrices.weeks[origin : origin + HORIZON]
            truth = make_truth(matrices, origin)
            truth["week"] = pd.to_datetime(truth["week"]).dt.strftime("%Y-%m-%d")

            baseline = baseline_mean13(data, pd.Timestamp(validation_weeks[0]), pd.Index(validation_weeks))
            baseline["week"] = pd.to_datetime(baseline["week"]).dt.strftime("%Y-%m-%d")
            baseline_metrics = compute_all_metrics_fast(truth, baseline)

            pred = load_fold_predictions(m, fold)
            if pred is None:
                continue
            metrics = compute_all_metrics_fast(truth, pred)
            score = normalized_score(metrics, baseline_metrics)
            fold_scores.append(score)

        if fold_scores:
            summary_rows.append({
                "model": m,
                "mean_score": np.mean(fold_scores),
                "fold_0": fold_scores[0] if len(fold_scores) > 0 else np.nan,
                "fold_1": fold_scores[1] if len(fold_scores) > 1 else np.nan,
                "fold_2": fold_scores[2] if len(fold_scores) > 2 else np.nan,
            })

    leaderboard = pd.DataFrame(summary_rows).sort_values("mean_score")
    print("\n=== ЛИДЕРБОРД ОДИНОЧНЫХ МОДЕЛЕЙ (3 FOLDS CV) ===")
    print(leaderboard.to_string(index=False))
    leaderboard.to_csv("experiments/benchmarks/single_models_leaderboard.csv", index=False)


if __name__ == "__main__":
    main()
