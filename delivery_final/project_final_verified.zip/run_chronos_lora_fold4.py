"""
Controlled Experiment: Chronos-2 LoRA Fine-Tuning on Fold 4 (origin=89).
Official Chronos2Pipeline.fit with finetune_mode="lora".
Strict time-series split with internal validation window.
"""

import sys
import time
import json
import hashlib
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from transformers import TrainerCallback
from peft import LoraConfig, get_peft_model

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'sber_hak'))
from fast_score import compute_all_metrics_fast, METRIC_WEIGHTS
from chronos import Chronos2Pipeline

KEYS = ['week', 'warehouse_name', 'article']
FOLD = 4
ORIGIN = 89
HORIZON = 9
CONTEXT = 52
BATCH_SIZE = 32
GRAD_ACCUM = 2
LR = 1e-5
STEPS = 300
LOG_STEPS = 50
EVAL_STEPS = 50


class LossLoggingCallback(TrainerCallback):
    def __init__(self):
        super().__init__()
        self.logs = []

    def on_log(self, args, state, control, logs=None, **kwargs):
        if logs:
            entry = dict(logs)
            entry['global_step'] = state.global_step
            self.logs.append(entry)


def calc_scores(m_pred: dict, m_base: dict) -> tuple[float, float]:
    clipped = 0.0
    unclipped = 0.0
    for k, w in METRIC_WEIGHTS.items():
        base_val = m_base[k]
        pred_val = m_pred[k]
        ratio = pred_val / base_val if base_val > 0 else 1.0
        clipped += w * min(max(ratio, 0.0), 1.0)
        unclipped += w * ratio
    return clipped, unclipped


def apply_p(raw_arr: np.ndarray, alpha: float = 1.05, thresh: float = 0.65) -> np.ndarray:
    scaled = raw_arr * alpha
    gated = np.where(scaled < thresh, 0.0, scaled)
    return np.rint(gated).clip(0, None)


def sha256_file(filepath: Path) -> str:
    h = hashlib.sha256()
    with open(filepath, 'rb') as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def verify_exact_and_unique_keys(truth_df: pd.DataFrame, pred_df: pd.DataFrame, expected_rows: int = 79101):
    """
    Strict validation of prediction keys:
    - Exactly expected_rows rows (79,101)
    - Zero duplicates in keys
    - Zero missing or NaN keys
    - Exact full set equality between truth keys and prediction keys
    - Zero unmapped or mismatched rows (outer join check)
    - All predictions must be finite (no NaN or inf)
    """
    if len(pred_df) != expected_rows:
        raise ValueError(f"Integrity error: predictions row count {len(pred_df)} != expected {expected_rows}")
    if len(truth_df) != expected_rows:
        raise ValueError(f"Integrity error: truth row count {len(truth_df)} != expected {expected_rows}")

    dup_pred = int(pred_df.duplicated(subset=KEYS).sum())
    if dup_pred > 0:
        raise ValueError(f"Integrity error: duplicate keys detected in predictions ({dup_pred} duplicates)!")

    dup_truth = int(truth_df.duplicated(subset=KEYS).sum())
    if dup_truth > 0:
        raise ValueError(f"Integrity error: duplicate keys detected in ground truth ({dup_truth} duplicates)!")

    if pred_df[KEYS].isna().any().any():
        raise ValueError("Integrity error: missing/NaN values found in prediction keys!")

    merged_keys = truth_df[KEYS].merge(pred_df[KEYS], on=KEYS, how="outer", indicator=True)
    if len(merged_keys) != expected_rows or (merged_keys["_merge"] != "both").any():
        mismatch_cnt = int((merged_keys["_merge"] != "both").sum())
        raise ValueError(f"Integrity error: key mismatch between truth and predictions ({mismatch_cnt} missing/extra keys)!")

    if not np.isfinite(pred_df['quantity'].to_numpy(dtype=np.float64)).all():
        raise ValueError("Integrity error: non-finite (NaN or Inf) values found in predicted quantities!")


def load_full_ft_benchmarks(bench_csv: Path, target_fold: int = 4) -> dict:
    """
    Dynamically loads verified Full Fine-Tuning benchmark records from CSV:
    - Verifies fold, variant and uniqueness of records.
    - Extracts Fold 4 Legacy P and Fold 4 Rint bit-exact metrics.
    - Computes 5-fold average across folds [0, 1, 2, 3, 4] for Rint.
    """
    if not bench_csv.exists():
        raise FileNotFoundError(f"Missing Full FT benchmark summary CSV: {bench_csv}")

    df_bench = pd.read_csv(bench_csv)

    # 1. Fold 4 Legacy P
    row_leg = df_bench[(df_bench["fold"] == target_fold) & (df_bench["variant"] == "legacy_p")]
    if len(row_leg) != 1:
        raise ValueError(f"Expected exactly 1 record for fold={target_fold}, variant='legacy_p', got {len(row_leg)}")
    r_leg = row_leg.iloc[0]
    bench_fold4_leg = {
        "clipped_score": float(r_leg["clipped_score"]),
        "unclipped_ratio": float(r_leg["unclipped_ratio"]),
        "smape": float(r_leg["smape"]),
        "wape": float(r_leg["wape"]),
        "rmse": float(r_leg["rmse"]),
        "bias": float(r_leg["bias"]),
        "rmsle": float(r_leg["rmsle"]),
    }

    # 2. Fold 4 Rint
    row_rint = df_bench[(df_bench["fold"] == target_fold) & (df_bench["variant"] == "rint")]
    if len(row_rint) != 1:
        raise ValueError(f"Expected exactly 1 record for fold={target_fold}, variant='rint', got {len(row_rint)}")
    r_rint = row_rint.iloc[0]
    bench_fold4_rint = {
        "clipped_score": float(r_rint["clipped_score"]),
        "unclipped_ratio": float(r_rint["unclipped_ratio"]),
        "smape": float(r_rint["smape"]),
        "wape": float(r_rint["wape"]),
        "rmse": float(r_rint["rmse"]),
        "bias": float(r_rint["bias"]),
        "rmsle": float(r_rint["rmsle"]),
    }

    # 3. 5-Fold Average Rint
    rows_5f = df_bench[(df_bench["variant"] == "rint") & (df_bench["fold"].isin([0, 1, 2, 3, 4]))]
    if len(rows_5f) != 5:
        raise ValueError(f"Expected exactly 5 folds for 5-fold average, got {len(rows_5f)}")
    bench_5f_rint = {
        "clipped_score": float(rows_5f["clipped_score"].mean()),
        "unclipped_ratio": float(rows_5f["unclipped_ratio"].mean()),
        "smape": float(rows_5f["smape"].mean()),
        "wape": float(rows_5f["wape"].mean()),
        "rmse": float(rows_5f["rmse"].mean()),
        "bias": float(rows_5f["bias"].mean()),
        "rmsle": float(rows_5f["rmsle"].mean()),
    }

    return {
        "fold4_leg": bench_fold4_leg,
        "fold4_rint": bench_fold4_rint,
        "5fold_rint": bench_5f_rint,
    }


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")

    import argparse
    parser = argparse.ArgumentParser(description="Chronos-2 LoRA Fine-Tuning Protocol on Fold 4")
    parser.add_argument("--model", choices=["small", "full"], default="small", help="Model size: 'small' (28M) or 'full' (120M)")
    parser.add_argument("--run-id", type=str, default="pilot", help="Unique run identifier (default: 'pilot')")
    args = parser.parse_args()

    run_id = args.run_id
    print("=" * 80)
    print(f"CONTROLLED EXPERIMENT: CHRONOS-2 LORA FINE-TUNING (FOLD 4) - MODEL: {args.model.upper()} [RUN_ID: {run_id}]")
    print("=" * 80)

    # 1. Environment & Library versions
    import transformers
    import peft
    import accelerate
    import chronos

    print("\n--- Environment & Versions ---")
    print(f"PyTorch: {torch.__version__}")
    print(f"CUDA available: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"GPU: {torch.cuda.get_device_name(0)}")
        print(f"Initial VRAM allocated: {torch.cuda.memory_allocated() / (1024**2):.2f} MB")
    print(f"Transformers: {transformers.__version__}")
    print(f"PEFT: {peft.__version__}")
    print(f"Accelerate: {accelerate.__version__}")
    print(f"Chronos: {chronos.__version__}")

    # 2. Check Model Weights (Strict protocol: NO fallback when full is requested)
    print(f"\n--- Checking Selected Model ({args.model.upper()}) Weights & Architecture ---")
    if args.model == "full":
        full_weights_dir = ROOT / 'experiments' / 'model_improvements' / 'chronos2_weights'
        full_safetensors = full_weights_dir / 'model.safetensors'
        full_config_file = full_weights_dir / 'config.json'

        # Requirement 6: Check configuration
        if not full_config_file.exists():
            raise FileNotFoundError(
                f"Full Chronos-2 (120M) config not found at {full_config_file}. "
                "Status: NEED_PRETRAINED_WEIGHTS."
            )
        with open(full_config_file, 'r', encoding='utf-8') as f:
            cfg = json.load(f)

        if (
            cfg.get("architectures") != ["Chronos2Model"]
            or cfg.get("d_model") != 768
            or cfg.get("num_layers") != 12
            or cfg.get("num_heads") != 12
            or cfg.get("d_ff") != 3072
        ):
            raise ValueError(
                f"Full Chronos-2 (120M) config validation failed: {cfg}. "
                "Expected architectures=['Chronos2Model'], d_model=768, num_layers=12, num_heads=12, d_ff=3072."
            )
        print(f"Verified {full_config_file.name}: architecture=Chronos2Model, d_model=768, num_layers=12, heads=12, d_ff=3072")

        # Requirement 6: Check expected file size and SHA256 (official amazon/chronos-2)
        EXPECTED_120M_SIZE = 477930472
        EXPECTED_120M_SHA256 = "ddcda3c7508bf2528087723e98a20707cc04b7f370ae275a9fd88078ddba4f42"

        if not full_safetensors.exists():
            raise FileNotFoundError(
                f"Full Chronos-2 (120M) pretrained weights not found at {full_safetensors}. "
                "Automatic fallback to Small is strictly forbidden by protocol. "
                "Status: NEED_PRETRAINED_WEIGHTS."
            )

        actual_size = full_safetensors.stat().st_size
        if actual_size != EXPECTED_120M_SIZE:
            raise ValueError(
                f"Full Chronos-2 (120M) weights size mismatch: got {actual_size:,} bytes, "
                f"expected official {EXPECTED_120M_SIZE:,} bytes. Status: NEED_PRETRAINED_WEIGHTS."
            )

        weights_sha = sha256_file(full_safetensors)
        if weights_sha.lower() != EXPECTED_120M_SHA256.lower():
            raise ValueError(
                f"Full Chronos-2 (120M) SHA256 mismatch: got {weights_sha}, "
                f"expected {EXPECTED_120M_SHA256}. Status: NEED_PRETRAINED_WEIGHTS."
            )

        active_weights_dir = full_weights_dir
        model_name = "Chronos-2 (120M)"
        model_tag = "chronos2_120m"
        print(f"Verified {model_name}: size={actual_size:,} bytes, SHA256={weights_sha}")
        status_weights = "CONFIRMED_PRETRAINED_FULL_120M"
    else:
        small_weights_dir = ROOT / 'experiments' / 'urgent_models' / 'chronos2_small'
        small_safetensors = small_weights_dir / 'model.safetensors'
        if not small_safetensors.exists() or small_safetensors.stat().st_size < 1000:
            raise FileNotFoundError(f"Chronos-2 Small weights missing at {small_weights_dir}!")
        active_weights_dir = small_weights_dir
        model_name = "Chronos-2 Small (28M)"
        model_tag = "chronos2_small_28m"
        weights_sha = sha256_file(small_safetensors)
        print(f"Verified {model_name}: size={small_safetensors.stat().st_size:,} bytes, SHA256={weights_sha}")
        status_weights = "CONFIRMED_PRETRAINED_SMALL_28M"

    # 3. Setup strictly isolated output directories (Requirement 1)
    out_dir = ROOT / 'experiments' / 'chronos_lora_fold4'
    ckpt_dir = out_dir / 'checkpoint' / model_tag
    trainer_output_dir = out_dir / 'trainer_output' / f"{model_tag}_{run_id}"
    keyed_dir = out_dir / 'keyed_predictions' / model_tag
    logs_dir = out_dir / 'logs' / model_tag
    for d in [out_dir, ckpt_dir, trainer_output_dir, keyed_dir, logs_dir]:
        d.mkdir(parents=True, exist_ok=True)

    ckpt_name = f"lora_fold4_{run_id}_ckpt"
    keyed_filename = f"{model_tag}_lora_fold4_{run_id}_keyed.csv.gz"
    json_filename = f"{model_tag}_lora_fold4_{run_id}_results.json"
    summary_filename = f"{model_tag}_lora_fold4_{run_id}_summary.csv"

    # 4. Load Weekly Dataset
    print("\n--- Loading Dataset & Setting Strict Splits ---")
    data_path = ROOT / 'weekly_data' / 'weekly_dataset.csv.gz'
    data = pd.read_csv(data_path, parse_dates=['week'])
    panel = data.pivot(index='week', columns=['warehouse_name', 'article'], values='quantity').sort_index()
    n_wks, n_pairs = panel.shape
    pairs_df = panel.columns.to_frame(index=False)
    print(f"Dataset panel shape: {n_wks} weeks, {n_pairs} series")

    # Time splits
    # Fold 4: origin = 89 (week: 2025-09-15)
    # External test: [origin, origin + HORIZON) = [89, 98) (2025-09-15 to 2025-11-10)
    # Internal val:  [origin - HORIZON, origin) = [80, 89) (2025-07-14 to 2025-09-08)
    # Train history: [0, origin - HORIZON)      = [0, 80)
    val_weeks = panel.index[ORIGIN : ORIGIN + HORIZON].strftime('%Y-%m-%d')
    int_val_weeks = panel.index[ORIGIN - HORIZON : ORIGIN].strftime('%Y-%m-%d')

    print(f"Fold: {FOLD}, Origin: {ORIGIN}")
    print(f"External Evaluation window: {val_weeks[0]} to {val_weeks[-1]} (9 weeks, weeks {ORIGIN}..{ORIGIN + HORIZON - 1})")
    print(f"Internal Validation window: {int_val_weeks[0]} to {int_val_weeks[-1]} (9 weeks, weeks {ORIGIN - HORIZON}..{ORIGIN - 1})")
    print(f"Training history window:   weeks 0 to {ORIGIN - HORIZON - 1} (length {ORIGIN - HORIZON} weeks, strictly BEFORE internal val)")

    # Prepare 3D tensors: shape (n_series, 1, history_length)
    train_history = panel.iloc[: ORIGIN - HORIZON].values.T[:, None, :]  # shape: (8789, 1, 80)
    val_history   = panel.iloc[: ORIGIN].values.T[:, None, :]             # shape: (8789, 1, 89)

    train_tensor = torch.tensor(train_history, dtype=torch.float32)
    val_tensor   = torch.tensor(val_history, dtype=torch.float32)
    print(f"Train tensor shape: {train_tensor.shape}")
    print(f"Validation tensor shape: {val_tensor.shape}")

    # Strict temporal isolation verification (Requirement 4)
    train_history_len = train_history.shape[2]
    val_history_len = val_history.shape[2]
    assert train_history_len == (ORIGIN - HORIZON), f"Train history length mismatch: {train_history_len} != {ORIGIN - HORIZON}"
    assert val_history_len == ORIGIN, f"Validation history length mismatch: {val_history_len} != {ORIGIN}"
    # In Chronos-2, training target windows are sampled strictly within train_tensor.
    # Maximum training target index inside train_tensor is train_history_len - 1 = 79.
    # Internal validation target window starts at week ORIGIN - HORIZON = 80.
    # Therefore: train_target_max_week (79) < internal_val_start_week (80). Zero overlap!
    assert (train_history_len - 1) < (ORIGIN - HORIZON), "Temporal leakage: train targets overlap with internal validation!"
    assert (ORIGIN - 1) < ORIGIN, "Temporal leakage: validation overlaps with external test!"
    print(f"Temporal isolation verified: train target max week index = {train_history_len - 1} < internal val start = {ORIGIN - HORIZON} < external eval start = {ORIGIN}.")

    # 5. Load Pipeline fresh
    print("\n--- Initializing Pipeline & Model ---")
    torch.manual_seed(42 + FOLD)
    np.random.seed(42 + FOLD)

    pipe = Chronos2Pipeline.from_pretrained(
        str(active_weights_dir),
        device_map='cuda',
        local_files_only=True
    )
    base_model = pipe.model
    total_base_params = sum(p.numel() for p in base_model.parameters())
    quantiles = list(base_model.chronos_config.quantiles)
    qi_med = int(np.argmin(np.abs(np.asarray(quantiles) - 0.5)))
    print(f"Base model loaded fresh. Total base parameters: {total_base_params:,}")

    # 6. LoRA Configuration
    lora_config = LoraConfig(
        r=8,
        lora_alpha=16,
        target_modules=[
            "self_attention.q",
            "self_attention.v",
            "self_attention.k",
            "self_attention.o",
            "output_patch_embedding.output_layer",
        ],
    )

    # Check PEFT parameters upfront
    peft_test_model = get_peft_model(base_model, lora_config)
    n_trainable_params, n_total_params = peft_test_model.get_nb_trainable_parameters()
    print(f"LoRA Target Modules: {lora_config.target_modules}")
    print(f"LoRA Rank r={lora_config.r}, alpha={lora_config.lora_alpha}")
    print(f"Trainable parameters: {n_trainable_params:,} / {n_total_params:,} ({100 * n_trainable_params / n_total_params:.2f}%)")

    # Reload fresh pipeline to avoid state contamination from test get_peft_model
    del peft_test_model
    del pipe
    torch.cuda.empty_cache()

    pipe = Chronos2Pipeline.from_pretrained(
        str(active_weights_dir),
        device_map='cuda',
        local_files_only=True
    )

    # 7. Fine-Tuning Execution
    print("\n--- Starting Fine-Tuning with LoRA ---")
    print(f"Parameters: steps={STEPS}, lr={LR}, context_length={CONTEXT}, horizon={HORIZON}")
    print(f"Batch size={BATCH_SIZE}, gradient_accumulation_steps={GRAD_ACCUM}")

    loss_callback = LossLoggingCallback()
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    t_train_start = time.perf_counter()

    ft_pipe = pipe.fit(
        inputs=train_tensor,
        validation_inputs=val_tensor,
        prediction_length=HORIZON,
        context_length=CONTEXT,
        finetune_mode="lora",
        lora_config=lora_config,
        learning_rate=LR,
        num_steps=STEPS,
        batch_size=BATCH_SIZE,
        output_dir=trainer_output_dir,
        finetuned_ckpt_name=ckpt_name,
        callbacks=[loss_callback],
        logging_steps=LOG_STEPS,
        eval_steps=EVAL_STEPS,
        save_steps=EVAL_STEPS,
        gradient_accumulation_steps=GRAD_ACCUM,
    )

    torch.cuda.synchronize()
    t_train_elapsed = time.perf_counter() - t_train_start
    train_peak_vram_mb = torch.cuda.max_memory_allocated() / (1024 ** 2)
    print(f"Fine-tuning completed in {t_train_elapsed:.2f} s ({t_train_elapsed / 60:.2f} min)")
    print(f"Peak VRAM during training: {train_peak_vram_mb:.2f} MB")

    # Extract train and eval losses
    train_losses = []
    eval_losses = []
    for l in loss_callback.logs:
        if 'loss' in l and 'eval_loss' not in l:
            train_losses.append({'step': l.get('global_step'), 'loss': float(l['loss']), 'lr': float(l.get('learning_rate', 0))})
            print(f"  Step {l.get('global_step'):3d} | Train Loss: {float(l['loss']):.4f} | LR: {float(l.get('learning_rate', 0)):.2e}")
        elif 'eval_loss' in l:
            eval_losses.append({'step': l.get('global_step'), 'eval_loss': float(l['eval_loss'])})
            print(f"  Step {l.get('global_step'):3d} | Internal Validation Loss: {float(l['eval_loss']):.4f}")

    final_train_loss = train_losses[-1]['loss'] if train_losses else None
    final_eval_loss = eval_losses[-1]['eval_loss'] if eval_losses else None

    # 8. External Inference
    print("\n--- External Inference on Fold 4 Forecast Horizon ---")
    ext_context_slice = panel.iloc[ORIGIN - CONTEXT : ORIGIN].values.T[:, None, :] # (8789, 1, 52)
    ext_context_tensor = torch.tensor(ext_context_slice, dtype=torch.float32)

    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    t_inf_start = time.perf_counter()

    with torch.inference_mode():
        predictions = ft_pipe.predict(
            ext_context_tensor,
            prediction_length=HORIZON,
            batch_size=256,
            context_length=CONTEXT,
            cross_learning=False
        )

    torch.cuda.synchronize()
    t_inf_elapsed = time.perf_counter() - t_inf_start
    inf_peak_vram_mb = torch.cuda.max_memory_allocated() / (1024 ** 2)
    print(f"Inference completed in {t_inf_elapsed:.2f} s")
    print(f"Inference peak VRAM: {inf_peak_vram_mb:.2f} MB")

    # Shape: (8789, len(quantiles), 9)
    pred_arr = np.stack([p[0].detach().cpu().numpy() for p in predictions])
    print(f"Predictions array shape: {pred_arr.shape}")

    # 9. Format Keyed Predictions
    print("\n--- Constructing Keyed Predictions & Integrity Verification ---")
    keys_expanded = pd.concat([pairs_df] * HORIZON, ignore_index=True)
    keys_expanded.insert(0, 'week', np.repeat(val_weeks, n_pairs))

    records_truth = []
    records_mean13 = []
    records_preds_q = {q: [] for q in quantiles}

    for h, w_str in enumerate(val_weeks):
        actual_y = panel.iloc[ORIGIN + h].values
        m13 = panel.iloc[ORIGIN - 13 : ORIGIN].mean().values
        records_truth.append(actual_y)
        records_mean13.append(m13)
        for q_idx, q in enumerate(quantiles):
            records_preds_q[q].append(pred_arr[:, q_idx, h])

    y_true = np.concatenate(records_truth)
    y_mean13 = np.concatenate(records_mean13)
    y_med_raw = np.maximum(0.0, np.concatenate(records_preds_q[quantiles[qi_med]]))
    y_rint = np.rint(y_med_raw)
    y_leg = apply_p(y_med_raw, 1.05, 0.65)

    keyed_df = keys_expanded.copy()
    keyed_df['y_true'] = y_true
    keyed_df['unconstrained_demand_13'] = y_mean13
    keyed_df['y_pred_continuous'] = y_med_raw
    keyed_df['y_pred_rint'] = y_rint
    keyed_df['y_pred_legacy_p'] = y_leg

    for q in quantiles:
        keyed_df[f'q_{q:g}'] = np.concatenate(records_preds_q[q])

    # Integrity assertions
    assert len(keyed_df) == 79101, f"Expected 79,101 rows, got {len(keyed_df)}"
    assert not keyed_df.duplicated(subset=KEYS).any(), "Duplicate keys found!"
    assert not keyed_df[KEYS].isna().any().any(), "NaN found in keys!"
    assert np.isfinite(y_med_raw).all(), "Non-finite values in continuous predictions!"
    assert np.isfinite(y_rint).all(), "Non-finite values in rint predictions!"
    assert np.isfinite(y_leg).all(), "Non-finite values in legacy_p predictions!"
    print(f"Integrity check PASSED: exactly {len(keyed_df):,} rows, unique keys, no NaN/inf.")

    # Save keyed predictions (Strictly isolated by model_tag and run_id)
    keyed_path = keyed_dir / keyed_filename
    keyed_df.to_csv(keyed_path, index=False, compression='gzip')
    print(f"Keyed predictions saved: {keyed_path.name} ({keyed_path.stat().st_size:,} bytes)")

    # 10. Metric Evaluation
    print("\n--- Metric Evaluation ---")
    truth_df = keys_expanded.copy(); truth_df['quantity'] = y_true
    mean13_df = keys_expanded.copy(); mean13_df['quantity'] = y_mean13
    m_base = compute_all_metrics_fast(truth_df, mean13_df)
    print(f"Mean13 Baseline Fold 4: SMAPE={m_base['smape']:.3f}%, WAPE={m_base['wape']:.3f}%, RMSE={m_base['rmse']:.4f}, Bias={m_base['bias']:.3f}%, RMSLE={m_base['rmsle']:.4f}")

    variants = {
        'rint': y_rint,
        'legacy_p': y_leg,
        'continuous_raw': y_med_raw,
    }

    eval_results = {}
    for v_name, v_pred in variants.items():
        pred_df = keys_expanded.copy(); pred_df['quantity'] = v_pred
        # Requirement 2: Strict verification of key uniqueness, completeness and full matching
        verify_exact_and_unique_keys(truth_df, pred_df, expected_rows=79101)
        m = compute_all_metrics_fast(truth_df, pred_df)
        sc_clip, sc_unclip = calc_scores(m, m_base)
        eval_results[v_name] = {
            'clipped_score': sc_clip,
            'unclipped_ratio': sc_unclip,
            'smape': m['smape'],
            'wape': m['wape'],
            'rmse': m['rmse'],
            'bias': m['bias'],
            'rmsle': m['rmsle'],
        }
        print(f"  [{v_name:15s}] Clipped: {sc_clip:.6f} | Unclipped: {sc_unclip:.6f} | SMAPE: {m['smape']:.3f}% | WAPE: {m['wape']:.3f}% | RMSE: {m['rmse']:.4f} | Bias: {m['bias']:.3f}% | RMSLE: {m['rmsle']:.4f}")

    # 11. Comparison with Control Benchmarks
    # Fold 4 control from current champion Scale_1M_Dual_0.5
    control_ensemble_fold4 = {
        'clipped_score': 0.736573,
        'unclipped_ratio': 0.773500,
        'smape': 64.685983,
        'wape': 51.432570,
        'rmse': 3.081258,
        'bias': 79.065592,
        'rmsle': 0.549929,
    }

    # Requirement 1 & 3: Dynamic loading of Full FT benchmark records from CSV
    bench_csv = ROOT / "experiments" / "chronos_finetune" / "chronos2_finetuned_benchmark_summary.csv"
    ft_benchmarks = load_full_ft_benchmarks(bench_csv, target_fold=FOLD)
    control_small_full_ft_fold4_leg = ft_benchmarks["fold4_leg"]
    control_small_full_ft_fold4_rint = ft_benchmarks["fold4_rint"]
    control_small_full_ft_5fold_rint = ft_benchmarks["5fold_rint"]

    # 12. Save Complete Experiment JSON & Summary CSV
    report = {
        'experiment_name': f'{model_tag}_lora_fold4',
        'model_loaded': model_name,
        'weights_status': status_weights,
        'fold': FOLD,
        'origin': ORIGIN,
        'external_window': [val_weeks[0], val_weeks[-1]],
        'internal_val_window': [int_val_weeks[0], int_val_weeks[-1]],
        'training_history_end': ORIGIN - HORIZON,
        'parameters': {
            'context_length': CONTEXT,
            'prediction_length': HORIZON,
            'learning_rate': LR,
            'num_steps': STEPS,
            'batch_size': BATCH_SIZE,
            'gradient_accumulation_steps': GRAD_ACCUM,
            'effective_batch_size': BATCH_SIZE * GRAD_ACCUM,
        },
        'lora': {
            'applied': True,
            'rank': lora_config.r,
            'alpha': lora_config.lora_alpha,
            'target_modules': list(lora_config.target_modules) if isinstance(lora_config.target_modules, set) else lora_config.target_modules,
            'trainable_params': n_trainable_params,
            'total_params': n_total_params,
            'trainable_pct': float(100 * n_trainable_params / n_total_params),
        },
        'resources': {
            'train_sec': t_train_elapsed,
            'inference_sec': t_inf_elapsed,
            'train_peak_vram_mb': train_peak_vram_mb,
            'inf_peak_vram_mb': inf_peak_vram_mb,
        },
        'training_loss_history': train_losses,
        'internal_val_loss_history': eval_losses,
        'final_train_loss': final_train_loss,
        'final_eval_loss': final_eval_loss,
        'evaluation': eval_results,
        'controls': {
            'ensemble_scale_1m_dual_fold4': control_ensemble_fold4,
            'chronos2_small_full_ft_fold4_rint': control_small_full_ft_fold4_rint,
            'chronos2_small_full_ft_fold4_leg': control_small_full_ft_fold4_leg,
            'chronos2_small_full_ft_5fold_rint': control_small_full_ft_5fold_rint,
        },
        'paths': {
            'code': 'run_chronos_lora_fold4.py',
            'checkpoint': str(Path('experiments/chronos_lora_fold4/checkpoint') / model_tag / ckpt_name),
            'trainer_output': str(Path('experiments/chronos_lora_fold4/trainer_output') / f"{model_tag}_{run_id}"),
            'keyed_predictions': str(Path('experiments/chronos_lora_fold4/keyed_predictions') / model_tag / keyed_filename),
            'log_json': str(Path('experiments/chronos_lora_fold4/logs') / model_tag / json_filename),
            'manifest': 'experiments/chronos_lora_fold4/manifest.json',
        }
    }

    # Save JSON strictly in model_tag logs directory (isolated, no un-namespaced overwriting)
    with open(logs_dir / json_filename, 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    summary_rows = []
    for v_name, res in eval_results.items():
        summary_rows.append({
            'model': f"{model_name}_LoRA",
            'variant': v_name,
            **res,
            'train_sec': t_train_elapsed,
            'train_peak_vram_mb': train_peak_vram_mb,
        })
    summary_rows.append({
        'model': 'Control_Ensemble_Scale_1M_Dual_0.5',
        'variant': 'tests_champion',
        **control_ensemble_fold4,
        'train_sec': None,
        'train_peak_vram_mb': None,
    })
    summary_rows.append({
        'model': 'Chronos2_Small_Full_FT_Fold4',
        'variant': 'rint',
        **control_small_full_ft_fold4_rint,
        'train_sec': None,
        'train_peak_vram_mb': None,
    })
    summary_rows.append({
        'model': 'Chronos2_Small_Full_FT_Fold4',
        'variant': 'legacy_p',
        **control_small_full_ft_fold4_leg,
        'train_sec': None,
        'train_peak_vram_mb': None,
    })
    summary_rows.append({
        'model': 'Chronos2_Small_Full_FT_5Fold_Avg',
        'variant': 'rint',
        **control_small_full_ft_5fold_rint,
        'train_sec': None,
        'train_peak_vram_mb': None,
    })

    pd.DataFrame(summary_rows).to_csv(logs_dir / summary_filename, index=False)
    print(f"\nResults JSON saved to {logs_dir / json_filename}")
    print(f"Summary CSV saved to {logs_dir / summary_filename}")

    print("\n" + "=" * 80)
    print("EXPERIMENT COMPLETED SUCCESSFULLY")
    print("=" * 80)


if __name__ == '__main__':
    main()
