import pandas as pd
df_sales = pd.read_csv('sales_dataset_hakaton_train.csv')
df_stock = pd.read_csv('stock_dataset_hakaton_train.csv')

top_pairs = df_sales.groupby(['warehouse_name', 'article'])['quantity'].sum().reset_index().sort_values('quantity', ascending=False)
sample_wh = top_pairs.iloc[0]['warehouse_name']
sample_art = top_pairs.iloc[0]['article']
print(f"Top 1 pair: warehouse={sample_wh}, article={sample_art}")

s_sub = df_sales[(df_sales['warehouse_name'] == sample_wh) & (df_sales['article'] == sample_art)]
s_agg = s_sub.groupby('date')['quantity'].sum().reset_index()

st_sub = df_stock[(df_stock['warehouse_name'] == sample_wh) & (df_stock['article'] == sample_art)]

m = s_agg.merge(st_sub, on='date', how='outer').sort_values('date')
m['quantity'] = m['quantity'].fillna(0)
m['stock'] = m['stock'].fillna(0)

print("\nПример строк (date, quantity, stock):")
print(m.head(20).to_string())

q_gt_s = m[m['quantity'] > m['stock']]
print(f"\nВсего строк в m: {len(m)}")
print(f"Строк, где quantity > stock: {len(q_gt_s)}")
print("\nПервые 10 строк, где quantity > stock:")
print(q_gt_s.head(10).to_string())

# Глобальная статистика по всей базе:
print("\n" + "="*50)
print("Глобальная проверка по всему датасету:")
sales_agg = df_sales.groupby(['date', 'warehouse_name', 'article'], as_index=False)['quantity'].sum()
global_m = sales_agg.merge(df_stock, on=['date', 'warehouse_name', 'article'], how='left')
global_m['stock'] = global_m['stock'].fillna(0)
glob_q_gt_s = (global_m['quantity'] > global_m['stock']).sum()
print(f"Всего строк продаж: {len(global_m):,}")
print(f"Строк, где quantity > stock: {glob_q_gt_s:,} ({glob_q_gt_s/len(global_m)*100:.2f}%)")
print(f"Строк, где quantity > 0, но stock == 0: {((global_m['quantity'] > 0) & (global_m['stock'] == 0)).sum():,}")
