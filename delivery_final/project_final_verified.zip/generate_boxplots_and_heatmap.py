"""Корректные графики распределений и корреляций (5–6)."""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


plt.style.use("seaborn-v0_8-whitegrid")
plt.rcParams["font.sans-serif"] = "DejaVu Sans"

print("Загрузка и подготовка полной дневной сетки...")
sales_raw = pd.read_csv(
    "sales_dataset_hakaton_train.csv",
    usecols=["date", "warehouse_name", "article", "quantity"],
    parse_dates=["date"],
)
stock_raw = pd.read_csv("stock_dataset_hakaton_train.csv", parse_dates=["date"])
sales = sales_raw.groupby(["date", "warehouse_name", "article"], as_index=False)["quantity"].sum()
stock = stock_raw.groupby(["date", "warehouse_name", "article"], as_index=False)["stock"].sum()
dates = pd.date_range(sales["date"].min(), sales["date"].max(), freq="D")
pairs = pd.MultiIndex.from_product(
    [sorted(sales["warehouse_name"].unique()), sorted(sales["article"].unique())],
    names=["warehouse_name", "article"],
)
target_pivot = sales.pivot(index="date", columns=["warehouse_name", "article"], values="quantity").reindex(index=dates, columns=pairs).fillna(0)
target = target_pivot.to_numpy(dtype=np.float32)


# 5. Два главных распределения: разреженность таргета и остатки.
print("График 5: распределения...")
flat = target.ravel()
stock_values = stock["stock"].to_numpy()
fig, axes = plt.subplots(1, 2, figsize=(14, 5.5), dpi=250)
zero_share = float((flat == 0).mean())
axes[0].bar(["Нулевая продажа", "Есть продажа"], [zero_share * 100, (1 - zero_share) * 100], color=["#A0AEC0", "#4A90E2"])
axes[0].set_ylabel("Доля всех дней × складов × товаров, %")
axes[0].set_title("Разреженность дневного таргета", fontweight="bold")
for i, value in enumerate([zero_share, 1 - zero_share]):
    axes[0].text(i, value * 100 + 1, f"{value * 100:.1f}%", ha="center", fontweight="bold")

# Понятные интервалы вместо логарифмической оси 10^0, 10^1, 10^2.
bucket_names = ["≤0", "1–5", "6–20", "21–100", ">100"]
bucket_masks = [
    stock_values <= 0,
    (stock_values >= 1) & (stock_values <= 5),
    (stock_values >= 6) & (stock_values <= 20),
    (stock_values >= 21) & (stock_values <= 100),
    stock_values > 100,
]
bucket_shares = np.array([mask.mean() * 100 for mask in bucket_masks])
bars = axes[1].bar(bucket_names, bucket_shares, color="#DD6B20", alpha=0.85)
for bar, value in zip(bars, bucket_shares):
    axes[1].text(bar.get_x() + bar.get_width() / 2, value + 0.8, f"{value:.1f}%", ha="center", fontweight="bold")
axes[1].set_xlabel("Агрегированный дневной остаток, единиц")
axes[1].set_ylabel("Доля записей, %")
axes[1].set_title("Остатки после агрегации дублей", fontweight="bold")
fig.suptitle("Нули в продажах и складских остатках", fontsize=16, fontweight="bold")
fig.tight_layout()
fig.savefig("plot_5_boxplots_distribution.png")
plt.close(fig)


# 6. Корреляции только с доступными лаговыми признаками.
print("График 6: лаговые корреляции без утечки...")
stock_pivot = stock.pivot(index="date", columns=["warehouse_name", "article"], values="stock").reindex(index=dates, columns=pairs)
stock_matrix = stock_pivot.to_numpy(dtype=np.float32)
rng = np.random.default_rng(42)
n_dates, n_series = target.shape
available_positions = (n_dates - 56) * n_series
sample_size = min(250_000, available_positions)
flat_positions = rng.choice(available_positions, size=sample_size, replace=False)
date_pos = flat_positions // n_series + 56
series_pos = flat_positions % n_series
lag_matrix_7 = np.column_stack([target[date_pos - offset, series_pos] for offset in range(1, 8)])
lag_matrix_28 = np.column_stack([target[date_pos - offset, series_pos] for offset in range(1, 29)])
sample = pd.DataFrame({
    "quantity": target[date_pos, series_pos],
    "lag_1": target[date_pos - 1, series_pos],
    "lag_7": target[date_pos - 7, series_pos],
    "lag_28": target[date_pos - 28, series_pos],
    "mean_7": lag_matrix_7.mean(axis=1),
    "mean_28": lag_matrix_28.mean(axis=1),
    "nonzero_rate_28": (lag_matrix_28 > 0).mean(axis=1),
    "stock_lag_1": stock_matrix[date_pos - 1, series_pos],
    "dayofweek": dates[date_pos].dayofweek,
    "month": dates[date_pos].month,
})
corr = sample.corr(method="spearman")
fig, ax = plt.subplots(figsize=(10, 8), dpi=250)
mask = np.triu(np.ones_like(corr, dtype=bool))
sns.heatmap(
    corr, mask=mask, cmap=sns.diverging_palette(230, 20, as_cmap=True),
    vmin=-0.8, vmax=0.8, center=0, square=True, linewidths=0.5,
    annot=True, fmt=".2f", cbar_kws={"shrink": 0.8}, ax=ax,
)
ax.set_title("Корреляции доступных до прогноза признаков\nВсе продажи и rolling-признаки сдвинуты минимум на 1 день", fontsize=14, fontweight="bold")
fig.tight_layout()
fig.savefig("plot_6_correlation_heatmap.png")
plt.close(fig)

print("Графики 5–6 пересозданы.")
