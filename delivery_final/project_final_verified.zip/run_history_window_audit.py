#!/usr/bin/env python3
"""
run_history_window_audit.py

Executes:
1. Standardized baseline evaluation (legacy_oof_frozen vs inference_matched_baseline).
2. Training history length ablation for bottom-level LightGBM (Variants A, B, C).
3. Pre-fold-0 candidate selection based on expanding Folds 4..1 unclipped_ratio.
4. Network-level test (Article Total): history ablation, network vs sum of bottom,
   and one-by-one feature tests (article categorical, seasonal lag52, robust stock).
5. Multi-seed robustness check (seeds 42, 52, 62), error breakdown by horizon 1..9,
   demand segments, and generation of all artifacts.
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
import time
from pathlib import Path

# Add project root and sber_hak
PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(PROJECT_ROOT / "sber_hak"))

import numpy as np
import pandas as pd
import lightgbm as lgb

from fast_score import compute_all_metrics_fast, METRIC_WEIGHTS
from score import normalized_score
from run_weekly_feature_experiments import (
    HORIZON,
    KEYS,
    CAT_COLUMNS,
    WeeklyMatrices,
    columns_for_experiment,
    make_truth,
)
from train_tft_weekly import baseline_mean13
from history_audit_pipeline import (
    compute_metrics_with_diagnostics,
    predict_from_components,
    train_lgbm_history_variant,
)

# Output directories
OUTPUT_DIR = PROJECT_ROOT / "experiments" / "history_window_audit"
KEYED_OOF_DIR = OUTPUT_DIR / "keyed_oof"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
KEYED_OOF_DIR.mkdir(parents=True, exist_ok=True)

FOLD_ORIGINS = {
    0: 125,  # 2026-05-25 — 2026-07-20
    1: 116,  # 2026-03-23 — 2026-05-18
    2: 107,  # 2026-01-19 — 2026-03-16
    3: 98,   # 2025-11-17 — 2026-01-12
    4: 89,   # 2025-09-15 — 2025-11-10
}

LEGACY_FROZEN_SCORES = {
    0: 0.717057,
    1: 0.734432,
    2: 0.725229,
    3: 0.745089,
    4: 0.740054,
}


def load_dataset() -> tuple[pd.DataFrame, WeeklyMatrices, list[pd.Timestamp]]:
    data_path = PROJECT_ROOT / "weekly_data" / "weekly_dataset.csv.gz"
    print(f"Loading dataset from {data_path}...")
    data = pd.read_csv(data_path, parse_dates=["week"])
    matrices = WeeklyMatrices(data)
    weeks = sorted(data["week"].unique())
    return data, matrices, weeks


def run_audit() -> None:
    print("=" * 80)
    print("AUDIT: PIPELINE STANDARDIZATION & TRAINING HISTORY LENGTH ABLATION")
    print("=" * 80)

    data, matrices, weeks = load_dataset()

    # Precompute baseline_mean13 for each fold
    print("\nPrecomputing mean13 baselines and ground truth for all 5 folds...")
    fold_truth = {}
    fold_baseline = {}
    for fold, origin in FOLD_ORIGINS.items():
        val_weeks = weeks[origin : origin + HORIZON]
        truth = make_truth(matrices, origin)
        truth["week"] = pd.to_datetime(truth["week"]).dt.strftime("%Y-%m-%d")
        b_df = baseline_mean13(data, pd.Timestamp(val_weeks[0]), pd.Index(val_weeks))
        b_df["week"] = pd.to_datetime(b_df["week"]).dt.strftime("%Y-%m-%d")
        fold_truth[fold] = truth
        fold_baseline[fold] = b_df

    # -------------------------------------------------------------------------
    # PART 1: Standardized Baseline Evaluation
    # -------------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("PART 1: STANDARDIZE BASELINES (Legacy Frozen vs Inference-Matched)")
    print("=" * 80)

    component_records = []
    blend_records = []

    # Config for legacy frozen
    legacy_config = {
        "name": "legacy_oof_frozen",
        "components": {
            "tft": {"weight": 0.50, "type": "raw"},
            "lgbm": {"weight": 0.30, "type": "two_stage", "prob_gate": 0.5, "comp_postprocess": "bench_lgbm"},
            "catboost": {"weight": 0.10, "type": "two_stage", "prob_gate": 0.5, "comp_postprocess": "bench_cb"},
            "per_category": {"weight": 0.10, "type": "two_stage", "prob_gate": None, "comp_postprocess": None},
        },
        "blend": {"alpha": 1.05, "threshold": 0.65, "rounding": "rint", "clip_lower": 0.0},
    }

    # Config for inference matched baseline
    inf_matched_config = {
        "name": "inference_matched_baseline",
        "components": {
            "tft": {"weight": 0.50, "type": "raw"},
            "lgbm": {"weight": 0.30, "type": "two_stage", "prob_gate": 0.5, "comp_postprocess": None},
            "catboost": {"weight": 0.10, "type": "two_stage", "prob_gate": 0.5, "comp_postprocess": None},
            "per_category": {"weight": 0.10, "type": "two_stage", "prob_gate": None, "comp_postprocess": None},
        },
        "blend": {"alpha": 1.05, "threshold": 0.65, "rounding": "rint", "clip_lower": 0.0},
    }

    # Load component outputs from meta files
    base_components_by_fold = {}
    for fold in range(5):
        meta_path = PROJECT_ROOT / "experiments" / "stacking_honest" / "fold_meta_features" / f"fold_{fold}_meta.csv.gz"
        meta = pd.read_csv(meta_path)
        meta["week"] = pd.to_datetime(meta["week"]).dt.strftime("%Y-%m-%d")

        comp_dict = {
            "tft": pd.DataFrame({
                "week": meta["week"],
                "warehouse_name": meta["warehouse_name"],
                "article": meta["article"],
                "quantity": meta["raw_tft"],
            }),
            "lgbm": pd.DataFrame({
                "week": meta["week"],
                "warehouse_name": meta["warehouse_name"],
                "article": meta["article"],
                "p_sale": meta["p_sale_lgb"],
                "q_cond": meta["q_cond_lgb"],
                "expected": meta["exp_lgb"],
            }),
            "catboost": pd.DataFrame({
                "week": meta["week"],
                "warehouse_name": meta["warehouse_name"],
                "article": meta["article"],
                "p_sale": meta["p_sale_cb"],
                "q_cond": meta["q_cond_cb"],
                "expected": meta["exp_cb"],
            }),
            "per_category": pd.DataFrame({
                "week": meta["week"],
                "warehouse_name": meta["warehouse_name"],
                "article": meta["article"],
                "p_sale": np.ones(len(meta)),
                "q_cond": meta["raw_per_cat"],
                "expected": meta["raw_per_cat"],
            }),
        }
        base_components_by_fold[fold] = comp_dict

        # Evaluate legacy frozen
        keyed_leg, sub_leg = predict_from_components(comp_dict, legacy_config)
        m_leg = compute_metrics_with_diagnostics(fold_truth[fold], sub_leg, fold_baseline[fold])
        blend_records.append({
            "variant": "legacy_oof_frozen",
            "fold": fold,
            "origin": FOLD_ORIGINS[fold],
            **m_leg,
        })

        # Evaluate inference matched baseline
        keyed_inf, sub_inf = predict_from_components(comp_dict, inf_matched_config)
        m_inf = compute_metrics_with_diagnostics(fold_truth[fold], sub_inf, fold_baseline[fold])
        blend_records.append({
            "variant": "inference_matched_baseline",
            "fold": fold,
            "origin": FOLD_ORIGINS[fold],
            **m_inf,
        })

        # Save keyed OOF for inference matched baseline
        keyed_inf["origin"] = FOLD_ORIGINS[fold]
        keyed_inf.to_csv(KEYED_OOF_DIR / f"inference_matched_fold_{fold}.csv.gz", index=False, compression="gzip")

        # Check line difference between legacy and inference matched
        diff_lines = int((sub_leg["quantity"] != sub_inf["quantity"]).sum())
        print(f"Fold {fold}: Legacy Score={m_leg['clipped_score']:.6f} (unclipped={m_leg['unclipped_ratio']:.6f}) | "
              f"Inf-Matched Score={m_inf['clipped_score']:.6f} (unclipped={m_inf['unclipped_ratio']:.6f}) | "
              f"Changed lines={diff_lines}")

    # -------------------------------------------------------------------------
    # PART 2: Training History Length Ablation (Bottom-level LightGBM)
    # -------------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("PART 2: HISTORY LENGTH ABLATION FOR BOTTOM-LEVEL LIGHTGBM (A vs B vs C)")
    print("=" * 80)

    lgbm_models = {}  # (variant, fold) -> df_pred
    lgbm_diagnostics = []

    for variant in ["A", "B", "C"]:
        print(f"\n--- Training Bottom LightGBM Variant {variant} ---")
        for fold, origin in FOLD_ORIGINS.items():
            df_pred, diag = train_lgbm_history_variant(matrices, origin, variant=variant, seed=42)
            lgbm_models[(variant, fold)] = df_pred
            lgbm_diagnostics.append(diag)

            # Standalone evaluation of LightGBM: prob_gate=0.5, threshold=0.65, round
            y_raw = np.where(df_pred["p_sale"] < 0.5, 0.0, df_pred["expected_quantity"])
            y_gated = np.where(y_raw < 0.65, 0.0, y_raw)
            y_round = np.rint(y_gated).clip(0, None)
            standalone_sub = df_pred[KEYS].copy()
            standalone_sub["quantity"] = y_round

            m_stand = compute_metrics_with_diagnostics(fold_truth[fold], standalone_sub, fold_baseline[fold])
            component_records.append({
                "model": f"LightGBM_Standalone_{variant}",
                "variant": variant,
                "fold": fold,
                "origin": origin,
                **m_stand,
            })

            # Blend evaluation: replace 30% LightGBM in inference matched baseline
            comp_variant = {
                "tft": base_components_by_fold[fold]["tft"],
                "lgbm": pd.DataFrame({
                    "week": df_pred["week"],
                    "warehouse_name": df_pred["warehouse_name"],
                    "article": df_pred["article"],
                    "p_sale": df_pred["p_sale"],
                    "q_cond": df_pred["conditional_quantity"],
                    "expected": df_pred["expected_quantity"],
                }),
                "catboost": base_components_by_fold[fold]["catboost"],
                "per_category": base_components_by_fold[fold]["per_category"],
            }
            _, sub_blend_var = predict_from_components(comp_variant, inf_matched_config)
            m_blend_var = compute_metrics_with_diagnostics(fold_truth[fold], sub_blend_var, fold_baseline[fold])
            blend_records.append({
                "variant": f"Blend_LightGBM_{variant}",
                "fold": fold,
                "origin": origin,
                **m_blend_var,
            })

            print(f"  Variant {variant} Fold {fold}: "
                  f"Standalone Score={m_stand['clipped_score']:.6f} (unclipped={m_stand['unclipped_ratio']:.6f}) | "
                  f"Blend Score={m_blend_var['clipped_score']:.6f} (unclipped={m_blend_var['unclipped_ratio']:.6f}) | "
                  f"Origins={diag['num_origins']}, Range=[{diag['min_train_target_date']}..{diag['max_train_target_date']}], "
                  f"ZeroRate={diag['zero_rate']:.3f}")

    # -------------------------------------------------------------------------
    # Selection Protocol on Expanding Folds 4..1 BEFORE looking at Fold 0
    # -------------------------------------------------------------------------
    df_blends = pd.DataFrame(blend_records)
    expanding_folds = [1, 2, 3, 4]  # folds 4..1

    mean_unclipped_expanding = {}
    mean_clipped_expanding = {}
    for var in ["A", "B", "C"]:
        sub_df = df_blends[(df_blends["variant"] == f"Blend_LightGBM_{var}") & (df_blends["fold"].isin(expanding_folds))]
        mean_unclipped_expanding[var] = float(sub_df["unclipped_ratio"].mean())
        mean_clipped_expanding[var] = float(sub_df["clipped_score"].mean())

    print("\n" + "=" * 80)
    print("SELECTION PROTOCOL ON EXPANDING FOLDS 4..1 (Excluding Fold 0):")
    print(f"  Variant A (18 origins):         Unclipped Ratio = {mean_unclipped_expanding['A']:.6f}, Clipped Score = {mean_clipped_expanding['A']:.6f}")
    print(f"  Variant B (52 origins):         Unclipped Ratio = {mean_unclipped_expanding['B']:.6f}, Clipped Score = {mean_clipped_expanding['B']:.6f}")
    print(f"  Variant C (52 origins weighted):Unclipped Ratio = {mean_unclipped_expanding['C']:.6f}, Clipped Score = {mean_clipped_expanding['C']:.6f}")

    # Determine winner strictly based on unclipped_ratio on folds 4..1
    best_candidate = "A"
    best_ratio = mean_unclipped_expanding["A"]
    for var in ["B", "C"]:
        if mean_unclipped_expanding[var] < best_ratio - 1e-6:
            best_ratio = mean_unclipped_expanding[var]
            best_candidate = var

    selection_record = {
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "selection_metric": "mean_unclipped_ratio_expanding_folds_4_to_1",
        "scores_expanding_folds_4_to_1": {
            var: {
                "unclipped_ratio": mean_unclipped_expanding[var],
                "clipped_score": mean_clipped_expanding[var],
            }
            for var in ["A", "B", "C"]
        },
        "selected_variant": best_candidate,
        "reason": (
            f"Variant {best_candidate} selected with mean unclipped_ratio={best_ratio:.6f} "
            f"(improvement vs Control A = {mean_unclipped_expanding['A'] - best_ratio:+.6f})."
            if best_candidate != "A" else
            "Variants B and C did not improve unclipped_ratio over Control A on expanding folds 4..1; keeping Control A."
        ),
    }

    # Save selected_config.json BEFORE inspecting fold 0
    selected_config_path = OUTPUT_DIR / "selected_config.json"
    with open(selected_config_path, "w", encoding="utf-8") as f:
        json.dump(selection_record, f, indent=2, ensure_ascii=False)
    print(f"\n>> Selected candidate saved to {selected_config_path}: Variant {best_candidate} <<")

    # Now inspect Fold 0 results for all variants as historical control
    print("\nHISTORICAL CONTROL EVALUATION ON FOLD 0:")
    for var in ["A", "B", "C"]:
        row = df_blends[(df_blends["variant"] == f"Blend_LightGBM_{var}") & (df_blends["fold"] == 0)].iloc[0]
        print(f"  Variant {var} Fold 0: Clipped Score = {row['clipped_score']:.6f}, Unclipped Ratio = {row['unclipped_ratio']:.6f}, SMAPE = {row['smape']:.2f}%, RMSE = {row['rmse']:.3f}")

    # -------------------------------------------------------------------------
    # PART 3: Network Level Test (Article Total)
    # -------------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("PART 3: NETWORK LEVEL TEST (Article Total)")
    print("=" * 80)

    # Build Article Aggregates
    print("Building article-level weekly aggregated datasets...")
    art_df = data.groupby(["article", "week"], as_index=False).agg({
        "quantity": "sum",
        "stock_week_end": lambda x: x.sum(min_count=1),
        "stock_mean": lambda x: x.sum(min_count=1),
        "category_lvl_1": "first",
        "category_lvl_2": "first",
        "category_lvl_3": "first",
    })

    # Pivot matrix: articles x weeks
    articles = sorted(data["article"].unique())
    n_articles = len(articles)
    art_to_idx = {a: i for i, a in enumerate(articles)}
    n_weeks = len(weeks)

    art_qty = np.zeros((n_articles, n_weeks), dtype=np.float32)
    art_stock = np.full((n_articles, n_weeks), np.nan, dtype=np.float32)
    art_stock_obs = np.zeros((n_articles, n_weeks), dtype=np.float32)

    # Pre-aggregate stock observed count per article-week
    data_stock_obs = data.dropna(subset=["stock_week_end"]).groupby(["article", "week"]).size().unstack(fill_value=0)

    for _, row in art_df.iterrows():
        a_idx = art_to_idx[row["article"]]
        w_idx = weeks.index(row["week"])
        art_qty[a_idx, w_idx] = row["quantity"]
        if pd.notna(row["stock_week_end"]):
            art_stock[a_idx, w_idx] = row["stock_week_end"]

    for a in articles:
        if a in data_stock_obs.index:
            for w in data_stock_obs.columns:
                if w in weeks:
                    art_stock_obs[art_to_idx[a], weeks.index(w)] = data_stock_obs.loc[a, w]

    cat_info = (
        data[["article", "category_lvl_1", "category_lvl_2", "category_lvl_3"]]
        .drop_duplicates("article")
        .set_index("article")
        .loc[articles]
    )

    def make_network_features(
        origin: int,
        history_len: int = 18,
        use_article_cat: bool = False,
        use_seasonal_lag52: bool = False,
        use_robust_stock: bool = False,
        sample_weights_decay: bool = False,
    ) -> tuple[pd.DataFrame, np.ndarray, pd.DataFrame]:
        """
        Builds network training and validation feature matrices for an origin.
        """
        val_start = weeks[origin]
        latest_train_origin = origin - HORIZON
        earliest_train_origin = max(26, latest_train_origin - (history_len - 1))
        train_origins = np.arange(earliest_train_origin, latest_train_origin + 1)

        def extract_for_origins(origins_list: np.ndarray, is_val: bool = False):
            rows, targets = [], []
            for org in origins_list:
                lag_1 = art_qty[:, org - 1]
                lag_2 = art_qty[:, org - 2]
                lag_4 = art_qty[:, org - 4]
                lag_13 = art_qty[:, org - 13]
                lag_26 = art_qty[:, org - 26]
                lag_52 = art_qty[:, org - 52] if org >= 52 else np.full(n_articles, np.nan, dtype=np.float32)

                mean_4 = art_qty[:, max(0, org - 4) : org].mean(axis=1)
                sum_4 = art_qty[:, max(0, org - 4) : org].sum(axis=1)
                mean_13 = art_qty[:, max(0, org - 13) : org].mean(axis=1)
                sum_13 = art_qty[:, max(0, org - 13) : org].sum(axis=1)
                mean_26 = art_qty[:, max(0, org - 26) : org].mean(axis=1)
                sum_26 = art_qty[:, max(0, org - 26) : org].sum(axis=1)
                max_13 = art_qty[:, max(0, org - 13) : org].max(axis=1)
                std_13 = art_qty[:, max(0, org - 13) : org].std(axis=1)

                growth_4_13 = (mean_4 + 1e-4) / (mean_13 + 1e-4)
                prev_13_sum = art_qty[:, max(0, org - 26) : max(0, org - 13)].sum(axis=1) if org >= 26 else sum_13
                growth_13_prev13 = (sum_13 + 1e-4) / (prev_13_sum + 1e-4)

                stock_end_lag_1 = art_stock[:, org - 1]
                stock_obs_lag_1 = art_stock_obs[:, org - 1]

                for h in range(1, HORIZON + 1):
                    t_week_idx = org + h - 1
                    t_week = weeks[t_week_idx]
                    woy = t_week.isocalendar().week
                    month = t_week.month
                    sin_week = np.sin(2 * np.pi * woy / 52.1775)
                    cos_week = np.cos(2 * np.pi * woy / 52.1775)

                    feat_dict = {
                        "article": articles,
                        "horizon": h,
                        "week_of_year": woy,
                        "month": month,
                        "sin_week": sin_week,
                        "cos_week": cos_week,
                        "category_lvl_1": cat_info["category_lvl_1"].values,
                        "category_lvl_2": cat_info["category_lvl_2"].values,
                        "category_lvl_3": cat_info["category_lvl_3"].values,
                        "lag_1": lag_1,
                        "lag_2": lag_2,
                        "lag_4": lag_4,
                        "lag_13": lag_13,
                        "lag_26": lag_26,
                        "lag_52": lag_52,
                        "mean_4": mean_4,
                        "sum_4": sum_4,
                        "mean_13": mean_13,
                        "sum_13": sum_13,
                        "mean_26": mean_26,
                        "sum_26": sum_26,
                        "max_13": max_13,
                        "std_13": std_13,
                        "growth_4_13": growth_4_13,
                        "growth_13_prev13": growth_13_prev13,
                    }

                    if use_seasonal_lag52:
                        # y[origin + h - 1 - 52] = y[t_week_idx - 52]
                        s_idx = t_week_idx - 52
                        if s_idx >= 0:
                            feat_dict["seasonal_target_lag52"] = art_qty[:, s_idx]
                            feat_dict["seasonal_target_lag52_missing"] = np.zeros(n_articles, dtype=np.float32)
                        else:
                            feat_dict["seasonal_target_lag52"] = np.full(n_articles, np.nan, dtype=np.float32)
                            feat_dict["seasonal_target_lag52_missing"] = np.ones(n_articles, dtype=np.float32)

                    if use_robust_stock:
                        feat_dict["stock_end_lag_1"] = stock_end_lag_1
                        feat_dict["stock_coverage"] = stock_obs_lag_1 / 11.0
                        feat_dict["stock_missing"] = (stock_obs_lag_1 == 0).astype(np.float32)
                    else:
                        feat_dict["stock_end_lag_1"] = np.nan_to_num(stock_end_lag_1, nan=0.0)

                    df_sub = pd.DataFrame(feat_dict)
                    rows.append(df_sub)
                    if not is_val:
                        targets.append(art_qty[:, t_week_idx])

            return pd.concat(rows, ignore_index=True), (np.concatenate(targets) if targets else None)

        X_tr, y_tr = extract_for_origins(train_origins, is_val=False)
        X_v, _ = extract_for_origins(np.array([origin]), is_val=True)

        return X_tr, y_tr, X_v

    def train_predict_network(
        X_tr: pd.DataFrame,
        y_tr: np.ndarray,
        X_v: pd.DataFrame,
        use_article_cat: bool = False,
        sample_weights: Optional[np.ndarray] = None,
        seed: int = 42,
    ) -> np.ndarray:
        cat_cols = ["category_lvl_1", "category_lvl_2", "category_lvl_3"]
        if use_article_cat:
            cat_cols.append("article")

        features = [c for c in X_tr.columns if c not in ("article",) or use_article_cat]

        X_train = X_tr[features].copy()
        X_val = X_v[features].copy()

        for c in cat_cols:
            if c in X_train.columns:
                X_train[c] = X_train[c].astype("category")
                X_val[c] = X_val[c].astype("category")

        model = lgb.LGBMRegressor(
            n_estimators=180,
            learning_rate=0.05,
            num_leaves=31,
            min_child_samples=30,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=seed,
            verbosity=-1,
            n_jobs=-1,
        )
        model.fit(X_train, np.log1p(np.maximum(y_tr, 0)), sample_weight=sample_weights)
        preds = np.expm1(model.predict(X_val)).clip(0, None)
        return preds

    # Compare Network Model vs Sum of Bottom Level (inference matched baseline)
    print("\nComparing Article Total Network Model vs Bottom-Level Sum (week x article)...")
    article_level_records = []

    network_experiments = {
        "Net_A_18w_baseline": {"history_len": 18, "use_article_cat": False, "use_seasonal_lag52": False, "use_robust_stock": False},
        "Net_B_52w_history": {"history_len": 52, "use_article_cat": False, "use_seasonal_lag52": False, "use_robust_stock": False},
        "Net_Iso1_ArticleCat": {"history_len": 18, "use_article_cat": True, "use_seasonal_lag52": False, "use_robust_stock": False},
        "Net_Iso2_SeasonalLag52": {"history_len": 18, "use_article_cat": False, "use_seasonal_lag52": True, "use_robust_stock": False},
        "Net_Iso3_RobustStock": {"history_len": 18, "use_article_cat": False, "use_seasonal_lag52": False, "use_robust_stock": True},
    }

    for exp_name, exp_cfg in network_experiments.items():
        print(f"\n--- Testing Network Experiment: {exp_name} ---")
        for fold, origin in FOLD_ORIGINS.items():
            X_tr, y_tr, X_v = make_network_features(
                origin,
                history_len=exp_cfg["history_len"],
                use_article_cat=exp_cfg["use_article_cat"],
                use_seasonal_lag52=exp_cfg["use_seasonal_lag52"],
                use_robust_stock=exp_cfg["use_robust_stock"],
            )
            net_preds = train_predict_network(X_tr, y_tr, X_v, use_article_cat=exp_cfg["use_article_cat"])

            # Build article validation ground truth (799 articles x 9 horizons = 7191 rows)
            val_weeks = weeks[origin : origin + HORIZON]
            art_truth_list = []
            for h in range(1, HORIZON + 1):
                t_idx = origin + h - 1
                for a_idx, a in enumerate(articles):
                    art_truth_list.append({
                        "article": a,
                        "week": str(weeks[t_idx].date()),
                        "horizon": h,
                        "y_true": art_qty[a_idx, t_idx],
                    })
            df_art_eval = pd.DataFrame(art_truth_list)
            df_art_eval["y_net_pred"] = net_preds

            # Sum of bottom predictions for this fold
            bottom_oof = pd.read_csv(KEYED_OOF_DIR / f"inference_matched_fold_{fold}.csv.gz")
            bottom_sum = bottom_oof.groupby(["article", "week"])["raw_blend"].sum().reset_index()
            bottom_sum = bottom_sum.rename(columns={"raw_blend": "y_bottom_sum"})

            df_art_eval = df_art_eval.merge(bottom_sum, on=["article", "week"], how="inner")

            # Compute article-level WAPE and RMSE
            y_t = df_art_eval["y_true"].values
            y_net = df_art_eval["y_net_pred"].values
            y_bot = df_art_eval["y_bottom_sum"].values

            denom = float(np.sum(y_t))
            net_wape = float(np.sum(np.abs(y_t - y_net)) / denom * 100.0) if denom > 0 else 0.0
            bot_wape = float(np.sum(np.abs(y_t - y_bot)) / denom * 100.0) if denom > 0 else 0.0

            net_rmse = float(np.sqrt(np.mean((y_t - y_net) ** 2)))
            bot_rmse = float(np.sqrt(np.mean((y_t - y_bot) ** 2)))

            article_level_records.append({
                "experiment": exp_name,
                "fold": fold,
                "origin": origin,
                "net_wape": net_wape,
                "bottom_sum_wape": bot_wape,
                "wape_diff_net_minus_bot": net_wape - bot_wape,
                "net_rmse": net_rmse,
                "bottom_sum_rmse": bot_rmse,
                "rmse_diff_net_minus_bot": net_rmse - bot_rmse,
            })

            print(f"  Fold {fold}: Net WAPE={net_wape:.2f}% (vs Bottom Sum={bot_wape:.2f}%) | "
                  f"Net RMSE={net_rmse:.2f} (vs Bottom Sum={bot_rmse:.2f})")

    df_art_metrics = pd.DataFrame(article_level_records)
    df_art_metrics.to_csv(OUTPUT_DIR / "article_level_metrics.csv", index=False)

    # -------------------------------------------------------------------------
    # PART 4: Multi-Seed Robustness Check (Seeds 42, 52, 62)
    # -------------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("PART 4: MULTI-SEED ROBUSTNESS CHECK (Seeds 42, 52, 62)")
    print("=" * 80)

    seeds = [42, 52, 62]
    seed_records = []

    # Compare Control A vs Chosen Variant across seeds
    compare_variants = ["A"] if best_candidate == "A" else ["A", best_candidate]
    print(f"Comparing variants {compare_variants} across seeds {seeds}...")

    for seed in seeds:
        print(f"\n--- Testing Seed {seed} ---")
        for var in compare_variants:
            fold_scores = []
            fold_unclipped = []
            for fold, origin in FOLD_ORIGINS.items():
                df_pred, _ = train_lgbm_history_variant(matrices, origin, variant=var, seed=seed)
                comp_var = {
                    "tft": base_components_by_fold[fold]["tft"],
                    "lgbm": pd.DataFrame({
                        "week": df_pred["week"],
                        "warehouse_name": df_pred["warehouse_name"],
                        "article": df_pred["article"],
                        "p_sale": df_pred["p_sale"],
                        "q_cond": df_pred["conditional_quantity"],
                        "expected": df_pred["expected_quantity"],
                    }),
                    "catboost": base_components_by_fold[fold]["catboost"],
                    "per_category": base_components_by_fold[fold]["per_category"],
                }
                _, sub_b = predict_from_components(comp_var, inf_matched_config)
                m = compute_metrics_with_diagnostics(fold_truth[fold], sub_b, fold_baseline[fold])
                seed_records.append({
                    "seed": seed,
                    "variant": var,
                    "fold": fold,
                    "origin": origin,
                    **m,
                })
                fold_scores.append(m["clipped_score"])
                fold_unclipped.append(m["unclipped_ratio"])

            print(f"  Variant {var} Seed {seed}: Mean Score={np.mean(fold_scores):.6f}, Mean Unclipped={np.mean(fold_unclipped):.6f}")

    df_seed_metrics = pd.DataFrame(seed_records)

    # -------------------------------------------------------------------------
    # Horizon Breakdown & Demand Segment Breakdown for Final Report
    # -------------------------------------------------------------------------
    print("\nComputing Horizon and Demand Segment Breakdown...")
    horizon_records = []
    segment_records = []

    # Historical demand segments based on fold 0 past history:
    # rare: historical nonzero rate <= 0.10
    # regular: 0.10 < rate <= 0.80
    # large: rate > 0.80 or top volume
    df_f0_truth = fold_truth[0].copy()
    df_f0_pred = pd.read_csv(KEYED_OOF_DIR / "inference_matched_fold_0.csv.gz")

    # Merge with pair static info
    meta_f0 = pd.read_csv(PROJECT_ROOT / "experiments" / "stacking_honest" / "fold_meta_features" / "fold_0_meta.csv.gz")
    merged_f0 = meta_f0[["week", "warehouse_name", "article", "horizon", "quantity_nonzero_rate_13", "target"]].copy()
    merged_f0 = merged_f0.merge(df_f0_pred[["week", "warehouse_name", "article", "final_prediction"]], on=KEYS, how="inner")

    # Segment definitions:
    merged_f0["segment"] = np.where(
        merged_f0["quantity_nonzero_rate_13"] <= 0.10, "Rare",
        np.where(merged_f0["quantity_nonzero_rate_13"] > 0.80, "Large", "Regular")
    )

    for seg in ["Rare", "Regular", "Large"]:
        sub_seg = merged_f0[merged_f0["segment"] == seg]
        yt = sub_seg["target"].values
        yp = sub_seg["final_prediction"].values
        denom = float(np.sum(yt))
        wape = float(np.sum(np.abs(yt - yp)) / denom * 100.0) if denom > 0 else 0.0
        rmse = float(np.sqrt(np.mean((yt - yp) ** 2)))
        nonzero_rate = float((yp > 0).mean())
        segment_records.append({
            "segment": seg,
            "rows": len(sub_seg),
            "wape": wape,
            "rmse": rmse,
            "nonzero_rate": nonzero_rate,
        })

    for h in range(1, 10):
        sub_h = merged_f0[merged_f0["horizon"] == h]
        yt = sub_h["target"].values
        yp = sub_h["final_prediction"].values
        denom = float(np.sum(yt))
        wape = float(np.sum(np.abs(yt - yp)) / denom * 100.0) if denom > 0 else 0.0
        rmse = float(np.sqrt(np.mean((yt - yp) ** 2)))
        horizon_records.append({
            "horizon": h,
            "rows": len(sub_h),
            "wape": wape,
            "rmse": rmse,
        })

    # Save summary csv files
    pd.DataFrame(component_records).to_csv(OUTPUT_DIR / "component_metrics.csv", index=False)
    pd.DataFrame(blend_records).to_csv(OUTPUT_DIR / "blend_metrics.csv", index=False)

    config_record = {
        "legacy_frozen_config": legacy_config,
        "inference_matched_config": inf_matched_config,
        "history_ablation_variants": {
            "A": "last 18 origins (control, equal sample weights)",
            "B": "last 52 origins (equal sample weights)",
            "C": "last 52 origins (exponential decay sample weights 2 ** (-age_weeks / 26))",
        },
        "network_experiments": network_experiments,
        "seeds_evaluated": seeds,
    }
    with open(OUTPUT_DIR / "config.json", "w", encoding="utf-8") as f:
        json.dump(config_record, f, indent=2, ensure_ascii=False)

    print("\n" + "=" * 80)
    print("ALL AUDIT CALCULATIONS FINISHED. GENERATING REPORT...")
    print("=" * 80)


if __name__ == "__main__":
    run_audit()
