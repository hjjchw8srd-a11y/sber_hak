import pandas as pd
import numpy as np

print("="*60)
print("1. ЗАГРУЗКА И АНАЛИЗ SALES DATASET")
print("="*60)

df_sales = pd.read_csv("sales_dataset_hakaton_train.csv")
print(f"Количество строк в sales: {len(df_sales):,}")
print(f"Колонки: {df_sales.columns.tolist()}")

df_sales["date"] = pd.to_datetime(df_sales["date"])
min_date = df_sales["date"].min()
max_date = df_sales["date"].max()
num_days = (max_date - min_date).days + 1
unique_dates = df_sales["date"].nunique()

print(f"Период продаж: с {min_date.date()} по {max_date.date()} (всего {num_days} дней, уникальных дат: {unique_dates})")
print(f"Уникальных складов: {df_sales['warehouse_name'].nunique()}")
print(f"Уникальных артикулов: {df_sales['article'].nunique()}")
print(f"Уникальных городов: {df_sales['cities_name'].nunique()}")
print(f"Уникальных категорий lvl_1: {df_sales['category_lvl_1'].nunique()}")
print(f"Уникальных категорий lvl_2: {df_sales['category_lvl_2'].nunique()}")
print(f"Уникальных категорий lvl_3: {df_sales['category_lvl_3'].nunique()}")

print("\nПроверка агрегации по департаментам:")
# Проверяем, есть ли дубли дат x склад x артикул из-за composite_division
dups = df_sales.duplicated(subset=["date", "warehouse_name", "article"]).sum()
print(f"Дубликатов (date + warehouse + article) из-за разных composite_division: {dups:,}")

print("\nСтатистика по quantity (целевая переменная):")
print(df_sales["quantity"].describe())

zero_qty = (df_sales["quantity"] == 0).sum()
neg_qty = (df_sales["quantity"] < 0).sum()
print(f"Строк с quantity == 0: {zero_qty} ({zero_qty/len(df_sales)*100:.2f}%)")
print(f"Строк с quantity < 0: {neg_qty}")

print("\n" + "="*60)
print("2. ЗАГРУЗКА И АНАЛИЗ STOCK DATASET")
print("="*60)

df_stock = pd.read_csv("stock_dataset_hakaton_train.csv")
print(f"Количество строк в stock: {len(df_stock):,}")
print(f"Колонки: {df_stock.columns.tolist()}")

df_stock["date"] = pd.to_datetime(df_stock["date"])
stock_min_date = df_stock["date"].min()
stock_max_date = df_stock["date"].max()
print(f"Период остатков: с {stock_min_date.date()} по {stock_max_date.date()}")
print(f"Уникальных складов в stock: {df_stock['warehouse_name'].nunique()}")
print(f"Уникальных артикулов в stock: {df_stock['article'].nunique()}")

print("\nСтатистика по stock:")
print(df_stock["stock"].describe())

zero_stock = (df_stock["stock"] == 0).sum()
print(f"Строк с остатком stock == 0: {zero_stock:,} ({zero_stock/len(df_stock)*100:.2f}%)")

# Проверим, все ли 11 складов и 799 артикулов совпадают
sales_warehouses = set(df_sales["warehouse_name"].unique())
stock_warehouses = set(df_stock["warehouse_name"].unique())
print(f"\nСклады совпадают полностью? {sales_warehouses == stock_warehouses}")

sales_articles = set(df_sales["article"].unique())
stock_articles = set(df_stock["article"].unique())
print(f"Артикулы совпадают полностью? {sales_articles == stock_articles}")
print(f"Всего пар склад x товар в теории: {len(sales_warehouses) * len(sales_articles)}")
