"""Корректные EDA-графики 1–4 для задачи дневного прогнозирования."""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


plt.style.use("seaborn-v0_8-whitegrid")
plt.rcParams["font.sans-serif"] = "DejaVu Sans"

print("Загрузка и агрегация данных...")
sales_raw = pd.read_csv(
    "sales_dataset_hakaton_train.csv",
    usecols=["date", "warehouse_name", "article", "quantity"],
    parse_dates=["date"],
)
sales = sales_raw.groupby(
    ["date", "warehouse_name", "article"], as_index=False, sort=False
)["quantity"].sum()
stock_raw = pd.read_csv("stock_dataset_hakaton_train.csv", parse_dates=["date"])
# В stock есть несколько строк на прогнозный ключ, поэтому агрегируем до merge.
stock = stock_raw.groupby(
    ["date", "warehouse_name", "article"], as_index=False, sort=False
)["stock"].sum()

all_dates = pd.date_range(sales["date"].min(), sales["date"].max(), freq="D")
max_date = all_dates.max()
val_start = max_date - pd.Timedelta(days=63)


# 1. Простой общий тренд продаж.
print("График 1: общий тренд продаж...")
daily = sales.groupby("date").agg(quantity=("quantity", "sum")).reindex(all_dates, fill_value=0)
daily["sales_ma7"] = daily["quantity"].rolling(7, min_periods=1).mean()
daily["sales_ma30"] = daily["quantity"].rolling(30, min_periods=1).mean()

fig, ax = plt.subplots(figsize=(14, 6), dpi=250)
ax.plot(daily.index, daily["quantity"], color="#90CDF4", alpha=0.35, label="Продажи за день")
ax.plot(daily.index, daily["sales_ma7"], color="#2B6CB0", linewidth=1.8, label="Среднее за 7 дней")
ax.plot(daily.index, daily["sales_ma30"], color="#E53E3E", linewidth=2.4, label="Среднее за 30 дней")
ax.axvspan(val_start, max_date, color="#FED7D7", alpha=0.35, label="Проверочный период: последние 64 дня")
ax.set_title("Общий объём продаж растёт со временем", fontsize=16, fontweight="bold")
ax.set_ylabel("Продано единиц по всей сети за день")
ax.set_xlabel("Дата")
ax.legend(loc="upper left")
fig.tight_layout()
fig.savefig("plot_1_trend_seasonality.png")
plt.close(fig)


# 2. Реальный пример stock-out после агрегации stock.
print("График 2: корректный пример stock-out...")
recent_start = max_date - pd.Timedelta(days=180)
recent_dates = pd.date_range(recent_start, max_date, freq="D")
recent_sales = sales[sales["date"].between(recent_start, max_date)]
recent_stock = stock[stock["date"].between(recent_start, max_date)]
pair_grid = pd.MultiIndex.from_product(
    [recent_dates, sorted(sales["warehouse_name"].unique()), sorted(sales["article"].unique())],
    names=["date", "warehouse_name", "article"],
).to_frame(index=False)
recent = pair_grid.merge(recent_sales, how="left").merge(recent_stock, how="left")
recent["quantity"] = recent["quantity"].fillna(0)
pair_stats = recent.groupby(["warehouse_name", "article"]).agg(
    total_sales=("quantity", "sum"),
    zero_stock_days=("stock", lambda x: int(x.eq(0).sum())),
    positive_stock_days=("stock", lambda x: int(x.gt(0).sum())),
)
candidates = pair_stats[
    (pair_stats["zero_stock_days"] >= 7) & (pair_stats["positive_stock_days"] >= 30)
]
if candidates.empty:
    candidates = pair_stats[pair_stats["zero_stock_days"] > 0]
sample_wh, sample_art = candidates["total_sales"].idxmax()
example = recent[
    (recent["warehouse_name"] == sample_wh) & (recent["article"] == sample_art)
].sort_values("date")

fig, ax_stock = plt.subplots(figsize=(14, 6), dpi=250)
ax_sales = ax_stock.twinx()
line = ax_stock.plot(example["date"], example["stock"], color="#2B6CB0", linewidth=2, label="Суммарный остаток")
bars = ax_sales.bar(example["date"], example["quantity"], color="#E53E3E", alpha=0.55, width=0.8, label="Продажи")
for date in example.loc[example["stock"].eq(0), "date"]:
    ax_stock.axvspan(date - pd.Timedelta(hours=12), date + pd.Timedelta(hours=12), color="#FED7D7", alpha=0.65)
ax_stock.set_title(
    f"Остатки и продажи после агрегации stock\n"
    f"Склад: {sample_wh}, товар: {sample_art}; розовым отмечены реальные дни stock=0",
    fontsize=15,
    fontweight="bold",
)
ax_stock.set_xlabel("Дата")
ax_stock.set_ylabel("Суммарный остаток", color="#2B6CB0")
ax_sales.set_ylabel("Продажи в день", color="#E53E3E")
ax_stock.set_ylim(bottom=0)
ax_sales.set_ylim(bottom=0)
ax_sales.grid(False)
ax_stock.legend(line + [bars], ["Суммарный остаток", "Продажи"], loc="upper left")
fig.tight_layout()
fig.savefig("plot_2_out_of_stock_effect.png")
plt.close(fig)


# 3. Средний дневной объём по дням недели.
print("График 3: недельная сезонность...")
network_daily = sales.groupby("date")["quantity"].sum().reindex(all_dates, fill_value=0)
dow_frame = network_daily.rename("quantity").to_frame()
dow_frame["dow"] = dow_frame.index.dayofweek
dow = dow_frame.groupby("dow")["quantity"].agg(["mean", "std", "count"])
dow["se"] = dow["std"] / np.sqrt(dow["count"])
days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
fig, ax = plt.subplots(figsize=(11, 5.5), dpi=250)
colors = ["#4A90E2"] * 5 + ["#E53E3E"] * 2
bars = ax.bar(days_ru, dow["mean"], yerr=1.96 * dow["se"], capsize=4, color=colors, width=0.62)
for bar, value in zip(bars, dow["mean"]):
    ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 35, f"{value:,.0f}", ha="center", fontweight="bold")
ax.set_title("Средние продажи за один календарный день недели\nПланки — 95% доверительный интервал среднего", fontsize=15, fontweight="bold")
ax.set_ylabel("Среднее количество проданных единиц")
ax.tick_params(axis="x", rotation=15)
fig.tight_layout()
fig.savefig("plot_3_day_of_week_seasonality.png")
plt.close(fig)


# 4. Склады на одинаковом недавнем горизонте.
print("График 4: сравнение складов...")
warehouse_grid = pd.MultiIndex.from_product(
    [recent_dates, sorted(sales["warehouse_name"].unique())],
    names=["date", "warehouse_name"],
).to_frame(index=False)
warehouse_daily = recent_sales.groupby(["date", "warehouse_name"], as_index=False)["quantity"].sum()
warehouse_daily = warehouse_grid.merge(warehouse_daily, how="left").fillna({"quantity": 0})
warehouse_stats = warehouse_daily.groupby("warehouse_name")["quantity"].mean().sort_values(ascending=False)
fig, ax = plt.subplots(figsize=(12, 5.5), dpi=250)
bars = ax.bar(warehouse_stats.index, warehouse_stats.values, color="#3182CE", width=0.65)
for bar, value in zip(bars, warehouse_stats.values):
    ax.text(bar.get_x() + bar.get_width() / 2, value + 3, f"{value:,.1f}", ha="center", fontsize=9)
ax.set_title("Средние дневные продажи по складам за последние 181 день", fontsize=15, fontweight="bold")
ax.set_ylabel("Среднее число проданных единиц в день")
ax.tick_params(axis="x", rotation=45)
fig.tight_layout()
fig.savefig("plot_4_warehouse_distribution.png")
plt.close(fig)

print("Графики 1–4 пересозданы.")
