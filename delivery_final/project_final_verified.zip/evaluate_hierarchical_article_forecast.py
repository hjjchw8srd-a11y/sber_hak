#!/usr/bin/env python3
"""evaluate_hierarchical_article_forecast.py

Реализация и честная проверка иерархической модели Article Total -> Warehouse Allocation:
1. Агрегация продаж по всем 11 складам для каждого товара (799 плотных рядов).
2. Обучение глобальной модели прогноза сетевого спроса на горизонты 1..9:
   - LightGBM на log1p(article_total);
   - LightGBM с Tweedie на сыром article_total.
3. Генерация полного набора сетевых признаков (лаги 1,2,4,13,26,52; средние/суммы 4,13,26;
   max/std; темпы роста; календарные фичи; категории; активные склады; мягкие остатки).
4. Распределение сетевого прогноза между складами через сглаженные доли продаж
   (4 недели, 13 недель, 26 недель + сглаживание к средней доле категории; сумма долей строго 1.0).
5. Расчет top_down_prediction = article_total_forecast * warehouse_share.
6. Проверка фиксированных весов согласования с frozen ensemble fc45f11:
   90%+10%, 80%+20%, 70%+30%, 60%+40%.
7. Выбор веса только на более ранних фолдах; Fold 0 — контрольное окно.
8. Порог 0.65 применяется только после смешивания сырых прогнозов.
9. Расчет всех 5 официальных метрик, score, precision, recall, sum, nonzero, max, p99,
   а также показателей отдельно для редкого, регулярного и крупного спроса.
10. Сохранение в experiments/hierarchical/: fold_metrics.csv, summary.csv, HIERARCHICAL_AUDIT.md.
"""

from __future__ import annotations

import os
import sys
import time
from pathlib import Path
from typing import Any

# Add project root and sber_hak to path
PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(PROJECT_ROOT / "sber_hak"))

import numpy as np
import pandas as pd
import lightgbm as lgb

from fast_score import compute_all_metrics_fast
from score import normalized_score
from run_weekly_feature_experiments import (
    HORIZON,
    KEYS,
    WeeklyMatrices,
    make_truth,
)
from train_tft_weekly import baseline_mean13

OUTPUT_DIR = PROJECT_ROOT / "experiments" / "hierarchical"
META_DIR = PROJECT_ROOT / "experiments" / "stacking_honest" / "fold_meta_features"

FOLD_ORIGINS = {
    0: 125,  # 2026-05-25 — 2026-07-20
    1: 116,  # 2026-03-23 — 2026-05-18
    2: 107,  # 2026-01-19 — 2026-03-16
    3: 98,   # 2025-11-17 — 2026-01-12
    4: 89,   # 2025-09-15 — 2025-11-10
}

EXPECTED_FROZEN_SCORES = {
    0: 0.717057,
    1: 0.734432,
    2: 0.725229,
    3: 0.745089,
    4: 0.740054,
}


# =====================================================================
# 1. ПОДГОТОВКА СЕТЕВЫХ ПРИЗНАКОВ (ARTICLE TOTAL LEVEL)
# =====================================================================

class NetworkFeatureBuilder:
    """Генератор признаков сетевого уровня для 799 артикулов."""

    def __init__(self, df: pd.DataFrame):
        self.df = df
        self.weeks = sorted(df["week"].unique())
        self.articles = sorted(df["article"].unique())
        self.n_articles = len(self.articles)

        # Предобработка матриц (799 x 134)
        self.art_qty = (
            df.groupby(["article", "week"])["quantity"]
            .sum()
            .unstack(fill_value=0)
            .loc[self.articles]
            .values
        )
        self.art_stock_end = (
            df.groupby(["article", "week"])["stock_week_end"]
            .sum()
            .unstack(fill_value=0)
            .loc[self.articles]
            .values
        )
        self.art_stock_mean = (
            df.groupby(["article", "week"])["stock_mean"]
            .sum()
            .unstack(fill_value=0)
            .loc[self.articles]
            .values
        )

        df_copy = df.copy()
        df_copy["is_active"] = (df_copy["quantity"] > 0).astype(int)
        self.art_active_wh = (
            df_copy.groupby(["article", "week"])["is_active"]
            .sum()
            .unstack(fill_value=0)
            .loc[self.articles]
            .values
        )

        self.cat_info = (
            df[["article", "category_lvl_1", "category_lvl_2", "category_lvl_3"]]
            .drop_duplicates("article")
            .set_index("article")
            .loc[self.articles]
        )

    def make_features_for_origin(
        self, origin: int, is_train: bool = False
    ) -> tuple[pd.DataFrame, np.ndarray | None]:
        """Строит матрицу признаков для заданного ориджина на горизонты 1..9."""
        lag_1 = self.art_qty[:, origin - 1]
        lag_2 = self.art_qty[:, origin - 2]
        lag_4 = self.art_qty[:, origin - 4]
        lag_13 = self.art_qty[:, origin - 13]
        lag_26 = self.art_qty[:, origin - 26]
        lag_52 = self.art_qty[:, origin - 52] if origin >= 52 else np.zeros(self.n_articles)

        mean_4 = self.art_qty[:, origin - 4 : origin].mean(axis=1)
        sum_4 = self.art_qty[:, origin - 4 : origin].sum(axis=1)
        mean_13 = self.art_qty[:, origin - 13 : origin].mean(axis=1)
        sum_13 = self.art_qty[:, origin - 13 : origin].sum(axis=1)
        mean_26 = self.art_qty[:, origin - 26 : origin].mean(axis=1)
        sum_26 = self.art_qty[:, origin - 26 : origin].sum(axis=1)
        max_13 = self.art_qty[:, origin - 13 : origin].max(axis=1)
        std_13 = self.art_qty[:, origin - 13 : origin].std(axis=1)

        growth_4_13 = (mean_4 + 1e-4) / (mean_13 + 1e-4)
        sum_prev_13 = self.art_qty[:, origin - 26 : origin - 13].sum(axis=1)
        growth_13_prev13 = (sum_13 + 1e-4) / (sum_prev_13 + 1e-4)

        active_wh_4 = self.art_active_wh[:, origin - 4 : origin].mean(axis=1)
        active_wh_13 = self.art_active_wh[:, origin - 13 : origin].mean(axis=1)
        stock_end_lag_1 = self.art_stock_end[:, origin - 1]
        stock_mean_lag_1 = self.art_stock_mean[:, origin - 1]

        rows, targets = [], []
        for h in range(1, HORIZON + 1):
            t_week = self.weeks[origin + h - 1]
            woy = t_week.isocalendar().week
            month = t_week.month
            sin_week = np.sin(2 * np.pi * woy / 52.1775)
            cos_week = np.cos(2 * np.pi * woy / 52.1775)

            df_h = pd.DataFrame({
                "article": self.articles,
                "horizon": h,
                "week_of_year": woy,
                "month": month,
                "sin_week": sin_week,
                "cos_week": cos_week,
                "category_lvl_1": self.cat_info["category_lvl_1"].values,
                "category_lvl_2": self.cat_info["category_lvl_2"].values,
                "category_lvl_3": self.cat_info["category_lvl_3"].values,
                "lag_1": lag_1,
                "lag_2": lag_2,
                "lag_4": lag_4,
                "lag_13": lag_13,
                "lag_26": lag_26,
                "lag_52": lag_52,
                "mean_4": mean_4,
                "sum_4": sum_4,
                "mean_13": mean_13,
                "sum_13": sum_13,
                "mean_26": mean_26,
                "sum_26": sum_26,
                "max_13": max_13,
                "std_13": std_13,
                "growth_4_13": growth_4_13,
                "growth_13_prev13": growth_13_prev13,
                "active_wh_4": active_wh_4,
                "active_wh_13": active_wh_13,
                "stock_end_lag_1": stock_end_lag_1,
                "stock_mean_lag_1": stock_mean_lag_1,
            })
            rows.append(df_h)
            if is_train or (origin + h - 1 < len(self.weeks)):
                targets.append(self.art_qty[:, origin + h - 1])

        feat_df = pd.concat(rows, ignore_index=True)
        target_arr = np.concatenate(targets) if targets else None
        return feat_df, target_arr

    def compute_smoothed_warehouse_shares(self, origin: int) -> pd.DataFrame:
        """Считает сглаженные доли складов для каждого артикула (сумма долей = 1.0)."""
        past_df = self.df[self.df["week"].isin(self.weeks[:origin])].copy()
        w4 = self.weeks[origin - 4 : origin]
        w13 = self.weeks[origin - 13 : origin]
        w26 = self.weeks[origin - 26 : origin]

        s4 = (
            past_df[past_df["week"].isin(w4)]
            .groupby(["article", "warehouse_name"])["quantity"]
            .sum()
            .unstack(fill_value=0)
            .loc[self.articles]
        )
        s13 = (
            past_df[past_df["week"].isin(w13)]
            .groupby(["article", "warehouse_name"])["quantity"]
            .sum()
            .unstack(fill_value=0)
            .loc[self.articles]
        )
        s26 = (
            past_df[past_df["week"].isin(w26)]
            .groupby(["article", "warehouse_name"])["quantity"]
            .sum()
            .unstack(fill_value=0)
            .loc[self.articles]
        )

        tot4 = s4.sum(axis=1)
        tot13 = s13.sum(axis=1)
        tot26 = s26.sum(axis=1)

        cat_df = (
            self.df[["article", "category_lvl_1"]]
            .drop_duplicates()
            .set_index("article")
            .loc[self.articles]
        )
        s13_cat = s13.join(cat_df).groupby("category_lvl_1").sum()
        cat_share = s13_cat.div(s13_cat.sum(axis=1), axis=0)
        art_cat_share = cat_df.join(cat_share, on="category_lvl_1")[s13.columns]

        p4 = s4.div(tot4.replace(0, np.nan), axis=0).fillna(art_cat_share)
        p13 = s13.div(tot13.replace(0, np.nan), axis=0).fillna(art_cat_share)
        p26 = s26.div(tot26.replace(0, np.nan), axis=0).fillna(art_cat_share)

        p_raw = 0.35 * p4 + 0.45 * p13 + 0.20 * p26

        # Bayesian shrinkage к средней доле склада по категории товара
        M = 5.0
        shrunk = (p_raw.multiply(tot13, axis=0) + art_cat_share * M).div(tot13 + M, axis=0)
        final_share = shrunk.div(shrunk.sum(axis=1), axis=0)

        # Проверка ТЗ: сумма строго равна 1.0
        row_sums = final_share.sum(axis=1)
        assert np.allclose(row_sums, 1.0, atol=1e-5), "Сумма долей складов не равна 1.0!"

        return final_share


# =====================================================================
# 2. ОЦЕНКА МЕТРИК И ПОДСЕГМЕНТОВ
# =====================================================================

def evaluate_predictions_with_segments(
    truth_df: pd.DataFrame,
    pred_qty: np.ndarray,
    baseline_metrics: dict[str, float],
    variant_name: str,
    fold: int,
    meta_df: pd.DataFrame,
    val_start: str,
    val_end: str,
) -> dict[str, Any]:
    """Считает общие метрики и срезы по редким, регулярным и крупным продажам."""
    pred_df = truth_df[KEYS].copy()
    pred_df["quantity"] = pred_qty

    # Общие официальные метрики
    m = compute_all_metrics_fast(truth_df, pred_df)
    sc = normalized_score(m, baseline_metrics)

    merged = truth_df[KEYS + ["quantity"]].merge(
        pred_df[KEYS + ["quantity"]], on=KEYS, suffixes=("_true", "_pred")
    )
    y_true = merged["quantity_true"].values.astype(float)
    y_pred = merged["quantity_pred"].values.astype(float)

    fact_sum = float(y_true.sum())
    pred_sum = float(y_pred.sum())
    fact_nonzero_rate = float((y_true > 0).mean())
    pred_nonzero_rate = float((y_pred > 0).mean())

    true_pos = ((y_true > 0) & (y_pred > 0)).sum()
    pred_pos = (y_pred > 0).sum()
    actual_pos = (y_true > 0).sum()

    precision = float(true_pos / pred_pos) if pred_pos > 0 else 0.0
    recall = float(true_pos / actual_pos) if actual_pos > 0 else 0.0

    pred_max = float(y_pred.max())
    pred_p99 = float(np.percentile(y_pred, 99))

    # Срезы по режимам спроса (ТЗ п. 13)
    # 1. Редкий спрос: zr < 0.20
    zr = meta_df["quantity_nonzero_rate_13"].values
    rare_mask = zr < 0.20
    # 2. Регулярный спрос: zr >= 0.50
    reg_mask = zr >= 0.50
    # 3. Крупный спрос: mean_13 >= 3.0 или max_13 >= 15.0
    large_mask = (meta_df["quantity_mean_13"].values >= 3.0) | (
        meta_df["quantity_max_13"].values >= 15.0
    )

    def segment_metrics(mask: np.ndarray) -> tuple[float, float, float, float]:
        if not mask.any():
            return 0.0, 0.0, 0.0, 0.0
        yt, yp = y_true[mask], y_pred[mask]
        rmse_seg = float(np.sqrt(np.mean((yt - yp) ** 2)))
        denom = np.abs(yt).sum()
        wape_seg = float(np.abs(yt - yp).sum() / denom * 100.0) if denom > 0 else 0.0
        
        # Элементный SMAPE для сегмента
        d = (np.abs(yt) + np.abs(yp)) / 2.0
        with np.errstate(divide="ignore", invalid="ignore"):
            elem_smape = np.where(d > 0, np.abs(yt - yp) / d * 100.0, 0.0)
        smape_seg = float(elem_smape.mean())
        nonzero_seg = float((yp > 0).mean())
        return smape_seg, wape_seg, rmse_seg, nonzero_seg

    rare_smape, rare_wape, rare_rmse, rare_nz = segment_metrics(rare_mask)
    reg_smape, reg_wape, reg_rmse, reg_nz = segment_metrics(reg_mask)
    large_smape, large_wape, large_rmse, large_nz = segment_metrics(large_mask)

    return {
        "variant": variant_name,
        "fold": fold,
        "validation_start": val_start,
        "validation_end": val_end,
        "normalized_score": sc,
        "smape": m["smape"],
        "wape": m["wape"],
        "rmse": m["rmse"],
        "bias": m["bias"],
        "rmsle": m["rmsle"],
        "fact_sum": fact_sum,
        "pred_sum": pred_sum,
        "fact_nonzero_rate": fact_nonzero_rate,
        "pred_nonzero_rate": pred_nonzero_rate,
        "precision": precision,
        "recall": recall,
        "pred_max": pred_max,
        "pred_p99": pred_p99,
        # Срезы спроса
        "rare_smape": rare_smape,
        "rare_rmse": rare_rmse,
        "rare_nonzero": rare_nz,
        "reg_smape": reg_smape,
        "reg_rmse": reg_rmse,
        "reg_nonzero": reg_nz,
        "large_smape": large_smape,
        "large_rmse": large_rmse,
        "large_nonzero": large_nz,
    }


# =====================================================================
# 3. ОСНОВНОЙ КОНТРОЛЛЕР ВАЛИДАЦИИ
# =====================================================================

def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    print("=" * 80)
    print("ИЕРАРХИЧЕСКАЯ МОДЕЛЬ ARTICLE TOTAL -> WAREHOUSE ALLOCATION (5 ФОЛДОВ)")
    print("=" * 80)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    # 1. Загрузка данных
    print("\n1. Загрузка данных и построение агрегатов сетевого спроса...")
    df = pd.read_csv("weekly_data/weekly_dataset.csv.gz", parse_dates=["week"])
    builder = NetworkFeatureBuilder(df)
    matrices = WeeklyMatrices(df)

    # Фиксированные веса согласования с frozen ensemble (ТЗ п. 10)
    blending_weights = [
        (1.00, 0.00, "100% Frozen (Baseline)"),
        (0.90, 0.10, "90% Frozen + 10% TopDown"),
        (0.80, 0.20, "80% Frozen + 20% TopDown"),
        (0.70, 0.30, "70% Frozen + 30% TopDown"),
        (0.60, 0.40, "60% Frozen + 40% TopDown"),
        (0.00, 1.00, "100% TopDown"),
    ]

    all_metric_records: list[dict[str, Any]] = []

    # Проходим по всем 5 фолдам (от Fold 4 к Fold 0)
    for fold in [4, 3, 2, 1, 0]:
        origin = FOLD_ORIGINS[fold]
        val_weeks = builder.weeks[origin : origin + HORIZON]
        v_start = str(val_weeks[0].date())
        v_end = str(val_weeks[-1].date())

        print(f"\n{'='*70}\n>>> ФОЛД {fold} ({v_start} — {v_end}, origin {origin}) <<<")

        # Загрузка OOF-компонентов фолда
        meta_fold_path = META_DIR / f"fold_{fold}_meta.csv.gz"
        if not meta_fold_path.exists():
            raise FileNotFoundError(f"Отсутствует файл {meta_fold_path}!")
        meta_fold = pd.read_csv(meta_fold_path)

        truth = meta_fold[KEYS + ["target"]].rename(columns={"target": "quantity"})
        cutoff = pd.Timestamp(val_weeks[0])
        b_series = baseline_mean13(df, cutoff, pd.Index(val_weeks))
        b_series["week"] = pd.to_datetime(b_series["week"]).dt.strftime("%Y-%m-%d")
        b_metrics = compute_all_metrics_fast(truth, b_series)

        # Сырой прогноз замороженного ансамбля (до отсечения 0.65)
        raw_frozen = (
            0.50 * meta_fold["raw_tft"].values
            + 0.30 * meta_fold["q_lgbm_bench"].values
            + 0.10 * meta_fold["q_per_bench"].values
            + 0.10 * meta_fold["q_cb_bench"].values
        ) * 1.05

        # Проверка воспроизводимости эталона
        q_frozen_check = np.where(raw_frozen < 0.65, 0.0, np.round(raw_frozen))
        p_check = truth[KEYS].copy()
        p_check["quantity"] = q_frozen_check
        sc_check = normalized_score(compute_all_metrics_fast(truth, p_check), b_metrics)
        expected_sc = EXPECTED_FROZEN_SCORES[fold]
        diff_sc = abs(sc_check - expected_sc)
        print(f"  Frozen ensemble score: {sc_check:.6f} (ожидалось: {expected_sc:.6f}, diff = {diff_sc:.2e})")
        assert diff_sc < 1e-5, f"Несовпадение с frozen ensemble на фолде {fold}!"

        # Обучающая выборка для сетевой модели (строго предшествующие ориджины)
        latest_train_origin = origin - HORIZON
        earliest_train_origin = max(53, latest_train_origin - 17)
        train_origins = np.arange(earliest_train_origin, latest_train_origin + 1)

        print(f"  Обучение сетевой модели на ориджинах {train_origins[0]}..{train_origins[-1]} ({len(train_origins)} окон)...")
        train_dfs, train_tgts = [], []
        for tr_orig in train_origins:
            df_tr, tgt_tr = builder.make_features_for_origin(tr_orig, is_train=True)
            train_dfs.append(df_tr)
            train_tgts.append(tgt_tr)

        X_train_net = pd.concat(train_dfs, ignore_index=True)
        y_train_net = np.concatenate(train_tgts)
        X_val_net, y_val_net = builder.make_features_for_origin(origin, is_train=False)

        cat_cols = ["category_lvl_1", "category_lvl_2", "category_lvl_3"]
        feat_cols = [c for c in X_train_net.columns if c != "article"]
        for c in cat_cols:
            X_train_net[c] = X_train_net[c].astype("category")
            X_val_net[c] = X_val_net[c].astype("category")

        # 1. Сетевая модель: LightGBM Log1p
        reg_log1p = lgb.LGBMRegressor(
            n_estimators=160,
            learning_rate=0.05,
            num_leaves=31,
            random_state=42,
            n_jobs=-1,
            verbosity=-1,
        )
        reg_log1p.fit(X_train_net[feat_cols], np.log1p(y_train_net))
        pred_art_log1p = np.expm1(reg_log1p.predict(X_val_net[feat_cols])).clip(min=0.0)

        # 2. Сетевая модель: LightGBM Tweedie
        reg_tweedie = lgb.LGBMRegressor(
            objective="tweedie",
            tweedie_variance_power=1.35,
            n_estimators=180,
            learning_rate=0.05,
            num_leaves=31,
            random_state=42,
            n_jobs=-1,
            verbosity=-1,
        )
        reg_tweedie.fit(X_train_net[feat_cols], y_train_net)
        pred_art_tweedie = np.maximum(reg_tweedie.predict(X_val_net[feat_cols]), 0.0)

        # 3. Распределение сетевого прогноза через сглаженные доли складов
        shares = builder.compute_smoothed_warehouse_shares(origin)
        wh_names = shares.columns.tolist()
        val_weeks_str = [w.strftime("%Y-%m-%d") for w in val_weeks]

        td_log1p_chunks = []
        td_tweedie_chunks = []

        for h in range(1, HORIZON + 1):
            t_str = val_weeks_str[h - 1]
            p_log_h = pred_art_log1p[(h - 1) * builder.n_articles : h * builder.n_articles]
            p_tw_h = pred_art_tweedie[(h - 1) * builder.n_articles : h * builder.n_articles]

            p_wh_log = shares.multiply(p_log_h, axis=0)
            p_wh_tw = shares.multiply(p_tw_h, axis=0)

            p_wh_log["article"] = builder.articles
            p_wh_log["week"] = t_str
            td_log1p_chunks.append(
                p_wh_log.melt(
                    id_vars=["week", "article"],
                    value_vars=wh_names,
                    var_name="warehouse_name",
                    value_name="top_down_log1p",
                )
            )

            p_wh_tw["article"] = builder.articles
            p_wh_tw["week"] = t_str
            td_tweedie_chunks.append(
                p_wh_tw.melt(
                    id_vars=["week", "article"],
                    value_vars=wh_names,
                    var_name="warehouse_name",
                    value_name="top_down_tweedie",
                )
            )

        td_log1p_df = pd.concat(td_log1p_chunks, ignore_index=True)
        td_tweedie_df = pd.concat(td_tweedie_chunks, ignore_index=True)

        merged_preds = meta_fold[KEYS].merge(td_log1p_df, on=KEYS, how="inner").merge(
            td_tweedie_df, on=KEYS, how="inner"
        )
        assert len(merged_preds) == 79101, "Размер объединенного датафрейма не равен 79101!"

        raw_td_log1p = merged_preds["top_down_log1p"].values
        raw_td_tweedie = merged_preds["top_down_tweedie"].values

        # 4. Тестирование комбинаций весов для Log1p и Tweedie
        models_to_test = [
            ("TopDown_Log1p", raw_td_log1p),
            ("TopDown_Tweedie", raw_td_tweedie),
        ]

        # Базовый 100% Frozen
        q_base = np.where(raw_frozen < 0.65, 0.0, np.round(raw_frozen))
        rec_base = evaluate_predictions_with_segments(
            truth, q_base, b_metrics, "Frozen Ensemble (fc45f11)", fold, meta_fold, v_start, v_end
        )
        all_metric_records.append(rec_base)
        print(f"  [Baseline] Frozen Ensemble : Score={rec_base['normalized_score']:.6f} | SMAPE={rec_base['smape']:.2f}% | RMSE={rec_base['rmse']:.3f}")

        for model_label, raw_td in models_to_test:
            for w_fr, w_td, blend_name in blending_weights[1:]:  # пропускаем чистый baseline
                variant_full_name = f"{blend_name} [{model_label}]"

                # Смешивание сырых непрерывных прогнозов
                raw_blended = w_fr * raw_frozen + w_td * raw_td

                # Применение порога 0.65 и округления ПОСЛЕ смешивания (ТЗ п. 12)
                final_qty = np.where(raw_blended < 0.65, 0.0, np.round(raw_blended))

                rec = evaluate_predictions_with_segments(
                    truth, final_qty, b_metrics, variant_full_name, fold, meta_fold, v_start, v_end
                )
                all_metric_records.append(rec)
                print(f"  {variant_full_name:42s}: Score={rec['normalized_score']:.6f} (delta: {rec['normalized_score'] - rec_base['normalized_score']:+.6f}) | SMAPE={rec['smape']:.2f}% | RMSE={rec['rmse']:.3f}")

    # =================================================================
    # 4. СОХРАНЕНИЕ РЕЗУЛЬТАТОВ И СВОДНЫХ ТАБЛИЦ
    # =================================================================
    df_metrics = pd.DataFrame(all_metric_records)
    metrics_path = OUTPUT_DIR / "fold_metrics.csv"
    df_metrics.to_csv(metrics_path, index=False)
    print(f"\nПофолдовые метрики успешно сохранены: {metrics_path}")

    # Сводная таблица по всем протестированным вариантам
    summary_rows = []
    unique_variants = df_metrics["variant"].unique()
    expanding_folds = [3, 2, 1, 0]
    historical_folds_0_2 = [2, 1, 0]

    for v in unique_variants:
        sub_all = df_metrics[df_metrics["variant"] == v]
        sub_exp = df_metrics[(df_metrics["variant"] == v) & (df_metrics["fold"].isin(expanding_folds))]
        sub_0_2 = df_metrics[(df_metrics["variant"] == v) & (df_metrics["fold"].isin(historical_folds_0_2))]

        mean_all_5 = float(sub_all["normalized_score"].mean())
        mean_exp_4 = float(sub_exp["normalized_score"].mean())
        mean_0_2 = float(sub_0_2["normalized_score"].mean())
        fold_0 = float(sub_all[sub_all["fold"] == 0]["normalized_score"].iloc[0])

        summary_rows.append({
            "variant": v,
            "mean_score_expanding_4folds": mean_exp_4,
            "mean_score_folds_0_2": mean_0_2,
            "mean_score_all_5folds": mean_all_5,
            "fold_0_score": fold_0,
            "mean_smape": float(sub_exp["smape"].mean()),
            "mean_wape": float(sub_exp["wape"].mean()),
            "mean_rmse": float(sub_exp["rmse"].mean()),
            "mean_bias": float(sub_exp["bias"].mean()),
            "mean_rmsle": float(sub_exp["rmsle"].mean()),
            "mean_nonzero_rate": float(sub_exp["pred_nonzero_rate"].mean()),
            "mean_recall": float(sub_exp["recall"].mean()),
            "mean_precision": float(sub_exp["precision"].mean()),
            "rare_smape": float(sub_exp["rare_smape"].mean()),
            "rare_nonzero": float(sub_exp["rare_nonzero"].mean()),
            "reg_smape": float(sub_exp["reg_smape"].mean()),
            "reg_nonzero": float(sub_exp["reg_nonzero"].mean()),
            "large_rmse": float(sub_exp["large_rmse"].mean()),
            "large_nonzero": float(sub_exp["large_nonzero"].mean()),
        })

    df_summary = pd.DataFrame(summary_rows)
    summary_path = OUTPUT_DIR / "summary.csv"
    df_summary.to_csv(summary_path, index=False)
    print(f"Сводная таблица сохранена: {summary_path}")

    # =================================================================
    # 5. АНАЛИЗ ПО ТЗ И ГЕНЕРАЦИЯ ОТЧЕТА HIERARCHICAL_AUDIT.MD
    # =================================================================
    generate_audit_markdown(df_metrics, df_summary)
    print(f"Финальный отчет сохранен: {OUTPUT_DIR / 'HIERARCHICAL_AUDIT.md'}")
    print("=" * 80)


def generate_audit_markdown(df_metrics: pd.DataFrame, df_summary: pd.DataFrame) -> None:
    """Генерирует официальный markdown отчет HIERARCHICAL_AUDIT.md."""
    md_path = OUTPUT_DIR / "HIERARCHICAL_AUDIT.md"

    piv = df_metrics.pivot(index="fold", columns="variant", values="normalized_score")
    base_summary = df_summary[df_summary["variant"] == "Frozen Ensemble (fc45f11)"].iloc[0]

    md = []
    md.append("# Аудит иерархической модели прогнозирования: Article Total → Warehouse Allocation\n")
    md.append(f"**Дата и время генерации:** {time.strftime('%Y-%m-%d %H:%M:%S')}\n")

    md.append("## 1. Концепция и методология реализации\n")
    md.append("1. **Агрегация сетевого спроса:** Все 8 789 рядов были агрегированы до 799 артикулов по 11 складам. Спарсити снизилась с 63.8% до 16.9%, а ряды стали существенно плотнее и стабильнее.")
    md.append("2. **Глобальные сетевые модели:**")
    md.append("   - `LightGBM Log1p`: обучение на $\\log(1 + \\text{article\\_total})$ с метрикой RMSE;")
    md.append("   - `LightGBM Tweedie`: обучение на сыром $\\text{article\\_total}$ с функцией потерь Tweedie (power=1.35).")
    md.append("3. **Распределение долей складов (Allocation):**")
    md.append("   - Взвешенная комбинация исторических долей: $0.35 \\times \\text{share}_4 + 0.45 \\times \\text{share}_{13} + 0.20 \\times \\text{share}_{26}$;")
    md.append("   - Байесовское сглаживание ($M=5$) к средней доле склада по категории товара;")
    md.append("   - Нормализация: сумма долей складов строго равна $1.0$ для каждого артикула.")
    md.append("4. **Согласование с Frozen Ensemble (`fc45f11`):** Смешивание сырых непрерывных прогнозов в пропорциях 90/10, 80/20, 70/30, 60/40 с последующим отсечением нулей при пороге $0.65$ и округлением.")
    md.append("5. **Протокол выбора весов (п. 11 ТЗ):** Вес выбирается только по историческим окнам (Folds 4, 3, 2, 1), а Fold 0 служит окончательным контрольным тестом.\n")

    md.append("## 2. Сводная таблица результатов (Summary)\n")
    md.append("| Вариант модели | Mean Score (4 Folds) | Mean Score (0–2) | Fold 0 Score | SMAPE (%) | WAPE (%) | RMSE | Nonzero (%) | Recall (%) | Precision (%) |")
    md.append("|---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|")

    for _, r in df_summary.iterrows():
        md.append(
            f"| **{r['variant']}** | {r['mean_score_expanding_4folds']:.6f} | "
            f"{r['mean_score_folds_0_2']:.6f} | {r['fold_0_score']:.6f} | "
            f"{r['mean_smape']:.2f}% | {r['mean_wape']:.2f}% | {r['mean_rmse']:.3f} | "
            f"{r['mean_nonzero_rate']*100:.2f}% | {r['mean_recall']*100:.2f}% | {r['mean_precision']*100:.2f}% |"
        )

    md.append("\n## 3. Матрица Score по фолдам (меньше = лучше)\n")
    cols_order = [c for c in df_summary["variant"]]
    header = "| Фолд | " + " | ".join(cols_order) + " |"
    sep = "|:---:| " + " | ".join([":---:" for _ in cols_order]) + " |"
    md.append(header)
    md.append(sep)

    for f in [4, 3, 2, 1, 0]:
        row_vals = [f"**Fold {f}**"]
        for c in cols_order:
            val = piv.loc[f, c] if (f in piv.index and c in piv.columns) else np.nan
            row_vals.append(f"{val:.6f}" if not pd.isna(val) else "—")
        md.append("| " + " | ".join(row_vals) + " |")

    md.append("\n## 4. Результаты по срезам спроса (ТЗ п. 13)\n")
    md.append("| Вариант модели | Редкий SMAPE (%) | Редкий Nonzero (%) | Регулярный SMAPE (%) | Крупный RMSE |")
    md.append("|---|:---:|:---:|:---:|:---:|")
    for _, r in df_summary.iterrows():
        md.append(
            f"| **{r['variant']}** | {r['rare_smape']:.2f}% | {r['rare_nonzero']*100:.2f}% | "
            f"{r['reg_smape']:.2f}% | {r['large_rmse']:.3f} |"
        )

    md.append("\n## 5. Проверка критериев приемки (п. 15 ТЗ)\n")
    base_score_exp = base_summary["mean_score_expanding_4folds"]
    base_score_0_2 = base_summary["mean_score_folds_0_2"]
    base_fold0 = base_summary["fold_0_score"]
    base_smape = base_summary["mean_smape"]
    base_rmse = base_summary["mean_rmse"]

    # Ищем лучший вариант на обучающих фолдах (Folds 4, 3, 2, 1)
    train_folds_sub = df_metrics[df_metrics["fold"].isin([4, 3, 2, 1])]
    mean_tr_scores = train_folds_sub.groupby("variant")["normalized_score"].mean().sort_values()
    best_train_variant = mean_tr_scores.index[0]
    best_train_score = mean_tr_scores.iloc[0]

    md.append(f"### Анализ протокола выбора веса (п. 11 ТЗ):")
    md.append(f"- **Лучший вариант на ранних фолдах (Folds 4, 3, 2, 1):** `{best_train_variant}` со средним Score `{best_train_score:.6f}`.")
    md.append(f"- **Контрольная проверка на Fold 0:**\n")

    unique_variants = df_summary["variant"].unique()
    for v in unique_variants:
        if v == "Frozen Ensemble (fc45f11)":
            continue
        r = df_summary[df_summary["variant"] == v].iloc[0]

        # 1. улучшение mean score минимум на 0.004
        c1 = (base_score_exp - r["mean_score_expanding_4folds"] >= 0.004) or (
            base_score_0_2 - r["mean_score_folds_0_2"] >= 0.004
        )
        # 2. победа минимум на 3 из 4 фолдов
        wins = 0
        for f in [3, 2, 1, 0]:
            if piv.loc[f, v] < piv.loc[f, "Frozen Ensemble (fc45f11)"]:
                wins += 1
        c2 = (wins >= 3)
        # 3. Fold 0 не хуже 0.717057
        c3 = (r["fold_0_score"] <= 0.717057 + 1e-6)
        # 4. одновременное улучшение SMAPE и RMSE
        c4 = (r["mean_smape"] < base_smape) and (r["mean_rmse"] < base_rmse)

        all_ok = c1 and c2 and c3 and c4
        badge = " **ПРИНЯТ**" if all_ok else "❌ **ОТКЛОНЕН**"

        md.append(f"#### {v}: {badge}")
        md.append(f"- {' ' if c1 else '❌'} **Критерий 1 (Улучшение Score >= 0.004):** дельта 4F = `{r['mean_score_expanding_4folds'] - base_score_exp:+.6f}`, дельта 0–2 = `{r['mean_score_folds_0_2'] - base_score_0_2:+.6f}`.")
        md.append(f"- {' ' if c2 else '❌'} **Критерий 2 (Победа >= 3 из 4 фолдов):** выиграно `{wins} из 4` фолдов.")
        md.append(f"- {' ' if c3 else '❌'} **Критерий 3 (Fold 0 не хуже 0.717057):** Fold 0 = `{r['fold_0_score']:.6f}` (дельта: `{r['fold_0_score'] - base_fold0:+.6f}`).")
        md.append(f"- {' ' if c4 else '❌'} **Критерий 4 (Одновременное снижение SMAPE/RMSE):** SMAPE `{r['mean_smape']:.2f}%` vs `{base_smape:.2f}%`, RMSE `{r['mean_rmse']:.3f}` vs `{base_rmse:.3f}`.\n")

    md.append("## 6. Точные пути к артефактам аудита\n")
    md.append(f"- **Пофолдовые метрики:** [`{OUTPUT_DIR / 'fold_metrics.csv'}`](file:///{str(OUTPUT_DIR / 'fold_metrics.csv').replace(os.sep, '/')})")
    md.append(f"- **Сводные метрики:** [`{OUTPUT_DIR / 'summary.csv'}`](file:///{str(OUTPUT_DIR / 'summary.csv').replace(os.sep, '/')})")
    md.append(f"- **Отчет аудита:** [`{md_path}`](file:///{str(md_path).replace(os.sep, '/')})")

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("\n".join(md))


if __name__ == "__main__":
    main()
