#!/usr/bin/env python3
"""
run_strict_history_audit.py

Comprehensive, fully verified audit addressing all 7 diagnostic feedback points:
1. Exact mathematical reproduction of legacy_oof_frozen (< 1e-6) on all 5 folds.
2. Explicit provenance documentation for all components (Per-Category, LightGBM, CatBoost, TFT).
3. Explicit Fold 0 scaling metrics (raw alpha=1.00 vs scaled alpha=1.05).
4. Correct origin counts: Fold 4 (origin 89) has all 52 origins (29..80); summer 2025 (origin 80) has 46 origins.
5. Multi-seed check across seeds 42, 52, 62 documented as algorithmic stochasticity, not temporal independence.
6. Full artifacts generated and saved: keyed_oof (A, B, legacy, inf_matched), seed_metrics.csv,
   horizon_metrics.csv, segment_metrics.csv (clean 3-tier definition), article_level_metrics.csv, sha256 checksums.
7. Top-down 10% reconciliation test with Blend B on all 5 folds.
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import lightgbm as lgb

# Paths
PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(PROJECT_ROOT / "sber_hak"))

from fast_score import compute_all_metrics_fast, METRIC_WEIGHTS
from score import normalized_score
from run_weekly_feature_experiments import (
    HORIZON,
    KEYS,
    CAT_COLUMNS,
    WeeklyMatrices,
    columns_for_experiment,
    make_truth,
)
from train_tft_weekly import baseline_mean13
from sber_hak.history_audit_pipeline import (
    compute_metrics_with_diagnostics,
    predict_from_components,
    train_lgbm_history_variant,
)

OUTPUT_DIR = PROJECT_ROOT / "experiments" / "history_window_audit"
KEYED_OOF_DIR = OUTPUT_DIR / "keyed_oof"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
KEYED_OOF_DIR.mkdir(parents=True, exist_ok=True)

FOLD_ORIGINS = {
    0: 125,  # 2026-05-25 — 2026-07-20
    1: 116,  # 2026-03-23 — 2026-05-18
    2: 107,  # 2026-01-19 — 2026-03-16
    3: 98,   # 2025-11-17 — 2026-01-12
    4: 89,   # 2025-09-15 — 2025-11-10
}

LEGACY_FROZEN_SCORES = {
    0: 0.717057,
    1: 0.734432,
    2: 0.725229,
    3: 0.745089,
    4: 0.740054,
}


def compute_sha256(filepath: Path) -> str:
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    print("=" * 80)
    print("RUNNING STRICT HISTORY AUDIT & PIPELINE STANDARDIZATION")
    print("=" * 80)

    # 1. Load Data
    data_path = PROJECT_ROOT / "weekly_data" / "weekly_dataset.csv.gz"
    print(f"Loading dataset from {data_path}...")
    data = pd.read_csv(data_path, parse_dates=["week"])
    matrices = WeeklyMatrices(data)
    weeks = sorted(data["week"].unique())

    print("\nPrecomputing mean13 baselines and ground truth for all 5 folds...")
    fold_truth = {}
    fold_baseline = {}
    for fold, origin in FOLD_ORIGINS.items():
        val_weeks = weeks[origin : origin + HORIZON]
        truth = make_truth(matrices, origin)
        truth["week"] = pd.to_datetime(truth["week"]).dt.strftime("%Y-%m-%d")
        b_df = baseline_mean13(data, pd.Timestamp(val_weeks[0]), pd.Index(val_weeks))
        b_df["week"] = pd.to_datetime(b_df["week"]).dt.strftime("%Y-%m-%d")
        fold_truth[fold] = truth
        fold_baseline[fold] = b_df

    # -------------------------------------------------------------------------
    # PART 1: Strict Baseline Standardization & Exact Legacy Assertion
    # -------------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("PART 1: BASELINE STANDARDIZATION & EXACT LEGACY ASSERTION (< 1e-6)")
    print("=" * 80)

    legacy_config = {
        "name": "legacy_oof_frozen",
        "components": {
            "tft": {"weight": 0.50, "type": "raw"},
            "lgbm": {"weight": 0.30, "type": "raw"},
            "catboost": {"weight": 0.10, "type": "raw"},
            "per_category": {"weight": 0.10, "type": "raw"},
        },
        "blend": {"alpha": 1.05, "threshold": 0.65, "rounding": "rint", "clip_lower": 0.0},
    }

    inf_matched_config = {
        "name": "inference_matched_baseline",
        "components": {
            "tft": {"weight": 0.50, "type": "raw"},
            "lgbm": {"weight": 0.30, "type": "two_stage", "prob_gate": 0.5, "comp_postprocess": None},
            "catboost": {"weight": 0.10, "type": "two_stage", "prob_gate": 0.5, "comp_postprocess": None},
            "per_category": {"weight": 0.10, "type": "two_stage", "prob_gate": None, "comp_postprocess": None},
        },
        "blend": {"alpha": 1.05, "threshold": 0.65, "rounding": "rint", "clip_lower": 0.0},
    }

    blend_records = []
    component_records = []
    base_components_by_fold = {}

    for fold in range(5):
        meta_path = PROJECT_ROOT / "experiments" / "stacking_honest" / "fold_meta_features" / f"fold_{fold}_meta.csv.gz"
        meta = pd.read_csv(meta_path)
        meta["week"] = pd.to_datetime(meta["week"]).dt.strftime("%Y-%m-%d")

        # Provenance documentation:
        # q_lgbm_bench, q_cb_bench, q_per_bench are benchmark-postprocessed outputs
        # raw_tft is continuous TFT prediction
        comp_dict_legacy = {
            "tft": pd.DataFrame({"week": meta["week"], "warehouse_name": meta["warehouse_name"], "article": meta["article"], "quantity": meta["raw_tft"]}),
            "lgbm": pd.DataFrame({"week": meta["week"], "warehouse_name": meta["warehouse_name"], "article": meta["article"], "quantity": meta["q_lgbm_bench"]}),
            "catboost": pd.DataFrame({"week": meta["week"], "warehouse_name": meta["warehouse_name"], "article": meta["article"], "quantity": meta["q_cb_bench"]}),
            "per_category": pd.DataFrame({"week": meta["week"], "warehouse_name": meta["warehouse_name"], "article": meta["article"], "quantity": meta["q_per_bench"]}),
        }

        # Inference-matched dictionary: continuous expectations with p_sale gating
        comp_dict_inf = {
            "tft": pd.DataFrame({"week": meta["week"], "warehouse_name": meta["warehouse_name"], "article": meta["article"], "quantity": meta["raw_tft"]}),
            "lgbm": pd.DataFrame({
                "week": meta["week"], "warehouse_name": meta["warehouse_name"], "article": meta["article"],
                "p_sale": meta["p_sale_lgb"], "q_cond": meta["q_cond_lgb"], "expected": meta["exp_lgb"],
            }),
            "catboost": pd.DataFrame({
                "week": meta["week"], "warehouse_name": meta["warehouse_name"], "article": meta["article"],
                "p_sale": meta["p_sale_cb"], "q_cond": meta["q_cond_cb"], "expected": meta["exp_cb"],
            }),
            "per_category": pd.DataFrame({
                "week": meta["week"], "warehouse_name": meta["warehouse_name"], "article": meta["article"],
                "p_sale": np.ones(len(meta)), "q_cond": meta["raw_per_cat"], "expected": meta["raw_per_cat"],
            }),
        }
        base_components_by_fold[fold] = comp_dict_inf

        # 1. Exact Legacy Frozen
        keyed_leg, sub_leg = predict_from_components(comp_dict_legacy, legacy_config)
        m_leg = compute_metrics_with_diagnostics(fold_truth[fold], sub_leg, fold_baseline[fold])
        diff = abs(m_leg["clipped_score"] - LEGACY_FROZEN_SCORES[fold])
        print(f"Fold {fold}: Legacy Score = {m_leg['clipped_score']:.6f} (target = {LEGACY_FROZEN_SCORES[fold]:.6f}, diff = {diff:.8f})")
        assert diff < 1e-6, f"Legacy score mismatch on fold {fold}: {diff}"

        blend_records.append({
            "variant": "legacy_oof_frozen",
            "fold": fold,
            "origin": FOLD_ORIGINS[fold],
            **m_leg,
        })
        keyed_leg["origin"] = FOLD_ORIGINS[fold]
        keyed_leg.to_csv(KEYED_OOF_DIR / f"legacy_oof_fold_{fold}.csv.gz", index=False, compression="gzip")

        # 2. Inference Matched Baseline
        keyed_inf, sub_inf = predict_from_components(comp_dict_inf, inf_matched_config)
        m_inf = compute_metrics_with_diagnostics(fold_truth[fold], sub_inf, fold_baseline[fold])
        diff_lines = int((sub_leg["quantity"] != sub_inf["quantity"]).sum())
        print(f"Fold {fold}: Inf-Matched Score = {m_inf['clipped_score']:.6f} (unclipped = {m_inf['unclipped_ratio']:.6f}) | Changed lines vs Legacy = {diff_lines}")

        blend_records.append({
            "variant": "inference_matched_baseline",
            "fold": fold,
            "origin": FOLD_ORIGINS[fold],
            **m_inf,
        })
        keyed_inf["origin"] = FOLD_ORIGINS[fold]
        keyed_inf.to_csv(KEYED_OOF_DIR / f"inference_matched_fold_{fold}.csv.gz", index=False, compression="gzip")

    # -------------------------------------------------------------------------
    # PART 2: Bottom-Level LightGBM History Window Ablation (A vs B vs C)
    # -------------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("PART 2: HISTORY WINDOW ABLATION (A=18w vs B=52w vs C=52w decay)")
    print("=" * 80)

    lgbm_preds = {}  # (variant, fold) -> df_pred

    for variant in ["A", "B", "C"]:
        print(f"\n--- Training Bottom LightGBM Variant {variant} (seed 42) ---")
        for fold, origin in FOLD_ORIGINS.items():
            df_pred, diag = train_lgbm_history_variant(matrices, origin, variant=variant, seed=42)
            lgbm_preds[(variant, fold)] = df_pred

            # Standalone evaluation: prob_gate=0.5, threshold=0.65, round
            y_raw = np.where(df_pred["p_sale"] < 0.5, 0.0, df_pred["expected_quantity"])
            y_gated = np.where(y_raw < 0.65, 0.0, y_raw)
            y_round = np.rint(y_gated).clip(0, None)
            standalone_sub = df_pred[KEYS].copy()
            standalone_sub["quantity"] = y_round

            m_stand = compute_metrics_with_diagnostics(fold_truth[fold], standalone_sub, fold_baseline[fold])
            component_records.append({
                "model": f"LightGBM_Standalone_{variant}",
                "variant": variant,
                "fold": fold,
                "origin": origin,
                **m_stand,
            })

            # Blend evaluation: 50% TFT + 30% LGBM_variant + 10% CB + 10% PerCat
            comp_variant = {
                "tft": base_components_by_fold[fold]["tft"],
                "lgbm": pd.DataFrame({
                    "week": df_pred["week"],
                    "warehouse_name": df_pred["warehouse_name"],
                    "article": df_pred["article"],
                    "p_sale": df_pred["p_sale"],
                    "q_cond": df_pred["conditional_quantity"],
                    "expected": df_pred["expected_quantity"],
                }),
                "catboost": base_components_by_fold[fold]["catboost"],
                "per_category": base_components_by_fold[fold]["per_category"],
            }
            keyed_b, sub_blend_var = predict_from_components(comp_variant, inf_matched_config)
            m_blend_var = compute_metrics_with_diagnostics(fold_truth[fold], sub_blend_var, fold_baseline[fold])

            blend_records.append({
                "variant": f"Blend_LightGBM_{variant}",
                "fold": fold,
                "origin": origin,
                **m_blend_var,
            })

            # Save keyed OOF for Variant A and Variant B
            if variant in ("A", "B"):
                keyed_b["origin"] = origin
                keyed_b.to_csv(KEYED_OOF_DIR / f"blend_{variant.lower()}_fold_{fold}.csv.gz", index=False, compression="gzip")

            print(f"  Variant {variant} Fold {fold}: "
                  f"Standalone Score={m_stand['clipped_score']:.6f} (unclipped={m_stand['unclipped_ratio']:.6f}) | "
                  f"Blend Score={m_blend_var['clipped_score']:.6f} (unclipped={m_blend_var['unclipped_ratio']:.6f}) | "
                  f"Origins={diag['num_origins']}, Range=[{diag['min_train_target_date']}..{diag['max_train_target_date']}]")

    # -------------------------------------------------------------------------
    # PART 3: Candidate Selection on Expanding Folds 4..1 BEFORE inspecting Fold 0
    # -------------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("PART 3: CANDIDATE SELECTION PROTOCOL (Expanding Folds 4..1)")
    print("=" * 80)

    df_blends = pd.DataFrame(blend_records)
    expanding_folds = [1, 2, 3, 4]  # folds 4..1

    mean_unclipped_expanding = {}
    mean_clipped_expanding = {}
    for var in ["A", "B", "C"]:
        sub_df = df_blends[(df_blends["variant"] == f"Blend_LightGBM_{var}") & (df_blends["fold"].isin(expanding_folds))]
        mean_unclipped_expanding[var] = float(sub_df["unclipped_ratio"].mean())
        mean_clipped_expanding[var] = float(sub_df["clipped_score"].mean())

    print(f"Expanding Folds 4..1 Unclipped Ratio:")
    print(f"  Variant A (18 origins):          {mean_unclipped_expanding['A']:.6f} (Clipped Score: {mean_clipped_expanding['A']:.6f})")
    print(f"  Variant B (52 origins):          {mean_unclipped_expanding['B']:.6f} (Clipped Score: {mean_clipped_expanding['B']:.6f})")
    print(f"  Variant C (52 origins weighted): {mean_unclipped_expanding['C']:.6f} (Clipped Score: {mean_clipped_expanding['C']:.6f})")

    # Select best strictly on unclipped_ratio across folds 4..1
    best_candidate = "A"
    best_ratio = mean_unclipped_expanding["A"]
    for var in ["B", "C"]:
        if mean_unclipped_expanding[var] < best_ratio - 1e-6:
            best_ratio = mean_unclipped_expanding[var]
            best_candidate = var

    selection_record = {
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "selection_metric": "mean_unclipped_ratio_expanding_folds_4_to_1",
        "expanding_folds": expanding_folds,
        "scores_expanding_folds_4_to_1": {
            var: {
                "unclipped_ratio": mean_unclipped_expanding[var],
                "clipped_score": mean_clipped_expanding[var],
            }
            for var in ["A", "B", "C"]
        },
        "selected_variant": best_candidate,
        "delta_vs_control_A": float(best_ratio - mean_unclipped_expanding["A"]),
        "reason": (
            f"Variant {best_candidate} selected with mean unclipped_ratio={best_ratio:.6f} "
            f"({best_ratio - mean_unclipped_expanding['A']:+.6f} vs Control A)."
        ),
    }

    selected_config_path = OUTPUT_DIR / "selected_config.json"
    with open(selected_config_path, "w", encoding="utf-8") as f:
        json.dump(selection_record, f, indent=2, ensure_ascii=False)
    print(f"\n>> Selected candidate saved to {selected_config_path}: Variant {best_candidate} <<")

    # Now report Fold 0 historical control evaluation
    print("\nHISTORICAL CONTROL EVALUATION ON FOLD 0:")
    for var in ["A", "B", "C"]:
        row = df_blends[(df_blends["variant"] == f"Blend_LightGBM_{var}") & (df_blends["fold"] == 0)].iloc[0]
        print(f"  Variant {var} Fold 0: Clipped Score = {row['clipped_score']:.6f}, Unclipped Ratio = {row['unclipped_ratio']:.6f}, SMAPE = {row['smape']:.2f}%, RMSE = {row['rmse']:.3f}")

    # -------------------------------------------------------------------------
    # PART 4: Summer 2025 Out-of-Fold Verification (Origin 80)
    # -------------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("PART 4: SUMMER 2025 OUT-OF-FOLD VERIFICATION (Origin 80)")
    print("=" * 80)
    origin_summer = 80
    val_weeks_summer = weeks[origin_summer : origin_summer + HORIZON]
    truth_summer = make_truth(matrices, origin_summer)
    truth_summer["week"] = pd.to_datetime(truth_summer["week"]).dt.strftime("%Y-%m-%d")
    b_df_summer = baseline_mean13(data, pd.Timestamp(val_weeks_summer[0]), pd.Index(val_weeks_summer))
    b_df_summer["week"] = pd.to_datetime(b_df_summer["week"]).dt.strftime("%Y-%m-%d")

    # Variant A on summer 80: 18 origins (54..71)
    df_pred_a_summer, diag_a_summer = train_lgbm_history_variant(matrices, origin_summer, variant="A", seed=42)
    # Variant B on summer 80: 46 origins available (26..71)
    df_pred_b_summer, diag_b_summer = train_lgbm_history_variant(matrices, origin_summer, variant="B", seed=42)

    for v_name, df_p, diag in [("A_18w", df_pred_a_summer, diag_a_summer), ("B_46w", df_pred_b_summer, diag_b_summer)]:
        y_r = np.where(df_p["p_sale"] < 0.5, 0.0, df_p["expected_quantity"])
        y_g = np.where(y_r < 0.65, 0.0, y_r)
        y_int = np.rint(y_g).clip(0, None)
        sub_s = df_p[KEYS].copy()
        sub_s["quantity"] = y_int
        m_s = compute_metrics_with_diagnostics(truth_summer, sub_s, b_df_summer)
        print(f"  Summer 2025 Standalone LightGBM {v_name}: Score = {m_s['clipped_score']:.6f}, Unclipped = {m_s['unclipped_ratio']:.6f}, "
              f"SMAPE = {m_s['smape']:.2f}%, WAPE = {m_s['wape']:.2f}%, Origins = {diag['num_origins']}")

    # -------------------------------------------------------------------------
    # PART 5: Multi-Seed Algorithmic Stochasticity Check (Seeds 42, 52, 62)
    # -------------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("PART 5: MULTI-SEED ALGORITHMIC STOCHASTICITY CHECK (Seeds 42, 52, 62)")
    print("NOTE: Evaluates tree subsampling stochasticity, NOT temporal independence.")
    print("=" * 80)

    seeds = [42, 52, 62]
    seed_records = []

    for seed in seeds:
        print(f"\n--- Testing Seed {seed} ---")
        for var in ["A", "B"]:
            fold_scores = []
            fold_unclipped = []
            for fold, origin in FOLD_ORIGINS.items():
                if seed == 42 and (var, fold) in lgbm_preds:
                    df_pred = lgbm_preds[(var, fold)]
                else:
                    df_pred, _ = train_lgbm_history_variant(matrices, origin, variant=var, seed=seed)

                comp_var = {
                    "tft": base_components_by_fold[fold]["tft"],
                    "lgbm": pd.DataFrame({
                        "week": df_pred["week"],
                        "warehouse_name": df_pred["warehouse_name"],
                        "article": df_pred["article"],
                        "p_sale": df_pred["p_sale"],
                        "q_cond": df_pred["conditional_quantity"],
                        "expected": df_pred["expected_quantity"],
                    }),
                    "catboost": base_components_by_fold[fold]["catboost"],
                    "per_category": base_components_by_fold[fold]["per_category"],
                }
                _, sub_b = predict_from_components(comp_var, inf_matched_config)
                m = compute_metrics_with_diagnostics(fold_truth[fold], sub_b, fold_baseline[fold])
                seed_records.append({
                    "seed": seed,
                    "variant": var,
                    "fold": fold,
                    "origin": origin,
                    **m,
                })
                fold_scores.append(m["clipped_score"])
                fold_unclipped.append(m["unclipped_ratio"])

            print(f"  Variant {var} Seed {seed}: Mean Score = {np.mean(fold_scores):.6f}, Mean Unclipped = {np.mean(fold_unclipped):.6f}")

    df_seed_metrics = pd.DataFrame(seed_records)
    df_seed_metrics.to_csv(OUTPUT_DIR / "seed_metrics.csv", index=False)
    print(f"Saved seed metrics to {OUTPUT_DIR / 'seed_metrics.csv'}")

    # -------------------------------------------------------------------------
    # PART 6: Demand Segments & Horizon Breakdown for Blend A vs Blend B
    # -------------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("PART 6: DEMAND SEGMENT (3-TIER) & HORIZON BREAKDOWN (Blend A vs Blend B)")
    print("=" * 80)

    # Use Fold 0 keyed OOF predictions
    f0_meta = pd.read_csv(PROJECT_ROOT / "experiments" / "stacking_honest" / "fold_meta_features" / "fold_0_meta.csv.gz")
    oof_a = pd.read_csv(KEYED_OOF_DIR / "blend_a_fold_0.csv.gz")
    oof_b = pd.read_csv(KEYED_OOF_DIR / "blend_b_fold_0.csv.gz")

    merged_diag = f0_meta[["week", "warehouse_name", "article", "horizon", "quantity_nonzero_rate_13", "quantity_mean_13", "target"]].copy()
    merged_diag["pred_a"] = oof_a["final_prediction"]
    merged_diag["pred_b"] = oof_b["final_prediction"]

    # Clean 3-tier segment definitions:
    # 1. Rare: nonzero rate in past 13w <= 10%
    # 2. Regular Low-Volume: nonzero rate > 10% and past 13w mean positive quantity < 5
    # 3. Regular High-Volume: nonzero rate > 10% and past 13w mean positive quantity >= 5
    pos_mean = np.where(
        merged_diag["quantity_nonzero_rate_13"] > 0,
        merged_diag["quantity_mean_13"] / np.maximum(merged_diag["quantity_nonzero_rate_13"], 1e-4),
        0.0
    )
    merged_diag["pos_mean"] = pos_mean

    merged_diag["segment"] = np.where(
        merged_diag["quantity_nonzero_rate_13"] <= 0.10, "Rare",
        np.where(pos_mean < 5.0, "Regular_LowVolume", "Regular_HighVolume")
    )

    segment_records = []
    for seg in ["Rare", "Regular_LowVolume", "Regular_HighVolume"]:
        sub_seg = merged_diag[merged_diag["segment"] == seg]
        yt = sub_seg["target"].values
        ya = sub_seg["pred_a"].values
        yb = sub_seg["pred_b"].values
        denom = float(np.sum(yt))

        wape_a = float(np.sum(np.abs(yt - ya)) / denom * 100.0) if denom > 0 else 0.0
        wape_b = float(np.sum(np.abs(yt - yb)) / denom * 100.0) if denom > 0 else 0.0
        rmse_a = float(np.sqrt(np.mean((yt - ya) ** 2)))
        rmse_b = float(np.sqrt(np.mean((yt - yb) ** 2)))

        segment_records.append({
            "segment": seg,
            "rows": len(sub_seg),
            "fact_sum": denom,
            "wape_blend_a": wape_a,
            "wape_blend_b": wape_b,
            "wape_diff_b_minus_a": wape_b - wape_a,
            "rmse_blend_a": rmse_a,
            "rmse_blend_b": rmse_b,
            "rmse_diff_b_minus_a": rmse_b - rmse_a,
        })
        print(f"  Segment '{seg}' (rows={len(sub_seg)}, fact_sum={denom:.0f}): "
              f"WAPE A={wape_a:.2f}% vs B={wape_b:.2f}% | RMSE A={rmse_a:.2f} vs B={rmse_b:.2f}")

    df_segment_metrics = pd.DataFrame(segment_records)
    df_segment_metrics.to_csv(OUTPUT_DIR / "segment_metrics.csv", index=False)

    horizon_records = []
    for h in range(1, 10):
        sub_h = merged_diag[merged_diag["horizon"] == h]
        yt = sub_h["target"].values
        ya = sub_h["pred_a"].values
        yb = sub_h["pred_b"].values
        denom = float(np.sum(yt))

        wape_a = float(np.sum(np.abs(yt - ya)) / denom * 100.0) if denom > 0 else 0.0
        wape_b = float(np.sum(np.abs(yt - yb)) / denom * 100.0) if denom > 0 else 0.0
        rmse_a = float(np.sqrt(np.mean((yt - ya) ** 2)))
        rmse_b = float(np.sqrt(np.mean((yt - yb) ** 2)))

        horizon_records.append({
            "horizon": h,
            "rows": len(sub_h),
            "fact_sum": denom,
            "wape_blend_a": wape_a,
            "wape_blend_b": wape_b,
            "wape_diff_b_minus_a": wape_b - wape_a,
            "rmse_blend_a": rmse_a,
            "rmse_blend_b": rmse_b,
            "rmse_diff_b_minus_a": rmse_b - rmse_a,
        })
    df_horizon_metrics = pd.DataFrame(horizon_records)
    df_horizon_metrics.to_csv(OUTPUT_DIR / "horizon_metrics.csv", index=False)

    # -------------------------------------------------------------------------
    # PART 7: Network Level Article Total & 10% Top-Down Reconciliation
    # -------------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("PART 7: NETWORK ARTICLE TOTAL & 10% TOP-DOWN RECONCILIATION")
    print("=" * 80)

    # Aggregate article sales
    art_df = data.groupby(["article", "week"], as_index=False).agg({"quantity": "sum"})
    articles = sorted(data["article"].unique())
    n_articles = len(articles)
    art_to_idx = {a: i for i, a in enumerate(articles)}
    n_weeks = len(weeks)

    art_qty = np.zeros((n_articles, n_weeks), dtype=np.float32)
    for _, row in art_df.iterrows():
        art_qty[art_to_idx[row["article"]], weeks.index(row["week"])] = row["quantity"]

    cat_info = data[["article", "category_lvl_1", "category_lvl_2", "category_lvl_3"]].drop_duplicates("article").set_index("article").loc[articles]

    # Pre-calculate warehouse shares for all origins
    def compute_warehouse_shares(origin: int) -> pd.DataFrame:
        w_df = data[data["week"] < weeks[origin]].copy()
        p4_start = weeks[max(0, origin - 4)]
        p13_start = weeks[max(0, origin - 13)]
        p26_start = weeks[max(0, origin - 26)]

        s4 = w_df[w_df["week"] >= p4_start].groupby(["article", "warehouse_name"])["quantity"].sum().unstack(fill_value=0)
        s13 = w_df[w_df["week"] >= p13_start].groupby(["article", "warehouse_name"])["quantity"].sum().unstack(fill_value=0)
        s26 = w_df[w_df["week"] >= p26_start].groupby(["article", "warehouse_name"])["quantity"].sum().unstack(fill_value=0)

        for s in [s4, s13, s26]:
            for a in articles:
                if a not in s.index:
                    s.loc[a] = 0.0
            s.sort_index(inplace=True)

        cat_map = data[["article", "category_lvl_1"]].drop_duplicates().set_index("article").loc[articles]
        s13_cat = s13.join(cat_map).groupby("category_lvl_1").sum()
        cat_share = s13_cat.div(s13_cat.sum(axis=1), axis=0)
        art_cat_share = cat_map.join(cat_share, on="category_lvl_1")[s13.columns]

        tot4 = s4.sum(axis=1)
        tot13 = s13.sum(axis=1)
        tot26 = s26.sum(axis=1)

        p4 = s4.div(tot4.replace(0, np.nan), axis=0).fillna(art_cat_share)
        p13 = s13.div(tot13.replace(0, np.nan), axis=0).fillna(art_cat_share)
        p26 = s26.div(tot26.replace(0, np.nan), axis=0).fillna(art_cat_share)

        p_raw = 0.35 * p4 + 0.45 * p13 + 0.20 * p26
        M = 5.0
        shrunk = (p_raw.multiply(tot13, axis=0) + art_cat_share * M).div(tot13 + M, axis=0)
        final_share = shrunk.div(shrunk.sum(axis=1), axis=0)
        assert np.allclose(final_share.sum(axis=1), 1.0, atol=1e-5)
        return final_share

    def train_network_model(origin: int, history_len: int = 52, use_article_cat: bool = False) -> np.ndarray:
        latest_train_origin = origin - HORIZON
        earliest_train_origin = max(26, latest_train_origin - (history_len - 1))
        train_origins = np.arange(earliest_train_origin, latest_train_origin + 1)

        def make_art_features(org_list: np.ndarray, is_val: bool = False):
            rows, targets = [], []
            for org in org_list:
                lag_1 = art_qty[:, org - 1]
                lag_2 = art_qty[:, org - 2]
                lag_4 = art_qty[:, org - 4]
                lag_13 = art_qty[:, org - 13]
                lag_26 = art_qty[:, org - 26]
                lag_52 = art_qty[:, org - 52] if org >= 52 else np.full(n_articles, np.nan, dtype=np.float32)

                mean_4 = art_qty[:, max(0, org - 4) : org].mean(axis=1)
                sum_4 = art_qty[:, max(0, org - 4) : org].sum(axis=1)
                mean_13 = art_qty[:, max(0, org - 13) : org].mean(axis=1)
                sum_13 = art_qty[:, max(0, org - 13) : org].sum(axis=1)
                mean_26 = art_qty[:, max(0, org - 26) : org].mean(axis=1)
                sum_26 = art_qty[:, max(0, org - 26) : org].sum(axis=1)
                max_13 = art_qty[:, max(0, org - 13) : org].max(axis=1)
                std_13 = art_qty[:, max(0, org - 13) : org].std(axis=1)
                growth_4_13 = (mean_4 + 1e-4) / (mean_13 + 1e-4)

                for h in range(1, HORIZON + 1):
                    t_idx = org + h - 1
                    tw = weeks[t_idx]
                    woy = tw.isocalendar().week
                    month = tw.month
                    f_dict = {
                        "article": articles,
                        "horizon": h,
                        "week_of_year": woy,
                        "month": month,
                        "sin_week": np.sin(2 * np.pi * woy / 52.1775),
                        "cos_week": np.cos(2 * np.pi * woy / 52.1775),
                        "category_lvl_1": cat_info["category_lvl_1"].values,
                        "category_lvl_2": cat_info["category_lvl_2"].values,
                        "category_lvl_3": cat_info["category_lvl_3"].values,
                        "lag_1": lag_1, "lag_2": lag_2, "lag_4": lag_4, "lag_13": lag_13, "lag_26": lag_26, "lag_52": lag_52,
                        "mean_4": mean_4, "sum_4": sum_4, "mean_13": mean_13, "sum_13": sum_13,
                        "mean_26": mean_26, "sum_26": sum_26, "max_13": max_13, "std_13": std_13,
                        "growth_4_13": growth_4_13,
                    }
                    rows.append(pd.DataFrame(f_dict))
                    if not is_val:
                        targets.append(art_qty[:, t_idx])
            return pd.concat(rows, ignore_index=True), (np.concatenate(targets) if targets else None)

        X_tr, y_tr = make_art_features(train_origins, is_val=False)
        X_v, _ = make_art_features(np.array([origin]), is_val=True)

        cat_cols = ["category_lvl_1", "category_lvl_2", "category_lvl_3"]
        if use_article_cat:
            cat_cols.append("article")
        feats = [c for c in X_tr.columns if c != "article" or use_article_cat]

        X_train = X_tr[feats].copy()
        X_val = X_v[feats].copy()
        for c in cat_cols:
            if c in X_train.columns:
                X_train[c] = X_train[c].astype("category")
                X_val[c] = X_val[c].astype("category")

        model = lgb.LGBMRegressor(
            n_estimators=180, learning_rate=0.05, num_leaves=31, min_child_samples=30,
            subsample=0.8, colsample_bytree=0.8, random_state=42, verbosity=-1, n_jobs=-1
        )
        model.fit(X_train, np.log1p(np.maximum(y_tr, 0)))
        return np.expm1(model.predict(X_val)).clip(0, None)

    # Evaluate article level WAPE/RMSE and 10% reconciliation across folds
    article_level_records = []
    reconciliation_records = []

    for fold, origin in FOLD_ORIGINS.items():
        val_weeks = weeks[origin : origin + HORIZON]
        net_pred_b = train_network_model(origin, history_len=52, use_article_cat=False)
        net_pred_b_art = train_network_model(origin, history_len=52, use_article_cat=True)

        # Ground truth article total
        art_truth_list = []
        for h in range(1, HORIZON + 1):
            t_idx = origin + h - 1
            for a_idx, a in enumerate(articles):
                art_truth_list.append({
                    "article": a, "week": str(weeks[t_idx].date()), "horizon": h,
                    "y_true": art_qty[a_idx, t_idx],
                })
        df_art_eval = pd.DataFrame(art_truth_list)
        df_art_eval["y_net_b"] = net_pred_b
        df_art_eval["y_net_b_art"] = net_pred_b_art

        # Bottom sum from Blend B
        oof_b = pd.read_csv(KEYED_OOF_DIR / f"blend_b_fold_{fold}.csv.gz")
        bottom_sum_raw = oof_b.groupby(["article", "week"])["raw_blend"].sum().reset_index().rename(columns={"raw_blend": "y_bot_raw"})
        bottom_sum_scaled = oof_b.groupby(["article", "week"])["scaled_blend"].sum().reset_index().rename(columns={"scaled_blend": "y_bot_scaled"})

        df_art_eval = df_art_eval.merge(bottom_sum_raw, on=["article", "week"]).merge(bottom_sum_scaled, on=["article", "week"])

        yt = df_art_eval["y_true"].values
        denom = float(np.sum(yt))
        wape_net_b = float(np.sum(np.abs(yt - df_art_eval["y_net_b"].values)) / denom * 100.0)
        rmse_net_b = float(np.sqrt(np.mean((yt - df_art_eval["y_net_b"].values) ** 2)))

        wape_net_b_art = float(np.sum(np.abs(yt - df_art_eval["y_net_b_art"].values)) / denom * 100.0)
        rmse_net_b_art = float(np.sqrt(np.mean((yt - df_art_eval["y_net_b_art"].values) ** 2)))

        wape_bot_raw = float(np.sum(np.abs(yt - df_art_eval["y_bot_raw"].values)) / denom * 100.0)
        rmse_bot_raw = float(np.sqrt(np.mean((yt - df_art_eval["y_bot_raw"].values) ** 2)))

        wape_bot_scaled = float(np.sum(np.abs(yt - df_art_eval["y_bot_scaled"].values)) / denom * 100.0)
        rmse_bot_scaled = float(np.sqrt(np.mean((yt - df_art_eval["y_bot_scaled"].values) ** 2)))

        article_level_records.append({
            "fold": fold, "origin": origin,
            "net_b_wape": wape_net_b, "net_b_rmse": rmse_net_b,
            "net_b_art_wape": wape_net_b_art, "net_b_art_rmse": rmse_net_b_art,
            "bottom_sum_raw_wape": wape_bot_raw, "bottom_sum_raw_rmse": rmse_bot_raw,
            "bottom_sum_scaled_wape": wape_bot_scaled, "bottom_sum_scaled_rmse": rmse_bot_scaled,
        })

        print(f"  Fold {fold} Article Total: Net_B WAPE={wape_net_b:.2f}%, Net_B+Art WAPE={wape_net_b_art:.2f}% | "
              f"Bot Sum Raw WAPE={wape_bot_raw:.2f}%, Bot Sum Scaled WAPE={wape_bot_scaled:.2f}%")

        # Top-down allocation to warehouse level
        wh_shares = compute_warehouse_shares(origin)  # (799 articles x 11 warehouses)
        # Build top-down predictions per pair-week
        df_topdown_list = []
        for h in range(1, HORIZON + 1):
            t_idx = origin + h - 1
            w_str = str(weeks[t_idx].date())
            sub_art = df_art_eval[df_art_eval["horizon"] == h].set_index("article")
            for a in articles:
                art_forecast = sub_art.loc[a, "y_net_b_art"]
                shares = wh_shares.loc[a]
                for wh_name, sh in shares.items():
                    df_topdown_list.append({
                        "week": w_str,
                        "warehouse_name": wh_name,
                        "article": a,
                        "topdown_pred": art_forecast * sh,
                    })
        df_topdown = pd.DataFrame(df_topdown_list)
        merged_rec = oof_b.merge(df_topdown, on=KEYS, how="inner")

        # Test reconciliation weights: 100% Blend B vs 90% Blend B + 10% TopDown
        for w_td in [0.0, 0.10, 0.20]:
            rec_raw = (1.0 - w_td) * merged_rec["scaled_blend"].values + w_td * merged_rec["topdown_pred"].values
            rec_final = np.rint(np.where(rec_raw < 0.65, 0.0, rec_raw)).clip(0, None)
            sub_rec = merged_rec[KEYS].copy()
            sub_rec["quantity"] = rec_final

            m_rec = compute_metrics_with_diagnostics(fold_truth[fold], sub_rec, fold_baseline[fold])
            reconciliation_records.append({
                "fold": fold, "origin": origin,
                "topdown_weight": w_td,
                **m_rec,
            })

    df_art_metrics = pd.DataFrame(article_level_records)
    df_art_metrics.to_csv(OUTPUT_DIR / "article_level_metrics.csv", index=False)

    df_rec_metrics = pd.DataFrame(reconciliation_records)
    df_rec_metrics.to_csv(OUTPUT_DIR / "reconciliation_metrics.csv", index=False)

    # Save summary tables
    pd.DataFrame(component_records).to_csv(OUTPUT_DIR / "component_metrics.csv", index=False)
    pd.DataFrame(blend_records).to_csv(OUTPUT_DIR / "blend_metrics.csv", index=False)

    config_record = {
        "legacy_frozen_config": legacy_config,
        "inference_matched_config": inf_matched_config,
        "history_variants": {
            "A": "last 18 origins (control)",
            "B": "last 52 origins (candidate winner)",
            "C": "last 52 origins with exponential decay sample weights",
        },
        "seeds_evaluated": seeds,
        "segment_definitions": {
            "Rare": "historical nonzero rate past 13w <= 10%",
            "Regular_LowVolume": "nonzero rate past 13w > 10% and positive mean < 5",
            "Regular_HighVolume": "nonzero rate past 13w > 10% and positive mean >= 5",
        },
    }
    with open(OUTPUT_DIR / "config.json", "w", encoding="utf-8") as f:
        json.dump(config_record, f, indent=2, ensure_ascii=False)

    # Print checksums of all output files
    print("\n" + "=" * 80)
    print("SHA-256 CHECKSUMS OF GENERATED ARTIFACTS:")
    print("=" * 80)
    all_artifacts = sorted(list(OUTPUT_DIR.glob("*.csv")) + list(OUTPUT_DIR.glob("*.json")))
    for art in all_artifacts:
        sha = compute_sha256(art)
        print(f"  {art.name:30s} : {sha}")

    print("\n" + "=" * 80)
    print("STRICT HISTORY AUDIT EXECUTION COMPLETE!")
    print("=" * 80)


if __name__ == "__main__":
    main()
